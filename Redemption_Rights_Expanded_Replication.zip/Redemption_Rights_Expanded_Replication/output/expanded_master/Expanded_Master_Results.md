# Expanded master manuscript and empirical results

The revised master combines the audited theory and literature with an expanded monthly comparison and a complete dated contractual calculation. The current valuation date is **31 August 2026**.

## Completed coverage

The dated callable calculation includes **98 bonds: 32 green and 66 conventional, across eight legal issuers**. Each is valued with its own payment schedule and redemption terms under both the conventional and green kernels.

| Legal issuer | Green | Conventional | Total |
| --- | --- | --- | --- |
| Apple | 1 | 2 | 3 |
| Boston Properties | 4 | 3 | 7 |
| DTE Electric | 5 | 11 | 16 |
| Equinix | 2 | 5 | 7 |
| MidAmerican Energy | 7 | 6 | 13 |
| NSP Minnesota | 5 | 7 | 12 |
| PSC Colorado | 4 | 8 | 12 |
| Verizon | 4 | 24 | 28 |

The monthly dataset contains **114 eligible historical contracts and 10,398 cash-flow observations** from January 2016 through August 2026. There are **34 historical green bonds and 2,624 green bond-months with a same-issuer conventional curve**. Twenty-one early Apple green observations lack a conventional quote and are retained in the source data but excluded from green inversion. The monthly branch produces 10,377 pre-option price predictions.

The original 111-contract register was extended to **119 records** by verifying eight older conventional issues: MidAmerican AB/AE/AH, NSP Minnesota BQ/CA/CB and DTE EA/EB. The initial 9,374 archived cash-flow observations reproduce; the additions contribute 1,024 further observations. All 20,106 original source codes remain in the master inventory.

## What is estimated and what is maintained

The Treasury discount curve is the supplied dated Gürkaynak–Sack–Wright Svensson curve. An explicit deterministic shift makes it the AFNS model's initial discount curve. This is an exact fit to that supplied fitted curve, not evidence that every underlying Treasury bond is priced without error. Stochastic AFNS Treasury dynamics remain in the current callable calculation; H.15 supplies the contractual fixing conventions.

The credit level has zero pricing-measure drift. Credit slope and curvature retain their deterministic AFNS evolution, with decay 0.30 and a nonnegative instantaneous conventional spread constraint. Credit and green diffusion are zero in this empirical specialization. Each issuer's current green state is fitted jointly from its green quotes and may be positive or negative. Its green decay is fixed at 0.10, its long-run mean is zero, and therefore the plotted greenium slope is conditional on an imposed maturity profile.

| Issuer | Current state (bp) | 5-year greenium (bp) | 20-year greenium (bp) | Conventional RMSE (bp) | Green RMSE (bp) |
| --- | --- | --- | --- | --- | --- |
| Apple | 12.398 | 9.757 | 5.360 | 5.406 | 0.000 |
| Boston Properties | -2.645 | -2.081 | -1.143 | 3.225 | 10.550 |
| DTE Electric | 5.893 | 4.637 | 2.548 | 7.709 | 5.412 |
| Equinix | -1.546 | -1.217 | -0.668 | 1.223 | 4.003 |
| MidAmerican Energy | 60.671 | 47.744 | 26.230 | 2.654 | 20.330 |
| NSP Minnesota | 35.535 | 27.964 | 15.363 | 7.737 | 10.887 |
| PSC Colorado | 11.167 | 8.788 | 4.828 | 11.498 | 11.604 |
| Verizon | 4.324 | 3.403 | 1.869 | 9.270 | 3.083 |

These are fitted common states and curves. They are not a set of individually exact quote inversions, filtered states from a joint dynamic panel, or an unrestricted estimate of all pricing dynamics. The conventional RMSE uses fitting bonds; Verizon GK is the explicitly held-out conventional quote. The individual green inversions are supplied separately, with their differences from the common state and the original pricing residuals.

## Additional conventional bonds change the benchmark

The pre-option same-cash-flow comparisons quantify why conventional maturity information matters:

| Green bond | Before additional conventional bonds | After | Unit |
|---|---:|---:|---|
| DTE VAN | 23.638 | −0.054 | bp |
| MidAmerican AQ | 433.815 | 95.029 | bp |
| MidAmerican AT | 241.524 | 29.204 | bp |
| NSP Minnesota CT | 153.532 | 35.044 | bp |

For NSP Minnesota the conventional Jacobian condition number falls from approximately 4,774 to 27.6, and the common green fitting RMSE falls from 48.87 to 10.94 bp. MidAmerican's condition number falls from approximately 5,207 to 80.9. These comparisons hold the green observations fixed. They measure benchmark sensitivity, not a change in green preferences.

**15 of the 32 current green maturities lie inside their issuer's conventional maturity envelope.** The other 17 remain extrapolations. All seven current MidAmerican green maturities remain outside that envelope, including its very short issues. Curves and diagnostics retain this distinction. A better-conditioned fit does not remove price-source, liquidity, vintage or residual model effects.

## Redemption values and the important sensitivity

Across the current 32 green bonds, the mean absolute same-contract redemption correction is **0.146 bp**, and the median absolute correction is **0.015 bp**. **29 of 32** absolute corrections are below 0.1 bp under the common fitted states. The mean absolute correction excluding MidAmerican AT is **0.037 bp**.

AT is the material exception. At its common fitted green state of **60.671 bp**, the green own option is **0.118153 per 100** and the same-contract redemption correction is **-3.531 bp**. The independent numerical refinement changes the correction to **-3.484 bp**, a change of only **0.047 bp**.

The common-state pricing residual for AT is nevertheless **-19.638 bp**. Its individual fixed-option implied state is **38.921 bp**. Repricing the option once at that state, with the conventional curve fixed, gives an own option of **0.059981 per 100** and a redemption correction of **-1.140 bp**. That is a state-sensitivity calculation. It is not a new common state or a recursive callable-price calibration. The chosen-state numerical calculation is stable, while the economic magnitude remains sensitive to the green state and conventional maturity support.

NSP BQ is a useful counterexample in the contract layer: its original indenture expressly makes it noncallable, so its redemption option is exactly zero. A numerical zero for a callable bond has a different interpretation and does not establish a theoretical zero.

## Comparison with matched-bond greenia

The fixed nearest-comparator design contains **19 green bonds and 1,395 bond-months**; the strict nonnegative bracket contains **nine and 619**; the nearest-two sensitivity contains **12 and 807**. The original raw matched series reproduce within 1.3×10⁻⁹ bp.

The nearest pooled raw mean is 4.217 bp and its GSW cash-flow-standardized mean is 4.232 bp. The signed standardization nearly cancels in the average, but its mean absolute effect is **2.856 bp**. For the bracketing sample, the raw mean is 3.235 bp, the standardized mean is 2.905 bp, and the mean absolute standardization is **0.834 bp**. The raw means across the two designs refer to different samples.

On the identical 619 observations, changing between nearest and bracketing designs moves the raw estimate by about **3.43 bp on average in absolute value**, with **96 sign reversals**. Treating the source field as dirty instead of clean changes the nearest estimate by **10.17 bp** on average in absolute value and the bracket estimate by **11.10 bp**. Coupon-reset evidence supports clean treatment, so these are consequence-of-convention sensitivities rather than two equally likely price interpretations.

This is an adaptation of Zerbib's matching stage. The full liquidity regression and a provider-OAS comparison have not been reproduced. For the current dated sample, **37 matched comparisons** are reconciled exactly into the same-contract straight greenium, conventional coupon-and-curve differences, conventional contractual option differences, the green effect on its own option, and the two observed-price residual components. The maximum arithmetic discrepancy is 2.4e-10 bp.

## Contract and numerical implementation

The expansion distinguishes weekly H.15, daily H.15, notice-relative fixing and dealer-comparable Treasury rules. Continuation regressions now retain every already observed stochastic fixing state required by the finite-grid action set. The generic schedule respects MidAmerican AH's verified February/August coupons and the final October short coupon of 0.966667 per 100.

Older certificates without an express accrued-interest exclusion use the separately identified literal full-schedule-plus-accrued convention. Dealer quotations are represented by the stated model par-yield proxy. Funded irrevocable notice, the recorded trustee-shortening assumption and the common banking-calendar approximation are retained where relevant. DTE's two senior-note wrappers and mortgage-collateral release/substitution conditions remain explicit.

The 11 callable NSP contracts with an unverified maximum notice use a restricted exactly 30-calendar-day policy; candidates whose business-day adjustment breaks that lag are skipped. This does not represent the full legal notice action set. Boston's month-rounding rule uses calendar months. Fifteen current contracts extend beyond the supplied 30-year Treasury maturity range and use the maintained extrapolation, with a maximum horizon of 43.77 years.

All eight conventional and eight common-green-state fits terminate successfully. MidAmerican requires a warm restart from the archived iteration-capped incumbent, changing the conventional weighted price RMSE from 2.656243 to 2.656161 bp. Solver success does not establish global optimality or identification. Separately trained policies also retain small signed option-ordering reversals; conditional evaluation errors exclude that policy approximation.

The main calculation uses 768 training paths, 2,304 evaluation paths, 32 conditional fixing draws and a 30-day decision grid. The AT refinement doubles training and evaluation paths, uses 64 fixing draws and a 15-day grid. Evaluation standard errors condition on fitted parameters and learned policies. They do not quantify price-source, parameter, lifecycle, contract-convention or all numerical-policy uncertainty.

## Manuscript changes

The revised paper restores the current AFNS initial-curve treatment, the driftless credit-level baseline, the holding-service interpretation, the measure-change range condition, the restricted deterministic option ordering and the distinction between conditional inversion and joint identification. It adds the expanded empirical evidence and the latest-admissible-notice dominance lemma with its finite-grid qualification.

The dedicated literature section retains Jarrow–Li–Liu–Wu, Duffie–Singleton, Duffee, Christensen–Diebold–Rudebusch, Christensen–Lopez, the make-whole literature, Zerbib and Pietsch–Salakhova. The closer green valuation and term-structure predecessors are retained, including Agliardi–Agliardi, Kanamura, D'Amico–Klausmann–Pancost and Mercuri–Rroji–Stefani. The TIPS-liquidity analogy and Caramichael–Rapp's state-dependent callability controls are added with source-specific attribution. Van Loan remains an established computational tool; its use is not presented as the paper's identification novelty.

## Files and remaining scope

The master PDF and TeX contain the complete paper. The source-and-replication ZIP includes the bibliography, publication figures, price and curve tables, monthly comparisons, original and expanded branches, normalized contracts, source provenance, code and input subset. The full-universe ledger distinguishes reviewed contracts from candidates.

**1,477 mechanically screened source codes with current positive quotes remain in the contract-review queue**, including 110 unverified source-green flags. They have not been represented as priced contracts. The complete monthly option-valued panel, unrestricted dynamic estimation and production validation remain separate stages. All 98 current contract prices and both-kernel decompositions in this release are completed conditional calculations.
