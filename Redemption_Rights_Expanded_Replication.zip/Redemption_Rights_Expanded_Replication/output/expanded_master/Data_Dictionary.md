# Empirical data dictionary

All current contractual prices use 31 August 2026. Values labelled `per100` are monetary prices per 100 principal. Rate differences labelled `bp` are annual-rate basis points. Yield columns labelled `pct` are nominal semiannual yields expressed in percent, with ACT/365.25 horizons to adjusted payment dates.

## All_Bond_Prices_and_Components.csv

- `code`, `issuer`, `maturity_date`, `coupon_pct`, `split`, `is_green`: the verified security, legal pricing group and actual-label role. `conventional_holdout` is Verizon GK.
- `observed_clean_per100`, `accrued_per100`, `observed_dirty_per100`: clean-assumed source quote, computed accrued and dirty target.
- `treasury_straight_dirty_per100`: the contract's scheduled cash flows discounted using the dated initial Treasury curve.
- `issuer_discount_cost_per100`: Treasury straight price minus conventional issuer straight price; it is an effective issuer-discount component, not a separately identified default loss.
- `brown_*`, `green_*`: that same contract under the conventional or green kernel. Each has its own optimal-policy approximation. These prefixes do not change the legal security label.
- `actual_*`: the green kernel for verified green contracts and the conventional kernel for conventional contracts.
- `*_straight_dirty_per100`, `*_option_value_per100`, `*_callable_dirty_per100`: promised-flow price, own redemption deduction and resulting callable price. Straight minus option equals callable.
- `*_option_yield_wedge_bp`: callable yield minus straight yield, using exact yield roots on the same schedule.
- `*_yield_error_bp`: model yield minus observed yield. Positive means the model price is too low under the common yield convention.
- `same_contract_green_minus_brown_option_per100`: monetary option difference under the two kernels, preserving the contract.
- `same_contract_option_difference_paired_mc_se_per100`: antithetic-pair evaluation standard error of that difference with common paths. It excludes parameter and policy-estimation uncertainty.
- `endpoint_zero_greenium_bp`, `zero_to_nominal_compounding_bp`, `coupon_schedule_and_curve_effect_bp`, `redemption_effect_bp`: four additive terms giving the common-contract callable coupon-yield greenium.
- `fixed_option_implied_green_state_bp`: independent analytical state solving straight price = observed dirty price + own option from the common fit. The option is held fixed in this root.
- `fixed_option_implied_endpoint_zero_greenium_bp`: that implied state's zero greenium at final adjusted maturity, under the fixed green shape.
- `inside_conventional_maturity_support`: final green/payment horizon lies within the conventional fitting maturity envelope; this is a support diagnostic, not proof of identification.

## Treasury_Credit_and_Green_Zero_Curves.csv

`treasury_zero_pct`, `brown_zero_pct`, `green_zero_pct` are continuously compounded annual zero yields in percent. `credit_zero_spread_bp` is brown minus Treasury; `greenium_zero_bp` is brown minus green. The green maturity profile has fixed decay 0.10, zero long-run mean and zero diffusion. The conventional support endpoints identify where curve extrapolation is being used.

## Matched_Greenium_Exact_Decomposition.csv

The observed matched greenium equals six terms: same-contract straight greenium; the weighted conventional straight-yield difference from the green schedule; conventional contractual option-wedge difference; the green effect on its own option wedge; weighted conventional observed-minus-model yield; and green model-minus-observed yield. The weights sum to one. Extrapolating designs remain explicitly labelled.

## Monthly files

The monthly results in the replication package are **pre-option**. They contain no imputed zero option values. `common_z_bp` is a separately fitted date/issuer state under a fixed green profile. `independent_z_bp` is an individual conditional inversion. Clean and dirty alternatives are separate rows, so filters must retain the intended `price_basis`. Fixed matching selections are ex-post and do not constitute a real-time backtest. Solver, coefficient-bound, quote-convention, contract, maturity-support and source-date fields must be retained in downstream analysis.
