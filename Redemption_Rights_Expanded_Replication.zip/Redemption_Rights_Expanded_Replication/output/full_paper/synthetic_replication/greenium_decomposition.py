"""Recompute the coupon-yield decomposition from the stored synthetic prices.

This script transforms existing valuation outputs; it does not estimate an
empirical greenium or rerun the callable-bond simulation.
"""

from pathlib import Path
import json
import numpy as np
from scipy.optimize import brentq


def main():
    root = Path(__file__).resolve().parent
    original = json.loads((root / "representative_results.json").read_text())
    contract = original["contract"]
    times = np.array(contract["coupon_dates"], dtype=float)
    notional = float(contract["notional"])
    coupon = notional * float(contract["annual_coupon_rate"]) / 2.0
    cashflows = np.full(times.shape, coupon)
    cashflows[-1] += notional

    def price(y):
        return float(np.sum(cashflows * (1.0 + y / 2.0) ** (-2.0 * times)))

    def ytm(p):
        y = brentq(lambda v: price(v) - p, -0.5, 1.0, xtol=1e-14)
        assert abs(price(y) - p) < 1e-9
        return y

    rows = {(r["security"], r["exercise_rule"]): r for r in original["results"]}
    conventional = rows[("conventional", "frictionless")]["straight_price"]
    green = rows[("green", "frictionless")]["straight_price"]
    straight_gap_bp = 1e4 * (ytm(conventional) - ytm(green))
    result = {
        "scope": "Synthetic ten-year, 4.5% coupon, semiannual nominal annual YTM",
        "source": "representative_results.json",
        "straight_conventional_price": conventional,
        "straight_green_price": green,
        "straight_price_premium": green - conventional,
        "straight_coupon_greenium_bp": straight_gap_bp,
        "results": [],
    }
    for rule in ("frictionless", "intensity"):
        b = rows[("conventional", rule)]
        g = rows[("green", rule)]
        raw_gap = 1e4 * (ytm(b["callable_price"]) - ytm(g["callable_price"]))
        b_wedge = 1e4 * (ytm(b["callable_price"]) - ytm(conventional))
        g_wedge = 1e4 * (ytm(g["callable_price"]) - ytm(green))
        correction = straight_gap_bp - raw_gap
        assert abs(correction - (g_wedge - b_wedge)) < 1e-10
        diff_option = g["option_value"] - b["option_value"]
        result["results"].append({
            "exercise_rule": rule,
            "conventional_option": b["option_value"],
            "green_option": g["option_value"],
            "differential_option": diff_option,
            "differential_option_share_of_straight_price_premium_percent":
                100.0 * diff_option / (green - conventional),
            "conventional_option_yield_wedge_bp": b_wedge,
            "green_option_yield_wedge_bp": g_wedge,
            "callable_coupon_greenium_bp": raw_gap,
            "straight_minus_callable_greenium_bp": correction,
        })
    (root / "greenium_decomposition.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
