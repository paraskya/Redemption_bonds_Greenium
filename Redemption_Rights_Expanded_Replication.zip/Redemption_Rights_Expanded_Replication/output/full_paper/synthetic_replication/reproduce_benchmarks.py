#!/usr/bin/env python3
"""Reproduce the analytical/Monte Carlo checks accompanying the revised paper.

All prices are per 100 principal, rates are decimals per year, and time is in
years. Synthetic schedules have exact semiannual periods and zero notice. The
single-date make-whole benchmark deliberately has no par floor and continuous
compounding, as required by its analytical formula. It is not an indenture.

Run: python reproduce_benchmarks.py
Writes results.json and numerical_table.tex beside this script. NumPy and SciPy
are the only non-standard dependencies. The one-factor benchmark is independently coded and included below.
"""
from __future__ import annotations

import os
for _name in ("OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "OMP_NUM_THREADS"):
    os.environ[_name] = "1"

from pathlib import Path
import hashlib
import json
import platform
import time
import numpy as np
import scipy
from scipy.integrate import quad, solve_ivp
from scipy.linalg import expm
from scipy.optimize import brentq
from scipy.special import ndtr


class GaussianModel:
    """Seven-factor Q model; integrated state order is (Y[0:7], I_B, I_Z)."""
    def __init__(self):
        self.lam, self.lamF, self.epsF, self.muZ = .45, .30, .05, 1.12
        self.K = np.diag([0., self.lam, self.lam, self.epsF,
                          self.lamF, self.lamF, self.muZ])
        self.K[1, 2] = -self.lam
        self.K[4, 5] = -self.lamF
        self.theta = np.array([0., 0., 0., .012, 0., 0., .000344])
        self.y0 = np.array([.03, -.01, 0., .012, 0., 0., .0009])
        self.delta = .002
        self.vol = np.array([.006, .009, .012, .003, .004, .005, .0006])
        self.correlation = np.eye(7)
        for i, j, r in [(0, 3, -.30), (1, 6, .20),
                         (3, 6, -.25), (0, 6, .10)]:
            self.correlation[i, j] = self.correlation[j, i] = r
        self.Omega = np.outer(self.vol, self.vol) * self.correlation
        np.linalg.cholesky(self.Omega)
        self.rhoX = np.array([1., 1., 0., 0., 0., 0., 0.])
        self.rhoB = np.array([1., 1., 0., 1., 1., 0., 0.])
        self.rhoG = self.rhoB.copy()
        self.rhoG[6] = -1.
        self._Acache = {}
        self._transition_cache = {}

    @staticmethod
    def kernel(tau, k):
        return float(tau) if k == 0 else -np.expm1(-k * tau) / k

    def ell(self, tau):
        return self.kernel(tau, self.muZ)

    def rho(self, green=False, treasury=False):
        return self.rhoX if treasury else self.rhoG if green else self.rhoB

    def B(self, tau, green=False, treasury=False):
        tau = float(tau)
        bs = self.kernel(tau, self.lam)
        out = np.array([tau, bs, bs-tau*np.exp(-self.lam*tau), 0., 0., 0., 0.])
        if not treasury:
            bfs = self.kernel(tau, self.lamF)
            out[3:6] = [self.kernel(tau, self.epsF), bfs,
                        bfs-tau*np.exp(-self.lamF*tau)]
            if green:
                out[6] = -self.ell(tau)
        return out

    def A(self, tau, green=False, treasury=False):
        key = (float(tau), bool(green), bool(treasury))
        if key not in self._Acache:
            b = self.B(tau, green, treasury)
            r = self.rho(green, treasury)
            v = quad(lambda w: self.B(w, green, treasury) @ self.Omega @
                     self.B(w, green, treasury), 0., tau,
                     epsabs=1e-13, epsrel=1e-12)[0]
            self._Acache[key] = float((b-tau*r) @ self.theta + .5*v)
        return self._Acache[key]

    def zcb(self, tau, y=None, green=False, treasury=False):
        y = self.y0 if y is None else np.asarray(y)
        shift = 0. if treasury else self.delta
        return np.exp(-shift*tau + self.A(tau, green, treasury)
                      - y @ self.B(tau, green, treasury))

    def augmented_transition(self, dt):
        key = float(dt)
        if key in self._transition_cache:
            return self._transition_cache[key]
        drift = np.zeros((9, 9))
        drift[:7, :7] = -self.K
        drift[7, :7] = self.rhoB
        drift[8, 6] = 1.
        offset = np.r_[self.K @ self.theta, 0., 0.]
        diffusion = np.zeros((9, 9))
        diffusion[:7, :7] = self.Omega
        vanloan = np.block([[-drift, diffusion],
                            [np.zeros((9, 9)), drift.T]])
        ev = expm(vanloan*dt)
        affine = np.zeros((10, 10))
        affine[:9, :9] = drift
        affine[:9, 9] = offset
        ea = expm(affine*dt)
        phi, gamma = ea[:9, :9], ea[:9, 9]
        covariance = phi @ ev[:9, 9:]
        covariance = .5*(covariance+covariance.T)
        self._transition_cache[key] = (phi, gamma, covariance)
        return phi, gamma, covariance

    def coupon_bond(self, maturity, coupon, y=None, green=False):
        dates = np.arange(.5, maturity+.25, .5)
        amounts = np.full(len(dates), 100.*coupon/2.)
        amounts[-1] += 100.
        return sum(c*self.zcb(s, y, green) for s, c in zip(dates, amounts))

    def coupon_delta(self, maturity, coupon, y=None):
        dates = np.arange(.5, maturity+.25, .5)
        amounts = np.full(len(dates), 100.*coupon/2.)
        amounts[-1] += 100.
        return sum(c*self.zcb(s, y, True)*self.ell(s)
                   for s, c in zip(dates, amounts))

    def manifest(self):
        return dict(state_order=["L", "S", "C", "L_F", "S_F", "C_F", "Z"],
                    initial_state=self.y0.tolist(), theta_Q=self.theta.tolist(),
                    K_Q=self.K.tolist(), delta=self.delta,
                    factor_volatilities=self.vol.tolist(),
                    correlation=self.correlation.tolist(),
                    covariance=self.Omega.tolist(),
                    notional=100., units="years; decimal annual rates; prices per 100")


def antithetic_summary(values, exact):
    """First and second halves must be the two members of antithetic pairs."""
    n = len(values)//2
    paired = .5*(values[:n]+values[n:])
    estimate = float(paired.mean())
    se = float(paired.std(ddof=1)/np.sqrt(n))
    return dict(analytic=float(exact), estimate=estimate, standard_error=se,
                z_score=(estimate-float(exact))/se,
                error=estimate-float(exact),
                ci95=[estimate-1.96*se, estimate+1.96*se],
                antithetic_pairs=n, paths=2*n)


def one_date_options(model, n_pairs=200_000, seed=20260923):
    u, T, N, mwspread = 2., 7., 100., .012
    phi, gamma, covariance = model.augmented_transition(u)
    mean = phi @ np.r_[model.y0, 0., 0.] + gamma
    root = np.linalg.cholesky(covariance)
    rng = np.random.Generator(np.random.PCG64(seed))
    innovations = rng.standard_normal((n_pairs, 9)) @ root.T
    sample = np.concatenate([mean+innovations, mean-innovations], axis=0)
    Yu, ib, iz = sample[:, :7], sample[:, 7], sample[:, 8]
    pT = model.zcb(T)
    pu = model.zcb(u)
    fixed_redemption = N*pT/pu  # same contractual fixed amount for both securities
    tau = T-u
    treasury_remainder = model.zcb(tau, Yu, treasury=True)
    Rmw = N*np.exp(-mwspread*tau)*treasury_remainder
    rows, discount_checks = [], []
    for green, security in [(False, "Conventional"), (True, "Green")]:
        d = np.exp(-model.delta*u-ib+(iz if green else 0.))
        h = N*model.zcb(tau, Yu, green)
        pT, pu = model.zcb(T, green=green), model.zcb(u, green=green)
        bu = model.B(tau, green)
        v2 = float(bu @ covariance[:7, :7] @ bu)
        v = np.sqrt(v2)
        d1 = (np.log(N*pT/(fixed_redemption*pu))+.5*v2)/v
        fixed_exact = N*pT*ndtr(d1)-fixed_redemption*pu*ndtr(d1-v)
        fixed_payoff = d*np.maximum(h-fixed_redemption, 0.)
        row = dict(contract="Fixed price", security=security)
        row.update(antithetic_summary(fixed_payoff, fixed_exact))
        row["fixed_redemption"] = float(fixed_redemption)
        row["log_variance"] = v2
        rows.append(row)

        # Gaussian moment for E[D^bullet(0,u) R_MW(u)] under Q.
        loading = np.r_[-model.B(tau, treasury=True), -1., float(green)]
        log_constant = np.log(N)-mwspread*tau+model.A(tau, treasury=True)-model.delta*u
        discounted_R_mean = np.exp(log_constant+loading@mean+
                                   .5*loading@covariance@loading)
        abar, bbar = N*pT/pu, discounted_R_mean/pu
        difference = model.B(tau, green)-model.B(tau, treasury=True)
        vmw2 = float(difference@covariance[:7, :7]@difference)
        vmw = np.sqrt(vmw2)
        d1mw = (np.log(abar/bbar)+.5*vmw2)/vmw
        mw_exact = pu*(abar*ndtr(d1mw)-bbar*ndtr(d1mw-vmw))
        row = dict(contract="Make-whole, no floor", security=security)
        row.update(antithetic_summary(d*np.maximum(h-Rmw, 0.), mw_exact))
        row["log_variance"] = vmw2
        row["discounted_redemption_mean"] = float(discounted_R_mean)
        rows.append(row)
        dc = dict(security=security, horizon=u)
        dc.update(antithetic_summary(d, pu))
        discount_checks.append(dc)
    return dict(seed=seed, generator="NumPy PCG64", exercise_date=u, maturity=T,
                payment=N, make_whole_spread=mwspread, notice=0.,
                fixed_redemption=float(fixed_redemption),
                common_random_numbers=True, variance_reduction="antithetic pairs",
                rows=rows, discount_checks=discount_checks,
                augmented_covariance_min_eigenvalue=float(np.linalg.eigvalsh(covariance).min()))


def affine_checks(model):
    horizons = np.array([.01, .1, .5, 1., 2., 5., 7., 10.])
    rows = []
    for green, treasury, label in [(False, True, "Treasury"),
                                   (False, False, "Conventional"),
                                   (True, False, "Green")]:
        rho = model.rho(green, treasury)
        def riccati(_, state):
            b = state[:7]
            return np.r_[rho-model.K.T@b,
                         -b@(model.K@model.theta)+.5*b@model.Omega@b]
        sol = solve_ivp(riccati, (0., horizons[-1]), np.zeros(8),
                        t_eval=horizons, rtol=1e-11, atol=1e-13)
        berr = max(float(np.max(np.abs(sol.y[:7, j]-model.B(s, green, treasury))))
                   for j, s in enumerate(horizons))
        aerr = max(abs(float(sol.y[7, j])-model.A(s, green, treasury))
                   for j, s in enumerate(horizons))
        rows.append(dict(security=label, max_abs_B_error=berr, max_abs_A_error=aerr))
    moment_errors = []
    for s in horizons:
        phi, gamma, covariance = model.augmented_transition(float(s))
        mean = phi @ np.r_[model.y0, 0., 0.]+gamma
        for green in [False, True]:
            loading = np.r_[np.zeros(7), -1., float(green)]
            moment = np.exp(-model.delta*s+loading@mean+.5*loading@covariance@loading)
            moment_errors.append(abs(moment-model.zcb(float(s), green=green)))
    return dict(horizons=horizons.tolist(), riccati_comparison=rows,
                max_abs_augmented_moment_price_error=float(max(moment_errors)))


def straight_and_inversion(model):
    rows = []
    bump = 1e-6
    for maturity, coupon in [(5., .04), (10., .045)]:
        pb = float(model.coupon_bond(maturity, coupon))
        pg = float(model.coupon_bond(maturity, coupon, green=True))
        yp, ym = model.y0.copy(), model.y0.copy()
        yp[6] += bump
        ym[6] -= bump
        delta = float(model.coupon_delta(maturity, coupon))
        finite = float((model.coupon_bond(maturity, coupon, yp, True)-
                        model.coupon_bond(maturity, coupon, ym, True))/(2*bump))
        rows.append(dict(maturity=maturity, coupon=coupon, conventional_price=pb,
                         green_price=pg, green_delta_exact=delta,
                         green_delta_central_bump=finite, bump=bump,
                         delta_abs_error=abs(delta-finite)))
    maturity, coupon = 5., .04
    base = model.coupon_bond(maturity, coupon, green=True)
    inversion = []
    for residual in [-.10, 0., .10]:
        def price_at_z(z):
            y = model.y0.copy()
            y[6] = z
            return model.coupon_bond(maturity, coupon, y, True)
        target = float(base+residual)
        zstar = brentq(lambda z: price_at_z(z)-target, -.5, .5,
                      xtol=1e-14, rtol=1e-14)
        # Reproduce Newton iteration, using the exact monotone coupon loading.
        zn = float(model.y0[6])
        count = 0
        for count in range(1, 30):
            y = model.y0.copy(); y[6] = zn
            gap = model.coupon_bond(maturity, coupon, y, True)-target
            if abs(gap) < 1e-12:
                break
            zn -= gap/model.coupon_delta(maturity, coupon, y)
        inversion.append(dict(price_residual=residual, target_price=target,
                              implied_state=float(zstar), state_shift_bp=float((zstar-model.y0[6])*1e4),
                              price_reconstruction_error=float(price_at_z(zstar)-target),
                              newton_state=float(zn), newton_iterations=count,
                              newton_vs_brent_abs_error=abs(float(zn-zstar))))
    return dict(bonds=rows, inversion=dict(maturity=maturity, coupon=coupon,
                                          initial_green_state=float(model.y0[6]),
                                          rows=inversion))


def deterministic_counterexample():
    """Full semiannual coupon bond: current positive greenium, omega_G<omega_B."""
    r, q, N, z0, theta, mu = .04, .041, 100., .01, -.005, 1.
    T, u = 2., 1.
    dates = np.array([.5, 1., 1.5, 2.])
    amounts = np.array([N*q/2]*3+[N*(1+q/2)])
    def integrated_z(a, b):
        return theta*(b-a)+(z0-theta)*(np.exp(-mu*a)-np.exp(-mu*b))/mu
    def df(a, b, green):
        return np.exp(-r*(b-a)+(integrated_z(a,b) if green else 0.))
    rows=[]
    for green, name in [(False, "Conventional"), (True, "Green")]:
        straight0=sum(c*df(0., s, green) for s,c in zip(dates, amounts))
        remainder=sum(c*df(u, s, green) for s,c in zip(dates, amounts) if s>u)
        option=df(0.,u,green)*max(remainder-N, 0.)
        rows.append(dict(security=name, straight_price=float(straight0),
                         continuation_ex_coupon_at_call=float(remainder),
                         exercise=bool(remainder>N), option=float(option),
                         callable_price=float(straight0-option)))
    return dict(rate=r,coupon=q,notional=N,green_initial=z0,green_mean=theta,
                green_reversion=mu,maturity=T,call_date=u,redemption=N,
                notice=0.,coupon_dates=dates.tolist(),amounts=amounts.tolist(),
                integrated_green_0_T=float(integrated_z(0,T)),
                integrated_green_u_T=float(integrated_z(u,T)),rows=rows)


def latex_tables(results):
    lines=[r"% Generated by reproduce_benchmarks.py; do not edit numerical entries.",
           r"\begin{table}[t]",r"\centering\small",
           r"\caption{Single-date option benchmarks, with Monte Carlo uncertainty}",
           r"\label{tab:numerical-options}",
           r"\begin{tabular}{@{}llrrrr@{}}\toprule",
           r"Contract & Security & Analytic & Simulation & S.e. & $z$ \\",r"\midrule"]
    for row in results["single_date_options"]["rows"]:
        contract = "Fixed price" if row["contract"]=="Fixed price" else "Make-whole"
        lines.append(f"{contract} & {row['security']} & {row['analytic']:.6f} & {row['estimate']:.6f} & {row['standard_error']:.6f} & {row['z_score']:.2f} " + r"\\")
    lines += [r"\bottomrule\end{tabular}",r"\medskip",
              r"\parbox{0.95\textwidth}{\footnotesize All values are per 100 principal. There are 200,000 independent antithetic pairs (400,000 paths), generated with seed 20260923. The standardized discrepancy is $(\widehat\omega-\omega)/\operatorname{se}(\widehat\omega)$. Both securities use the same fixed redemption amount, equal to the conventional forward price. The make-whole benchmark has continuous compounding and no par floor.}",
              r"\end{table}","",
              r"\begin{table}[t]\centering\small",
              r"\caption{Straight-bond prices and sensitivity checks}",
              r"\label{tab:numerical-straight}",
              r"\begin{tabular}{@{}rrrrrr@{}}\toprule",
              r"Maturity & Coupon & Conventional & Green & Exact delta & Bump delta \\",r"\midrule"]
    for row in results["straight_and_inversion"]["bonds"]:
        lines.append(f"{row['maturity']:.0f} & {100*row['coupon']:.1f}\\% & {row['conventional_price']:.6f} & {row['green_price']:.6f} & {row['green_delta_exact']:.6f} & {row['green_delta_central_bump']:.6f} " + r"\\")
    lines += [r"\bottomrule\end{tabular}",r"\medskip",
              r"\parbox{0.95\textwidth}{\footnotesize Coupons are paid semiannually. Delta is the derivative with respect to the decimal green state; the central bump is $10^{-6}$.}",
              r"\end{table}","",
              r"\begin{table}[t]\centering\small",
              r"\caption{Exact inversion of a five-year green bond}",
              r"\label{tab:numerical-inversion}",
              r"\begin{tabular}{@{}rrrr@{}}\toprule",
              r"Price residual & Implied $z^*$ & State shift (bp) & Price error \\",r"\midrule"]
    for row in results["straight_and_inversion"]["inversion"]["rows"]:
        lines.append(f"{row['price_residual']:+.2f} & {row['implied_state']:.9f} & {row['state_shift_bp']:+.6f} & {row['price_reconstruction_error']:.1e} " + r"\\")
    lines += [r"\bottomrule\end{tabular}\end{table}"]
    if "onefactor_validation" in results:
        one = results["onefactor_validation"]
        lines += ["", r"\begin{table}[t]\centering\small",
                  r"\caption{One-factor callable-bond comparison}",
                  r"\label{tab:numerical-onefactor}",
                  r"\begin{tabular}{@{}lrr@{}}\toprule",
                  r"Method & Callable price & Evaluation s.e. \\", r"\midrule"]
        for row in one["deterministic"]:
            lines.append(f"Gaussian grid, {row['n_grid']:,} nodes & {row['callable_price']:.8f} & --- " + r"\\")
        for row in one["lsm"]:
            lines.append(f"LSM, degree {row['degree']} & {row['callable_cv']:.8f} & {row['callable_cv_se']:.8f} " + r"\\")
        lines += [r"\bottomrule\end{tabular}", r"\medskip",
                  r"\parbox{0.95\textwidth}{\footnotesize A five-year bond pays a 4.5 per cent semiannual coupon and may be called monthly from year two at par plus accrued. The short rate has initial value 0.034, mean 0.044, reversion 0.45 and volatility 0.009. LSM uses 80,000 training paths and 160,000 independent evaluation paths. Standard errors are conditional on the fitted policy and exclude policy-estimation uncertainty.}",
                  r"\end{table}"]
    return "\n".join(lines)+"\n"



# Independently coded one-factor discounted-Gaussian-grid and LSM benchmark.
from scipy.sparse import csr_matrix

VASICEK_PARAMS = dict(notional=100., coupon_rate=.045, maturity=5.,
              coupon_frequency=2, r0=.034, mu=.044, kappa=.45,
              sigma=.009, steps_per_year=12, first_call_year=2.,
              grid_x_min=-.12, grid_x_max=.12)


def vasicek_transition_moments(dt, p=VASICEK_PARAMS):
    k, sig = p['kappa'], p['sigma']
    a = np.exp(-k*dt)
    b = -np.expm1(-k*dt)/k
    var_x = sig**2 * (-np.expm1(-2*k*dt))/(2*k)
    var_i = sig**2/k**2*(dt-2*b+(-np.expm1(-2*k*dt))/(2*k))
    cov_xi = sig**2 * (1-a)**2 / (2*k**2)
    return a,b,var_x,var_i,cov_xi


def vasicek_zero_price(t, x, p=VASICEK_PARAMS):
    _,b,_,vi,_=vasicek_transition_moments(t,p)
    return np.exp(-p['mu']*t - b*np.asarray(x) + .5*vi)


def vasicek_schedule(p=VASICEK_PARAMS):
    N = round(p['maturity']*p['steps_per_year'])
    months_per_coupon = p['steps_per_year']//p['coupon_frequency']
    coupon = p['notional']*p['coupon_rate']/p['coupon_frequency']
    c = np.zeros(N+1)
    c[months_per_coupon::months_per_coupon] = coupon
    accrued = coupon*(np.arange(N+1)%months_per_coupon)/months_per_coupon
    redemption = p['notional']+accrued
    eligible = (np.arange(N+1)>=round(p['first_call_year']*p['steps_per_year']))
    eligible[-1] = False
    return N,c,redemption,eligible


def vasicek_straight_price(p=VASICEK_PARAMS):
    N,c,_,_=vasicek_schedule(p)
    times=np.arange(1,N+1)/p['steps_per_year']
    cash=c[1:].copy()
    cash[-1]+=p['notional']
    return float(cash@vasicek_zero_price(times, p['r0']-p['mu'],p))


def vasicek_transition_interpolant_matrix(x, dt, p=VASICEK_PARAMS, tail_sd=10.):
    """Positive expectation weights for piecewise-linear interpolation.

    Normal integrals on every grid interval are evaluated with CDF/PDF
    primitives, avoiding quadrature-order error.  Terms farther than
    tail_sd standard deviations are omitted (mass < 1.6e-23 at 10 sd).
    Outside the x domain, constant endpoint extrapolation is included.
    """
    a,b,vx,vi,cxi=vasicek_transition_moments(dt,p)
    s=np.sqrt(vx)
    h=x[1]-x[0]
    n=len(x)
    values=[]; indices=[]; indptr=[0]
    inv_sqrt_2pi=1/np.sqrt(2*np.pi)
    for xi in x:
        mean=a*xi-cxi
        j0=max(0, int(np.floor((mean-tail_sd*s-x[0])/h)))
        j1=min(n-2, int(np.ceil((mean+tail_sd*s-x[0])/h)))
        j=np.arange(j0,j1+1)
        lo=x[j]; hi=x[j+1]
        zl=(lo-mean)/s; zh=(hi-mean)/s
        # Right-tail evaluation avoids cancellation of 1-Phi(z).
        prob=np.where(zl>0, ndtr(-zl)-ndtr(-zh), ndtr(zh)-ndtr(zl))
        moment=s*inv_sqrt_2pi*(np.exp(-.5*zl*zl)-np.exp(-.5*zh*zh))
        left=((hi-mean)*prob-moment)/h
        right=((mean-lo)*prob+moment)/h
        w=np.zeros(len(j)+1)
        w[:-1]+=left; w[1:]+=right
        if j0==0: w[0]+=ndtr((x[0]-mean)/s)
        if j1==n-2: w[-1]+=ndtr((mean-x[-1])/s)
        if w.min() < -1e-12:
            raise ArithmeticError('Negative interpolation weight')
        w=np.maximum(w,0.)
        values.append(w)
        indices.append(np.arange(j0,j1+2,dtype=np.int32))
        indptr.append(indptr[-1]+len(w))
    mat=csr_matrix((np.concatenate(values), np.concatenate(indices),
                    np.asarray(indptr,dtype=np.int64)),shape=(n,n))
    discount=np.exp(-p['mu']*dt - b*x + .5*vi)
    row_mass=np.asarray(mat.sum(axis=1)).ravel()
    return mat,discount,float(np.max(np.abs(row_mass-1.)))


def vasicek_deterministic_price(n_grid, p=VASICEK_PARAMS):
    begin=time.time()
    N,c,R,eligible=vasicek_schedule(p)
    x=np.linspace(p['grid_x_min'],p['grid_x_max'],n_grid)
    dt=1/p['steps_per_year']
    mat,disc,mass_error=vasicek_transition_interpolant_matrix(x,dt,p)
    v=np.full(n_grid,p['notional']+c[N])
    v_straight=v.copy()
    thresholds={}
    for n in range(N-1,-1,-1):
        w=disc*(mat@v)
        v_straight=c[n]+disc*(mat@v_straight)
        if eligible[n]:
            exercise=w>R[n]
            if exercise.any() and (~exercise).any():
                # r boundary by interpolation of smooth continuation-R.
                j=np.flatnonzero(exercise)[-1]
                if j<n_grid-1:
                    thresholds[str(n)]=float(p['mu']+x[j]+(R[n]-w[j])*(x[j+1]-x[j])/(w[j+1]-w[j]))
            w=np.minimum(R[n],w)
        v=c[n]+w
    # Cubic interpolation only at initial point avoids a first-order root-grid issue.
    from scipy.interpolate import CubicSpline
    x0=p['r0']-p['mu']
    callable_p=float(CubicSpline(x,v)(x0))
    straight_grid=float(CubicSpline(x,v_straight)(x0))
    return dict(n_grid=n_grid, dx=float(x[1]-x[0]), callable_price=callable_p,
                option_value=vasicek_straight_price(p)-callable_p,
                straight_grid=straight_grid, straight_exact=vasicek_straight_price(p),
                straight_grid_error=straight_grid-vasicek_straight_price(p),
                max_row_mass_error=mass_error, first_call_boundary_r=thresholds.get('24'),
                elapsed_seconds=time.time()-begin, exercise_boundary=thresholds)


def vasicek_simulate_exact(n_paths, seed, p=VASICEK_PARAMS):
    N,_,_,_=vasicek_schedule(p)
    dt=1/p['steps_per_year']
    a,b,vx,vi,cxi=vasicek_transition_moments(dt,p)
    rng=np.random.default_rng(seed)
    x=np.empty((N+1,n_paths))
    discount=np.empty((N,n_paths))
    x[0]=p['r0']-p['mu']
    sd_x=np.sqrt(vx)
    loading_i=cxi/sd_x
    orth_i=np.sqrt(max(0.,vi-loading_i**2))
    for n in range(N):
        z=rng.standard_normal((2,n_paths))
        integral=p['mu']*dt+b*x[n]+loading_i*z[0]+orth_i*z[1]
        discount[n]=np.exp(-integral)
        x[n+1]=a*x[n]+sd_x*z[0]
    return x,discount


def vasicek_basis(x, degree):
    # Scaling is fixed ex ante; Chebyshev vasicek_basis avoids large raw-rate powers.
    return np.polynomial.chebyshev.chebvander(x/.025,degree)


def vasicek_remaining_straight(n,x,p=VASICEK_PARAMS):
    """Closed-form ex-coupon value of all strictly future promised payments."""
    N,c,_,_=vasicek_schedule(p)
    result=np.zeros_like(x)
    for j in range(n+1,N+1):
        payment=c[j]+(p['notional'] if j==N else 0.)
        if payment:
            result+=payment*vasicek_zero_price((j-n)/p['steps_per_year'],x,p)
    return result


def vasicek_train_lsm(x,disc,degree=4,p=VASICEK_PARAMS,continuation_cv=False):
    N,c,R,eligible=vasicek_schedule(p)
    v=np.full(x.shape[1],p['notional']+c[N])
    straight=v.copy()
    policies={}
    for n in range(N-1,-1,-1):
        y=disc[n]*v
        next_straight=disc[n]*straight
        if eligible[n]:
            design=vasicek_basis(x[n],degree)
            target=next_straight-y if continuation_cv else y
            coeff=np.linalg.lstsq(design,target,rcond=None)[0]
            policies[n]=coeff
            estimate=design@coeff
            if continuation_cv:
                h=vasicek_remaining_straight(n,x[n],p)
                estimate=h-np.clip(estimate,0.,h)
            y=np.where(estimate>R[n],R[n],y)
        v=c[n]+y
        straight=c[n]+next_straight
    return policies


def vasicek_evaluate_policy(x,disc,policies,p=VASICEK_PARAMS,continuation_cv=False):
    N,c,R,eligible=vasicek_schedule(p)
    v=np.full(x.shape[1],p['notional']+c[N])
    straight=v.copy()
    for n in range(N-1,-1,-1):
        y=disc[n]*v
        straight=c[n]+disc[n]*straight
        if eligible[n]:
            coeff=policies[n]
            estimate=vasicek_basis(x[n],len(coeff)-1)@coeff
            if continuation_cv:
                h=vasicek_remaining_straight(n,x[n],p)
                estimate=h-np.clip(estimate,0.,h)
            exercise=estimate>R[n]
            y=np.where(exercise,R[n],y)
        v=c[n]+y
    # CV coefficient exactly 1: option estimator is pathwise straight-callable.
    option=straight-v
    opt_mean=float(option.mean())
    opt_se=float(option.std(ddof=1)/np.sqrt(len(option)))
    exact=vasicek_straight_price(p)
    return dict(n_evaluation_paths=len(option), callable_raw=float(v.mean()),
        callable_raw_se=float(v.std(ddof=1)/np.sqrt(len(v))),
        straight_mc=float(straight.mean()),
        straight_mc_se=float(straight.std(ddof=1)/np.sqrt(len(straight))),
        straight_exact=exact, option_value_cv=opt_mean, option_value_se=opt_se,
        callable_cv=exact-opt_mean, callable_cv_se=opt_se,
        callable_cv_ci95=[exact-opt_mean-1.96*opt_se,exact-opt_mean+1.96*opt_se])



def onefactor_validation():
    output=dict(parameters=VASICEK_PARAMS,
        specification="One-factor Vasicek, 5-year 4.5% semiannual coupon, monthly call opportunities at months 24 through 59, par plus linear accrued, coupon paid first, zero notice.",
        deterministic=[], lsm=[],
        interpretation="Deterministic grid convergence is not a certified bound. LSM confidence intervals describe evaluation-path uncertainty conditional on the fitted policy, excluding training/policy uncertainty. An admissible issuer policy gives an upper bound on holder value in expectation, but a sample estimate need not be a bound.")
    for n in (3201, 6401, 12801):
        output["deterministic"].append(vasicek_deterministic_price(n))
    xt, dt = vasicek_simulate_exact(80000, 2026092301)
    policies = {degree: vasicek_train_lsm(xt, dt, degree) for degree in (4, 5)}
    del xt, dt
    xe, de = vasicek_simulate_exact(160000, 2026092302)
    reference = output["deterministic"][-1]["callable_price"]
    for degree, policy in policies.items():
        row = vasicek_evaluate_policy(xe, de, policy)
        row.update(degree=degree, n_training_paths=80000, training_seed=2026092301,
                   evaluation_seed=2026092302, reference=reference,
                   discrepancy_over_evaluation_se=(row["callable_cv"]-reference)/row["callable_cv_se"])
        output["lsm"].append(row)
    output["last_grid_refinement_change"] = output["deterministic"][-1]["callable_price"] - output["deterministic"][-2]["callable_price"]
    return output


def main():
    started=time.perf_counter()
    model=GaussianModel()
    results=dict(manifest=model.manifest(),
                 numerical_environment=dict(python=platform.python_version(),
                                             numpy=np.__version__,scipy=scipy.__version__,
                                             blas_threads=1),
                 affine_checks=affine_checks(model),
                 single_date_options=one_date_options(model),
                 straight_and_inversion=straight_and_inversion(model),
                 deterministic_counterexample=deterministic_counterexample())
    results["onefactor_validation"] = onefactor_validation()
    results["runtime_seconds"]=time.perf_counter()-started
    results["reproduction_script_sha256"]=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    out=Path(__file__).resolve().parent
    (out/"results.json").write_text(json.dumps(results,indent=2)+"\n")
    (out/"numerical_table.tex").write_text(latex_tables(results))
    print(json.dumps(dict(runtime_seconds=results["runtime_seconds"],
                          analytic_checks=results["affine_checks"],
                          option_rows=results["single_date_options"]["rows"],
                          straight_checks=results["straight_and_inversion"],
                          counterexample=results["deterministic_counterexample"]),indent=2))


if __name__ == "__main__":
    main()
