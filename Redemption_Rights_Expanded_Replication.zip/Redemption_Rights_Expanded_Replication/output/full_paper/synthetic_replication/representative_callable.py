#!/usr/bin/env python3
"""Reproduce the synthetic seven-factor callable-coupon illustration.

This is a zero-notice, monthly-decision illustration, not a reconstructed
security. The Treasury benchmark is explicitly synthetic. All contractual
cash-flow conventions are specified here. Reported sampling uncertainty is
conditional on a separately trained regression policy, and does not bound
policy, basis, or exercise-grid error.

Run next to reproduce_benchmarks.py:
    OPENBLAS_NUM_THREADS=1 python representative_callable.py
"""
import os
for _thread_variable in ("OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "OMP_NUM_THREADS"):
    os.environ[_thread_variable] = "1"
import argparse
from pathlib import Path
import json
import csv
import time
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from reproduce_benchmarks import GaussianModel

N = 100.0
COUPON_RATE = .045
T = 10.0
PAR_DATE = 9.75
MW_SPREAD = .002
NOMINAL_BENCHMARK_FLOOR = -1.99
HBAR = 4.0
SIGMA_M = .01
GRID = np.arange(121, dtype=float) / 12
CF_TIMES = np.arange(.5, T + .01, .5)
CF_AMOUNTS = np.full(len(CF_TIMES), N * COUPON_RATE / 2)
CF_AMOUNTS[-1] += N
MW_TIMES = np.r_[np.arange(.5, PAR_DATE, .5), PAR_DATE]
MW_AMOUNTS = np.r_[np.full(len(MW_TIMES)-1, N*COUPON_RATE/2),
                    N + N*COUPON_RATE*(PAR_DATE-MW_TIMES[-2])]
COUPONS = np.zeros(len(GRID))
COUPONS[np.rint(CF_TIMES*12).astype(int)] = N*COUPON_RATE/2


def simulate(model, paths, seed):
    """Exact jointly Gaussian state and integrated conventional/green rates."""
    Phi, gamma, Q = model.augmented_transition(1/12)
    Q = (Q+Q.T)/2
    vals, vecs = np.linalg.eigh(Q)
    if vals.min() < -1e-14:
        raise RuntimeError("Transition covariance is not nonnegative")
    root = vecs @ np.diag(np.sqrt(np.maximum(vals, 0)))
    rng = np.random.default_rng(seed)
    x = np.zeros((paths, len(GRID), 9))
    x[:, 0, :7] = model.y0
    for n in range(1, len(GRID)):
        x[:, n] = x[:, n-1] @ Phi.T + gamma + rng.standard_normal((paths, 9)) @ root.T
    return x


def coefficients(model, horizons, green=False, treasury=False):
    b = np.stack([model.B(float(u), green=green, treasury=treasury) for u in horizons])
    a = np.array([model.A(float(u), green=green, treasury=treasury) for u in horizons])
    if not treasury:
        a = a-model.delta*np.asarray(horizons)
    return a, b


def schedules_and_values(model, paths, green=False):
    """Exact ex-coupon straight value and dirty redemption on every node.

    Coupons at a decision date are paid before the decision. The ordinary
    bond continues to have semiannual coupons through year ten. Before the
    par-call date, make-whole calculation uses a hypothetical terminal
    principal plus prorated stub coupon at year 9.75. Accrued interest is
    counted once: R_dirty=max(N+AI, PV_full_scheduled). Treasury par reference
    uses the current remaining payment dates, actual first/final accruals,
    and the model Treasury discount factors. It is not claimed to reproduce
    an H.15 prospectus benchmark.
    """
    count = len(paths)
    H = np.zeros((count, len(GRID)))
    R = np.full_like(H, N)
    domain_stats = {"state_node_evaluations": 0, "floor_activations": 0,
                    "minimum_unfloored_total_nominal_benchmark": float("inf"),
                    "total_nominal_benchmark_floor": NOMINAL_BENCHMARK_FLOOR}
    H[:, -1] = N
    for n, t in enumerate(GRID[:-1]):
        y = paths[:, n, :7]
        keep = CF_TIMES > t+1e-10
        tau = CF_TIMES[keep]-t
        a, b = coefficients(model, tau, green=green)
        H[:, n] = np.exp(a[None, :] - y @ b.T) @ CF_AMOUNTS[keep]
        since_coupon = t-.5*np.floor((t+1e-10)/.5)
        accrued = N*COUPON_RATE*max(0.0, since_coupon)
        if t >= PAR_DATE-1e-10:
            R[:, n] = N+accrued
        else:
            keepmw = MW_TIMES > t+1e-10
            mw_tau = MW_TIMES[keepmw]-t
            accruals = np.diff(np.r_[0., mw_tau])
            at, bt = coefficients(model, mw_tau, treasury=True)
            pt = np.exp(at[None, :] - y @ bt.T)
            ref_yield = (1-pt[:, -1])/(pt@accruals)
            total_nominal = ref_yield+MW_SPREAD
            domain_stats["state_node_evaluations"] += len(total_nominal)
            domain_stats["floor_activations"] += int(np.count_nonzero(total_nominal < NOMINAL_BENCHMARK_FLOOR))
            domain_stats["minimum_unfloored_total_nominal_benchmark"] = min(
                domain_stats["minimum_unfloored_total_nominal_benchmark"], float(total_nominal.min()))
            # Global extension only for the synthetic benchmark. This is not
            # an asserted term of any market contract; it keeps the nominal
            # semiannual discount base positive on every Gaussian state.
            half_yield = np.maximum(total_nominal, NOMINAL_BENCHMARK_FLOOR)/2
            mw_discount = np.exp(-2*mw_tau[None, :]*np.log1p(half_yield[:, None]))
            mw_pv = mw_discount @ MW_AMOUNTS[keepmw]
            R[:, n] = np.maximum(N+accrued, mw_pv)
    return H, R, domain_stats


def features(y, h, r):
    m = (h-r)/N
    return np.column_stack((m, r/N, m*m, y[:,0]+y[:,1],
                            y[:,3]+y[:,4], y[:,6]))


def fit(features_, target):
    center = features_.mean(axis=0)
    scale = features_.std(axis=0)
    scale[scale < 1e-12] = 1
    a = np.column_stack((np.ones(len(target)), (features_-center)/scale))
    coef = np.linalg.lstsq(a, target, rcond=1e-10)[0]
    return center, scale, coef


def predict(spec, f):
    center, scale, coef = spec
    return coef[0]+((f-center)/scale)@coef[1:]


def probability(moneyness, policy, dt):
    if policy == "frictionless":
        return (moneyness>0).astype(float)
    positive = np.maximum(moneyness, 0)
    rate = HBAR*positive**2/(SIGMA_M**2+positive**2)
    return -np.expm1(-rate*dt)


def discount_array(model, paths, green):
    exponent = -model.delta*GRID[None, :]-paths[:, :, 7]
    if green:
        exponent = exponent+paths[:, :, 8]
    return np.exp(exponent)


def train(model, paths, H, R, green, policy):
    """Fit continuation using exact straight value as conditional control.

    Regression target is discounted future option payoff. The identity
    O_n=p_n(H_n-R_n)+(1-p_n)E[D(n,n+1)O_{n+1}|Y_n]
    integrates the future straight cash flows analytically. The resulting
    bond continuation is H minus the predicted conditional option value.
    Capping predicted option loss to [0,H] ensures 0 <= W_hat <= H.
    The ITM set is H>R and the basis includes H through R+N*m.
    """
    D = discount_array(model, paths, green)
    option = np.zeros(len(paths))
    fits = [None]*(len(GRID)-1)
    for n in range(len(GRID)-2, -1, -1):
        step = D[:, n+1]/D[:, n]
        target = step*option
        itm = H[:, n]>R[:, n]
        p = np.zeros(len(paths))
        if np.any(itm):
            f = features(paths[itm,n,:7], H[itm,n], R[itm,n])
            fits[n] = fit(f, target[itm])
            loss = np.clip(predict(fits[n], f), 0, H[itm,n])
            continuation = H[itm,n]-loss
            p[itm] = probability((continuation-R[itm,n])/N, policy, GRID[n+1]-GRID[n])
        option = p*(H[:,n]-R[:,n])+(1-p)*target
    return fits


def evaluate(model, paths, H, R, green, policy, fits):
    """Independent-policy valuation with straight-price control variate."""
    D = discount_array(model, paths, green)
    survival = np.ones(len(paths))
    payoff = np.zeros(len(paths))
    straight_payoff = (D*COUPONS[None,:]).sum(axis=1)+N*D[:,-1]
    ell = (1-np.exp(-model.muZ*GRID))/model.muZ
    direct_payoff = np.zeros(len(paths))
    straight_direct = (D*(COUPONS*ell)[None,:]).sum(axis=1)+N*D[:,-1]*ell[-1]
    exercise_mass = np.zeros(len(GRID))
    exercise_time = np.zeros(len(paths))
    option_given_path = np.zeros(len(paths))
    for n, t in enumerate(GRID[:-1]):
        p = np.zeros(len(paths))
        itm = H[:,n]>R[:,n]
        if fits[n] is not None and np.any(itm):
            f = features(paths[itm,n,:7],H[itm,n],R[itm,n])
            loss = np.clip(predict(fits[n], f),0,H[itm,n])
            continuation = H[itm,n]-loss
            p[itm] = probability((continuation-R[itm,n])/N, policy, GRID[n+1]-t)
        coupon_payment = survival*D[:,n]*COUPONS[n]
        redemption_payment = survival*p*D[:,n]*R[:,n]
        option_given_path += survival*p*D[:,n]*(H[:,n]-R[:,n])
        payoff += coupon_payment+redemption_payment
        direct_payoff += ell[n]*(coupon_payment+redemption_payment)
        exercise_mass[n] = np.mean(survival*p)
        exercise_time += t*survival*p
        survival *= 1-p
    payoff += survival*D[:,-1]*(COUPONS[-1]+N)
    direct_payoff += ell[-1]*survival*D[:,-1]*(COUPONS[-1]+N)
    exercise_mass[-1] = np.mean(survival)
    exercise_time += T*survival
    raw_option = straight_payoff-payoff
    identity_difference = raw_option-option_given_path
    option = np.mean(option_given_path)
    option_se = np.std(option_given_path, ddof=1)/np.sqrt(len(paths))
    straight = float(H[0,0])
    h_direct = 0.
    if green:
        h_direct = float(np.sum(CF_AMOUNTS*np.array([
            model.zcb(float(u), green=True) for u in CF_TIMES])*((1-np.exp(-model.muZ*CF_TIMES))/model.muZ)))
    direct = h_direct-np.mean(straight_direct-direct_payoff) if green else None
    direct_se = np.std(straight_direct-direct_payoff,ddof=1)/np.sqrt(len(paths)) if green else None
    return {
        "security": "green" if green else "conventional",
        "exercise_rule":policy, "straight_price":straight,
        "callable_price":straight-float(option), "option_value":float(option),
        "option_mc_se":float(option_se),
        "option_mc_ci95_low":float(option-1.96*option_se),
        "option_mc_ci95_high":float(option+1.96*option_se),
        "raw_control_option_value":float(raw_option.mean()),
        "raw_minus_conditional_control_difference":float(identity_difference.mean()),
        "raw_minus_conditional_control_difference_se":float(identity_difference.std(ddof=1)/np.sqrt(len(paths))),
        "probability_call_before_maturity":float(exercise_mass[:-1].sum()),
        "probability_makewhole_call":float(exercise_mass[GRID<PAR_DATE-1e-10].sum()),
        "probability_par_call":float(exercise_mass[(GRID>=PAR_DATE-1e-10)&(GRID<T-1e-10)].sum()),
        "expected_redemption_year":float(exercise_time.mean()),
        "expected_redemption_mc_se":float(exercise_time.std(ddof=1)/np.sqrt(len(paths))),
        "straight_green_loading":h_direct if green else None,
        "direct_cashflow_loading":float(direct) if green else None,
        "direct_loading_mc_se":float(direct_se) if green else None,
        "exercise_mass":exercise_mass.tolist(),
        "notes":"Pricing-measure probabilities. Sampling errors condition on fitted policy; direct loading excludes exercise-probability response.",
    }


def plot_results(results, out, tag="representative"):
    """Plot at approximately the paper text width so labels remain legible."""
    plt.rcParams.update({"font.family":"DejaVu Sans","font.size":9,"axes.spines.top":False,"axes.spines.right":False})
    fig,axs=plt.subplots(1,2,figsize=(6.5,3.15),constrained_layout=True)
    colors={"green":"#007f5f","conventional":"#3a4e75"}
    for result in results:
        key=result["security"]
        style="-" if result["exercise_rule"]=="frictionless" else "--"
        label=key.capitalize()+", "+result["exercise_rule"]
        cum=np.cumsum(result["exercise_mass"]);cum[-1]=cum[-2]
        for ax in axs:
            ax.step(GRID,cum*100,where="post",color=colors[key],linestyle=style,label=label)
    axs[0].set_xlim(0,10);axs[1].set_xlim(9.45,10)
    axs[0].set_title("Calls over the remaining life", fontsize=8.5)
    axs[1].set_title("Final par-call window", fontsize=8.5)
    for ax in axs:
        ax.set_xlabel("Years from valuation");ax.set_ylabel("Cumulative call probability (%)")
        ax.grid(alpha=.18);ax.axvline(PAR_DATE,color=".5",linestyle=":",linewidth=1)
    axs[0].legend(loc="upper left",fontsize=7.5,frameon=False)
    fig.savefig(out/(tag+"_exercise_probability.png"),dpi=250)
    fig.savefig(out/(tag+"_exercise_probability.pdf"))
    plt.close(fig)


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--train",type=int,default=32768)
    ap.add_argument("--test",type=int,default=131072)
    ap.add_argument("--train-seed",type=int,default=9231201)
    ap.add_argument("--test-seed",type=int,default=9231202)
    ap.add_argument("--tag",default="representative")
    args=ap.parse_args()
    out=Path(__file__).resolve().parent
    start=time.time()
    model=GaussianModel()
    train_paths=simulate(model,args.train,args.train_seed)
    test_paths=simulate(model,args.test,args.test_seed)
    print("Paths generated",round(time.time()-start,2),flush=True)
    results=[]
    domain_checks={}
    for green in (False,True):
        Htrain,Rtrain,domain_train=schedules_and_values(model,train_paths,green)
        Htest,Rtest,domain_test=schedules_and_values(model,test_paths,green)
        domain_checks["green" if green else "conventional"] = {
            "training":domain_train, "evaluation":domain_test}
        print("Cash-flow values generated",green,round(time.time()-start,2),flush=True)
        for policy in ("frictionless","intensity"):
            fits=train(model,train_paths,Htrain,Rtrain,green,policy)
            result=evaluate(model,test_paths,Htest,Rtest,green,policy,fits)
            results.append(result)
            print(result["security"],policy,"option",result["option_value"],"se",result["option_mc_se"],"Etime",result["expected_redemption_year"],flush=True)
    metadata={
        "model":{"initial_state":model.y0.tolist(),"K":model.K.tolist(),
                 "theta":model.theta.tolist(),"Omega":model.Omega.tolist(),"issuer_effect":model.delta},
        "contract":{"notional":N,"annual_coupon_rate":COUPON_RATE,"maturity":T,
                    "coupon_dates":CF_TIMES.tolist(),"call_decisions":"monthly, after any coupon at same date",
                    "notice_years":0,"par_call_date":PAR_DATE,"makewhole_spread":MW_SPREAD,
                    "makewhole_cashflows":{"times":MW_TIMES.tolist(),"amounts":MW_AMOUNTS.tolist()},
                    "makewhole_reference":"synthetic model Treasury par rate on remaining actual stub accruals",
                    "benchmark_domain_extension":"floor total nominal benchmark (reference yield plus makewhole spread) at -1.99 before semiannual compounding; synthetic numerical extension, not an observed contract term",
                    "dirty_redemption":"max(notional+accrued_interest,present_value_of_full_scheduled_makewhole_cashflows)"},
        "numerics":{"train_paths":args.train,"test_paths":args.test,"train_seed":args.train_seed,
                    "test_seed":args.test_seed,"grid":GRID.tolist(),"hbar":HBAR,"moneyness_scale":SIGMA_M,
                    "basis":["1","m","R/N","m^2","L+S","LF+SF","Z"],
                    "continuation_regression":"discounted future option payoff; OLS on ITM training paths; exercise reward is exact H-R",
                    "option_payoff":"sum_n survival_n*p_n*D(0,n)*(H_n-R_n); future straight cashflows integrated analytically",
                    "uncertainty":"independent-test Monte Carlo standard errors conditional on trained policy; no policy-error bound",
                    "runtime_seconds":time.time()-start},
        "benchmark_domain_checks":domain_checks,
        "results":results,
    }
    (out/(args.tag+"_results.json")).write_text(json.dumps(metadata,indent=2))
    keys=[k for k in results[0] if k not in ("exercise_mass","notes")]
    with (out/(args.tag+"_results.csv")).open("w",newline="") as f:
        w=csv.DictWriter(f,fieldnames=keys);w.writeheader()
        for result in results:w.writerow({k:result[k] for k in keys})
    plot_results(results, out, args.tag)
    print("Wrote results and exercise plot",round(time.time()-start,2),flush=True)


if __name__=="__main__":main()
