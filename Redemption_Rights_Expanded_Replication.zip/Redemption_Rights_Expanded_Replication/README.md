# Redemption Rights and the Greenium
## Full manuscript and expanded empirical replication

This package preserves the revised manuscript, its bibliography and publication figures, the retained synthetic experiments, and the completed issuer-level and monthly empirical outputs. It contains the frozen inputs needed by the supplied calculations. It does not connect to FactSet or use account credentials.

The internal relative directories are intentional. Several original modules find their companion files from their own location. Keep the directory structure intact and run the commands below from the top-level `Redemption_Rights_Expanded_Replication` folder.

## Environment

The recorded calculation used CPython 3.12.14 on Linux x86-64, NumPy 2.3.5, SciPy 1.17.0, pandas 2.2.3 and matplotlib 3.10.8. `replication_environment.json` records the full relevant dependency versions; `requirements-replication.txt` supplies pinned packages. A clean environment can be prepared with:

```bash
python3.12 -m venv .venv
. .venv/bin/activate
python -m pip install -r requirements-replication.txt
```

A TeX installation with `pdflatex`, `bibtex` and the packages requested by the manuscript is needed only to rebuild the PDF. The archived compiled PDF and figures can be read without TeX.

The stochastic engines pin common BLAS thread counts to one. Seeds, simulation counts, fixing draws, notice spacing, tolerances, input hashes and fitted coefficients are archived. Numerical optimizers and regression linear algebra can differ slightly across operating systems or BLAS implementations. The declared simulation uncertainty conditions on the fitted inputs and trained policy.

## Inspect the saved evidence first

The principal manuscript, bibliography and figures are under `output/expanded_master`. The associated `data` directory contains all actual-bond prices and price components, issuer fitting diagnostics, Treasury/credit/green zero curves, matched comparisons and reconciliation checks.

The contractual pricing branches are separately archived under `tmp/expansion/pricing/results` and `results_expanded`. Each issuer has its own fit results, price table, zero curves and paired simulation samples. The expanded branch overrides the affected issuer curves; it must not be added to the baseline as independent duplicate observations.

The monthly pre-option results are under `tmp/expansion/benchmarks`; `baseline` preserves the earlier benchmark sample. These monthly calculations use the dated GSW initial curve and each bond's cashflow schedule. They do not estimate monthly optionality or a filtered stochastic green state. The dated contractual AFNS++ exercise is a separate calculation.

`tmp/expansion/contracts` holds the normalized added contracts, source URL/checksum manifests and field-level evidence. Legal issuer, security class, maturity support, notice/fixing rules and unresolved conventions remain explicit. The evidence notes identify the original 1988/1998/2005/2006 NSP sources, including the noncallable 2028 conventional bond.

`tmp/expansion/inventory/final` contains the complete 20,106-code source-universe verification ledger, the 119-record contract register ledger, the 98-contract latest pricing scope, issuer coverage and the remaining unreviewed queues. The full-universe files record review status and coverage; they are distinct from the excluded broad raw vendor-price history. The frozen pre-extension metadata ledger and final merged normalized register are also retained as inputs to `build_final_inventory.py`.

`tmp/expansion/manuscript` preserves the merged theoretical source, empirical template, merge notes and differences, bibliography and source-generation helper. `tmp/expansion/reporting/review` contains the independent empirical reconciliations and the minimum-notice lemma and signed-green-ordering corollary inserted by the master builder. The user's uploaded `upload/Redemption_Rights_AFNS_Framework_September_25_2026_rev5.tex` is retained unchanged as a source reference, alongside the prior master and bibliography used in the documented merge. Their hashes are recorded in the manifest.

## Reproduce the calculations

A quick relocation check loads both contract/quote sets and their Treasury curve without refitting or generating paths:

```bash
python tmp/expansion/reporting/verify_portable_inputs.py
```

`replication_commands.json` is the finalized input/branch manifest. The wrapper below expands it into explicit command-line arguments, with frozen simulation settings. Display the complete command sequence without running it:

```bash
python tmp/expansion/reporting/reproduce_expansion.py --plan
```

Use a new, empty run directory to recompute the calculations while preserving archived outputs. The default is `tmp/reproduction`. A different run directory can be selected with `--run-root` on each command.

```bash
python tmp/expansion/reporting/reproduce_expansion.py --step baseline
python tmp/expansion/reporting/reproduce_expansion.py --step expanded
python tmp/expansion/reporting/reproduce_expansion.py --step monthly
python tmp/expansion/reporting/reproduce_expansion.py --step postprocess
python tmp/expansion/reporting/reproduce_expansion.py --step figures
```

Equivalently, `python tmp/expansion/reporting/reproduce_expansion.py --step all` runs those steps in order. `--workers 1` lowers simultaneous memory demand. Preparation of long contractual notice grids is computationally substantial. Intermediate pickle caches are generated locally during reproduction; they are not distributed in this archive.

For reference, the baseline driver can also be run directly:

```bash
python tmp/expansion/pricing/run_expanded_batch.py \
  --register restored/Zero_Coupon_Greenium_Data_and_Code/inventory/inputs/comparison/results/normalized_contracts.json \
  --prices restored/Zero_Coupon_Greenium_Data_and_Code/inventory/inputs/comparison/results/bond_month_values.csv \
  --month 2026-08-31 --workers 3 --train 768 --evaluation 2304 \
  --qmc-power 5 --seed 20261003 --step-days 30 --maxiter 45 \
  --out tmp/reproduction/baseline
python tmp/expansion/pricing/append_exact_inversions.py \
  --out tmp/reproduction/baseline
```

The expanded original-term branch runs the scenario driver against that completed baseline:

```bash
python tmp/expansion/pricing/run_expanded_scenario.py \
  --base-results tmp/reproduction/baseline \
  --register tmp/expansion/pricing/scenario_inputs/normalized_contracts_expanded_literal.json \
  --prices tmp/expansion/benchmarks/inputs/bond_month_values_final.csv \
  --out tmp/reproduction/expanded
```

It reuses unchanged baseline preparation, prepares new or changed contracts, refits MidAmerican, DTE Electric and NSP-Minnesota, copies the unchanged issuer results and performs the conditional exact inversions. Its output is the complete expanded branch.

The direct drivers resume a run when complete preparation caches or issuer outputs already exist. Keep the input contract interpretation, numerical settings and curve files unchanged within a resumable run. To compare a changed specification, choose a separate output directory.

For monthly reproduction the wrapper copies the monthly scripts and compact `inputs/replication` subset into `tmp/reproduction/monthly_baseline` and `tmp/reproduction/monthly`. It first reruns the original monthly sample without the extra contracts, then the expanded sample and its comparison:

```bash
python tmp/reproduction/monthly_baseline/run_monthly.py
python tmp/reproduction/monthly_baseline/summarize_monthly.py
python tmp/reproduction/monthly/run_monthly.py \
  --extra-contracts tmp/reproduction/monthly/inputs/replication/extra_contracts.json
python tmp/reproduction/monthly/summarize_monthly.py
```

The wrapper then copies the regenerated baseline comparison tables into the expanded run’s `baseline` directory and runs `python tmp/reproduction/monthly/compare_anchor_results.py`.

The runner uses the compact local input set automatically. The original broad vendor download is not needed. Price values in this subset are unchanged; the transformation only retains the relevant identifiers and columns. Source and subset hashes are recorded in `source_provenance.json`.

Postprocessing reconciles the price-component identity and the zero-to-coupon/matched-yield decompositions and writes new tables under `tmp/reproduction/report/data`. Figures are rendered from those tables into `tmp/reproduction/report/figures`. The saved final outputs under `output/expanded_master` remain available for comparison.

## Rebuild the paper and synthetic tables

The final paper can be rebuilt from the archived completed pricing and monthly outputs without repeating the Monte Carlo calculation. From the package root, run:

```bash
python tmp/expansion/reporting/build_empirical_outputs.py \
  --pricing tmp/expansion/pricing/results_expanded \
  --monthly tmp/expansion/benchmarks \
  --out output/expanded_master/data
python tmp/expansion/reporting/plot_expansion.py \
  --data output/expanded_master/data \
  --monthly tmp/expansion/benchmarks \
  --out output/expanded_master/figures
python tmp/expansion/reporting/assemble_master.py
```

The assembly command reads `tmp/expansion/manuscript/merged_base.tex`, `empirical_expanded_template.tex`, the two review inserts and the final empirical tables. It writes `output/expanded_master/Redemption_Rights_AFNS_Master_rev6.tex` and `output/expanded_master/data/Manuscript_Build_Checks.json`. These commands regenerate the archived report locations; the separate numerical reproduction wrapper above writes its calculation outputs under `tmp/reproduction`.

From `output/expanded_master`, compile the completed master with:

```bash
pdflatex -interaction=nonstopmode Redemption_Rights_AFNS_Master_rev6.tex
bibtex Redemption_Rights_AFNS_Master_rev6
pdflatex -interaction=nonstopmode Redemption_Rights_AFNS_Master_rev6.tex
pdflatex -interaction=nonstopmode Redemption_Rights_AFNS_Master_rev6.tex
```

The original verified literature evidence is retained under `output/full_paper/literature_verification`. The historical merge helper and merge notes document the source history; rebuilding the final master uses the supplied `merged_base.tex` directly.

The synthetic calculations are retained under `output/full_paper/synthetic_replication`. To reproduce them into a separate directory:

```bash
mkdir -p tmp/reproduction/synthetic
cp output/full_paper/synthetic_replication/*.py tmp/reproduction/synthetic/
python tmp/reproduction/synthetic/reproduce_benchmarks.py
python tmp/reproduction/synthetic/representative_callable.py \
  --train 32768 --test 131072 --train-seed 9231201 --test-seed 9231202
python tmp/reproduction/synthetic/greenium_decomposition.py
```

Their mean-reverting synthetic credit illustration is distinct from the driftless deterministic credit-level specification of the expanded conditional empirical exercise.

## Provenance, conventions and data rights

The original commercial price observations were supplied through the user's FactSet research workflow. The package grants no new rights in those observations; use and redistribution remain governed by the rights already applicable to the source data. The archived code does not require a live FactSet request. The precise evaluated/traded side and clean/dirty metadata of `P_PRICE` remain unverified, so the main clean-price interpretation and the dirty-price sensitivity retain their stated status.

Treasury inputs are the supplied Gürkaynak–Sack–Wright curve data and H.15 observations. Contract evidence comes from the cited SEC issuer filings and identified supporting disclosures. The data/source manifests give the original locations and hashes. Contract details such as dealer benchmarks represented by a model par-yield proxy, incomplete notice sets, older accrued-interest wording and payment-calendar conventions remain model/input restrictions in the calculations.

`REPLICATION_MANIFEST.json` lists every selected source file, purpose and hash. Preparation pickles, bytecode, connector transfer helpers, credential files, build intermediates and the broad raw 20,106-code vendor-price dump are excluded. `run_configuration.original.json` preserves each original execution record; the companion `run_configuration.json` changes only workspace prefixes in paths to make the archive portable. `MANIFEST.sha256` verifies the delivered bytes.

## Original public documents

The archive retains normalized contractual facts, evidence notes, primary-source URLs and retrieval checksums. Full third-party annual reports, prospectuses and downloaded HTML/text copies are kept outside the distribution. Pricing and monthly replication use the supplied normalized records and do not require these complete source documents. Optional source-audit builders may require retrieving the original URLs before rerunning that separate verification step.
