#!/usr/bin/env python3
"""Check relocated dependencies and frozen input coverage without fitting prices."""
from pathlib import Path
import importlib.util
import json
import os
import sys
ROOT=Path(__file__).resolve().parents[3]
os.chdir(ROOT)
sys.path.insert(0,str(ROOT/'tmp/expansion/pricing'))
from expansion_data import load_inputs
from treasury_curves import TreasuryCurve
spec=json.loads((Path(__file__).parent/'replication_commands.json').read_text())
output={}
for name in ['base','expanded']:
    parsed=load_inputs(ROOT/spec[name+'_register'],ROOT/spec[name+'_prices'],spec['valuation_month'],holdout_codes=('92343VGK',))
    frame=parsed['observations']
    output[name]={'contracts':len(frame),'issuers':int(frame.issuer.nunique()),'green':int(frame.is_green.sum()) if 'is_green' in frame else len(parsed['green_codes']),'excluded':len(parsed['exclusions'])}
    if frame.code.duplicated().any():raise ValueError('Duplicate included code')
curve=TreasuryCurve(spec['valuation_month'],'gsw_svensson',ROOT/'tmp/paper_pricing/engine/treasury/results/curve_parameters.json')
output['treasury_ten_year_zero']=float(curve.zero(10.0))
module_path=ROOT/'tmp/expansion/benchmarks/run_monthly.py'
ms=importlib.util.spec_from_file_location('portable_monthly_module',module_path);module=importlib.util.module_from_spec(ms);ms.loader.exec_module(module)
assert module.COMPARISON==ROOT/'tmp/expansion/benchmarks/inputs/replication'
for p in [module.GSW_FILE,module.RAW_FILE,module.COMPARISON/'bond_month_values.csv',module.COMPARISON/'extra_contracts.json']:
    if not p.is_file():raise FileNotFoundError(p)
output['monthly_uses_compact_local_inputs']=True
print(json.dumps(output,indent=2))
