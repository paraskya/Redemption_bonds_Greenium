"""Merge audited theory with the completed, expanded empirical calculation."""
from pathlib import Path
import json,re
import numpy as np
import pandas as pd
from plot_expansion import SHORT

ROOT=Path(__file__).resolve().parents[3];OUT=ROOT/'output/expanded_master';DATA=OUT/'data'
MON=ROOT/'tmp/expansion/benchmarks';MAN=ROOT/'tmp/expansion/manuscript'

def num(x,d=2):return f'{float(x):.{d}f}'
def signed(x,d=2):return f'{float(x):+.{d}f}'
def tex(s):return str(s).replace('&',r'\&').replace('_',r'\_').replace('%',r'\%')
def sci(x):
 if abs(x)<1e-100:return 'zero'
 a,b=f'{x:.1e}'.split('e');return '$'+a+r'\times10^{'+str(int(b))+'}$'
def table(caption,label,cols,head,rows,note):
 return '\n'.join([r'\begin{table}[htbp]',r'\centering\small',r'\caption{'+caption+'}',r'\label{'+label+'}',
  r'\setlength{\tabcolsep}{4pt}',r'\begin{tabular}{@{}'+cols+r'@{}}\toprule',head+r' \\',r'\midrule',
  *[r' & '.join(map(str,row))+r' \\' for row in rows],r'\bottomrule',r'\end{tabular}',r'\medskip',
  r'\parbox{\textwidth}{\footnotesize '+note+'}',r'\end{table}'])

def grouped_longtable(p,kind='green'):
 green=kind=='green'
 caption='Green contracts, implied zero greenia and own-option adjustments' if green else 'Complete actual-label conditional bond prices on 31 August 2026'
 label='tab:expanded_green' if green else 'tab:expanded_all_prices'
 head=(r'Code & Obs. & Model & Own option & $G(\tau)$ & $\Delta g_{\rm opt}$ & $z^*$ & Error' if green
       else r'Code & Type & Maturity & Coupon & Obs. & Straight & Option & Callable & Error')
 cols='lrrrrrrr' if green else 'lllr'+'rrrrr'
 lines=[r'{\fontsize{8.5}{10.2}\selectfont',r'\setlength{\tabcolsep}{3.1pt}',r'\begin{longtable}{@{}'+cols+'@{}}',
   r'\caption{'+caption+r'}\label{'+label+r'}\\',r'\toprule',head+r' \\',r'\midrule',r'\endfirsthead',
   r'\multicolumn{'+str(8 if green else 9)+r'}{l}{\textit{Table \ref{'+label+r'} continued}}\\',r'\toprule',head+r' \\',r'\midrule',r'\endhead',
   r'\midrule\multicolumn{'+str(8 if green else 9)+r'}{r}{\textit{Continued on next page}}\\',r'\endfoot',r'\bottomrule',r'\endlastfoot']
 for issuer,q in p.sort_values(['issuer','maturity_date']).groupby('issuer',sort=False):
  lines.append(r'\multicolumn{'+str(8 if green else 9)+r'}{l}{\textbf{'+tex(SHORT.get(issuer,issuer))+r'}}\\*[2pt]')
  for r in q.itertuples():
   if green:
    row=[r.code,num(r.observed_clean_per100,3),num(r.actual_callable_clean_per100,3),num(r.actual_option_value_per100,5),
     num(r.endpoint_zero_greenium_bp,2),signed(r.redemption_effect_bp,3),num(r.fixed_option_implied_green_state_bp,2),signed(r.actual_yield_error_bp,2)]
   else:
    row=[r.code,'G' if r.is_green else 'B*' if r.split=='conventional_holdout' else 'B',pd.to_datetime(r.maturity_date).strftime('%d %b %Y'),num(r.coupon_pct,3),
     num(r.observed_clean_per100,3),num(r.actual_straight_dirty_per100-r.accrued_per100,3),num(r.actual_option_value_per100,5),num(r.actual_callable_clean_per100,3),signed(r.actual_yield_error_bp,2)]
   lines.append(' & '.join(row)+r' \\')
 lines+= [r'\end{longtable}',r'}']
 note=(r'Prices and own options are per 100 principal; observed and model prices are clean. $G(\tau)$ is the common fitted zero greenium at the final adjusted payment horizon, in basis points. $\Delta g_{\rm opt}=w^B-w^G$ is the same-contract redemption effect on the coupon-yield greenium, in basis points. $z^*$ is the individual green state implied by observed dirty price plus the own option evaluated at the common state. Error is model callable yield minus observed yield, in basis points. The individual inversion is conditional and does not re-estimate its option policy.' if green
       else r'B denotes conventional and G green; B* is Verizon GK, held out of its issuer curve fit. Prices, straight values and callable values are clean per 100 principal. Option values are per 100 principal, with the actual-label kernel. Coupon is annual percent. Error is model callable yield minus observed yield, in basis points. Literal accrued-interest conventions, dealer Treasury proxies and the recorded notice/calendar restrictions are part of the conditional specification. The electronic table retains both kernels and unrounded values.')
 lines.append(r'\noindent{\footnotesize '+note+'}\n')
 return '\n'.join(lines)

def main():
 p=pd.read_csv(DATA/'All_Bond_Prices_and_Components.csv');g=p.loc[p.is_green]
 assert len(p)==98 and len(g)==32 and p.issuer.nunique()==8,'Only assemble the completed 98-contract release'
 assert g.fixed_option_implied_green_state_bp.notna().all(),'Run exact inversion postprocessor first'
 s=pd.read_csv(DATA/'Issuer_Pricing_Summary.csv').sort_values('issuer');ch=json.loads((DATA/'Empirical_Verification.json').read_text())
 ms=json.loads((MON/'summary.json').read_text());mt=pd.read_csv(DATA/'Monthly_Matched_Summary.csv').set_index('method')
 hist=pd.read_csv(MON/'issuer_summary.csv').set_index('issuer_name');anchor=pd.read_csv(MON/'additional_conventional_bonds_effect_summary.csv').set_index('issuer_name')
 inv=pd.read_csv(MON/'latest_green_diagnostics.csv');inv=inv.loc[inv.price_basis.eq('clean_assumed')].set_index('code')
 baseinv=pd.read_csv(MON/'baseline/latest_green_diagnostics.csv');baseinv=baseinv.loc[baseinv.price_basis.eq('clean_assumed')].set_index('code')
 new_by_issuer={'DTE Electric Company':2,'MidAmerican Energy Company':3,'Northern States Power Company (Minnesota)':3}
 coverage=[]
 for r in s.itertuples():
  h=hist.loc[r.issuer]
  coverage.append([tex(SHORT.get(r.issuer,r.issuer)),int(r.green),int(r.conventional),int(h.green_bonds),int(h.green_bond_months),new_by_issuer.get(r.issuer,0)])
 coverage.append([r'\textbf{Total}',32,66,34,int(ms['n_supported_green_bond_months']),8])
 coverage_table=table('Completed current valuation and supported historical green observations','tab:expanded_coverage','lrrrrr',
  r'Legal issuer & Current G & Current B & Historical G & Green months & Added B',coverage,
  'Current counts refer to 31 August 2026. Historical green counts include matured issues. Green months require a contemporaneous conventional issuer curve. Added B identifies the eight newly reviewed conventional contracts; all are present in the current calculation. The current sample also includes the two older MidAmerican certificates under the explicitly stated accrued-interest convention.')
 mrows=[]
 for key,name in [('nearest_single','Nearest conventional'),('strict_bracketing_pair','Nonnegative bracket'),('nearest_two_interpolation_or_extrapolation_sensitivity','Nearest two sensitivity')]:
  r=mt.loc[key];mrows.append([name,int(r.bonds),int(r.bond_months),num(r.raw_mean_bp,3),num(r.standardized_mean_bp,3),num(r.mean_absolute_standardization_bp,3),num(r.mean_absolute_price_basis_sensitivity_bp,2)])
 matched_table=table('Monthly matched yields and GSW cash-flow standardization','tab:expanded_matched','lrrrrrr',
  r'Design & Green & Bond-months & Raw mean & Std. mean & Mean $|\Delta_{\rm std}|$ & Basis $|\Delta|$',mrows,
  'All rate differences are in basis points. The raw and standardized means use identical observations within each design. Standardization prices the green schedule using conventional comparator spreads over the dated GSW curve, before option adjustment. Basis sensitivity changes the treatment of the source price from clean to dirty. The nearest-two design permits extrapolation and remains a sensitivity. These are adaptations of a matching stage, without the liquidity regression of the complete Zerbib estimator.')
 fitrows=[]
 for r in s.itertuples():
  fitrows.append([tex(SHORT.get(r.issuer,r.issuer)),num(r.conventional_yield_rmse_bp),num(r.green_yield_rmse_bp),signed(r.common_green_state_bp),signed(r.zero_greenium_5y_bp),signed(r.zero_greenium_20y_bp),f'{int(r.green_inside_conventional_maturity_support)}/{int(r.green)}'])
 fit_table=table('Conditional issuer fits and common greenium curves','tab:expanded_fit','lrrrrrr',
  r'Issuer & B RMSE & G RMSE & $z_t$ & $G(5)$ & $G(20)$ & In range',fitrows,
  'All rate quantities are in basis points. RMSE uses exact model-minus-observed yields; optimization minimizes squared DV01-scaled price residuals. B RMSE excludes held-out GK. G RMSE uses the issuer common-state fit. Decays, diffusion restrictions, initial Treasury curve and contract conventions are maintained inputs. In range counts green maturities inside the fitting conventional envelope, not an identification test.')
 matched=pd.read_csv(MON/'matched_panel_monthly_gsw.csv');near=matched.loc[matched.comparison_method.eq('nearest_single')]
 br=matched.loc[matched.comparison_method.eq('strict_bracketing_pair')]
 both=near.merge(br,on=['green_code','month_label'],suffixes=('_n','_b'))
 rawdiff=both.matched_greenium_clean_assumed_bp_b-both.matched_greenium_clean_assumed_bp_n
 flips=int((both.matched_greenium_clean_assumed_bp_b*both.matched_greenium_clean_assumed_bp_n<0).sum())
 decomp=pd.read_csv(DATA/'Matched_Greenium_Exact_Decomposition.csv');dn=decomp.loc[decomp.comparison_method.eq('nearest_single')]
 maxopt=p.loc[p.actual_option_yield_wedge_bp.idxmax()];maxgo=g.loc[g.redemption_effect_bp.abs().idxmax()]
 minfit=s.conventional_yield_rmse_bp.min();maxfit=s.conventional_yield_rmse_bp.max();hold=p.loc[p.split.eq('conventional_holdout')].iloc[0]
 checks_path=ROOT/'tmp/expansion/pricing/final_validation_text.tex'
 validation=checks_path.read_text() if checks_path.exists() else 'The calculation reports paired evaluation uncertainty separately from the finite-grid and policy approximations; no full-panel numerical error bound is asserted.'
 vals={
 'NEW_CONTRACT_COUNT':'eight','ANCHOR_DESCRIPTION':'Three are older MidAmerican notes, three are NSP Minnesota first-mortgage issues, and two are DTE senior notes secured by pledged bonds of the same general and refunding mortgage. The DTE wrapper, collateral substitution and release conditions remain explicit; common priority is conditional on the unreleased collateral arrangement documented in the current issuer filings.',
 'NEW_BOND_MONTHS':f'{ms["n_new_verified_bond_months"]:,}','BOND_MONTHS':f'{ms["n_bond_month_observations"]:,}',
 'MONTHLY_CONTRACTS':str(ms['n_cashflow_eligible_contracts']),'GREEN_MONTHS':f'{ms["n_supported_green_bond_months"]:,}',
 'CURRENT_BONDS':str(len(p)),'CURRENT_BROWNS':str(int((~p.is_green).sum())),
 'COVERAGE_TABLE':coverage_table,'MATCHED_TABLE':matched_table,'FIT_TABLE':fit_table,'GREEN_TABLE':grouped_longtable(g),
 'NUMERICAL_VALIDATION':validation,
 'COMMON_MATCH_COMPARISON':f'the mean absolute difference between raw designs is {rawdiff.abs().mean():.2f} basis points, with {flips} sign reversals ({100*flips/len(both):.1f}\\%)',
 'NEAREST_STANDARDIZATION_ABS':num(mt.loc['nearest_single','mean_absolute_standardization_bp'],2),
 'NEAREST_STANDARDIZATION_SIGNED':signed(mt.loc['nearest_single','mean_standardization_bp'],3),
 'BRACKET_STANDARDIZATION_ABS':num(mt.loc['strict_bracketing_pair','mean_absolute_standardization_bp'],2),
 'NSP_CT_ANCHORED':num(inv.loc['665772CT','same_cashflow_yield_greenium_bp'],2)+' basis points',
 'NSP_Z_ANCHORED':num(inv.loc['665772CT','common_z_bp'],2)+' basis points',
 'NSP_CONDITION_ANCHORED':num(anchor.loc['Northern States Power Company (Minnesota)','latest_conventional_jacobian_condition_after'],1),
 'NSP_GREEN_RMSE_ANCHORED':num(anchor.loc['Northern States Power Company (Minnesota)','latest_green_fit_rmse_after_bp'],2),
 'MIDAM_ANCHOR_RESULT':f'MidAmerican supplies a second example. Adding its 2031, 2035 and 2036 conventional issues reduces the pre-option common green state from {anchor.loc["MidAmerican Energy Company","latest_common_z_before_bp"]:.2f} to {anchor.loc["MidAmerican Energy Company","latest_common_z_after_bp"]:.2f} basis points, and the conventional Jacobian condition number from approximately {anchor.loc["MidAmerican Energy Company","latest_conventional_jacobian_condition_before"]:,.0f} to {anchor.loc["MidAmerican Energy Company","latest_conventional_jacobian_condition_after"]:.1f}. The short AQ differential falls from {baseinv.loc["595620AQ","same_cashflow_yield_greenium_bp"]:.2f} to {inv.loc["595620AQ","same_cashflow_yield_greenium_bp"]:.2f} basis points, and AT from {baseinv.loc["595620AT","same_cashflow_yield_greenium_bp"]:.2f} to {inv.loc["595620AT","same_cashflow_yield_greenium_bp"]:.2f}. These remaining short-end differences are still large and do not establish a pure green preference premium. Adding the two DTE issues changes the latest common pre-option state from {anchor.loc["DTE Electric Company","latest_common_z_before_bp"]:.2f} to {anchor.loc["DTE Electric Company","latest_common_z_after_bp"]:.2f} basis points, illustrating that conventional-set sensitivity also matters within a wider maturity envelope.',
 'CURRENT_GREEN_INSIDE_SUPPORT':str(ch['green_inside_maturity_support']),
 'CURRENT_GREEN_OUTSIDE_SUPPORT':str(len(g)-ch['green_inside_maturity_support']),
 'FIT_RESULT_DISCUSSION':f'Conventional fitting RMSE ranges from {minfit:.2f} to {maxfit:.2f} basis points across issuers. The held-out Verizon GK yield residual is {hold.actual_yield_error_bp:+.2f} basis points. The signed common states include negative Boston Properties and Equinix estimates. The larger utility green residuals show that the fixed green maturity profile and common issuer curve do not explain every observed quote. They remain part of the empirical result rather than being absorbed into a security-specific fitted green state.',
 'MAX_PRICE_IDENTITY':sci(ch['maximum_price_decomposition_error_per100']),
 'OPTION_RESULT_DISCUSSION':f'The largest own-option yield wedge is {maxopt.actual_option_yield_wedge_bp:.3f} basis points for {tex(maxopt.issuer)} bond \\texttt{{{maxopt.code}}}, with option value {maxopt.actual_option_value_per100:.5f} per 100. Across the 32 green contracts, the mean absolute same-contract redemption correction is {g.redemption_effect_bp.abs().mean():.3f} basis points and the largest absolute correction is {abs(maxgo.redemption_effect_bp):.3f}, for \\texttt{{{maxgo.code}}}. These are conditional point estimates on one date. The monetary own option, the option difference under the two kernels and the difference between two observed contracts are separate quantities.',
 'MATCHED_DECOMPOSITION_RESULT':f'The completed current sample permits {len(decomp)} such comparisons across the retained designs, including {len(dn)} nearest-comparator observations. The largest absolute reconstruction discrepancy is {sci(decomp.exact_reconciliation_error_bp.abs().max())} basis points.',
 'INVERSION_RESULT':f'The 32 analytical inversions reconstruct their adjusted targets with a maximum absolute error of {sci(g.fixed_option_inversion_reconstruction_error_per100.abs().max())} per 100.',
 'ORDERING_RESULT':f'The largest observed signed-order discrepancy in the reported finite-path green-contract estimates is {ch["maximum_ordering_violation_paired_se"]:.2f} paired evaluation standard errors. Across both kernels on all 98 contracts, the largest reversal occurs for conventional NSP CQ: the green-minus-conventional option difference is $-0.009382$ per 100 with paired evaluation standard error 0.004172, approximately 2.25 conditional standard errors. These conditional errors exclude uncertainty in the learned exercise policies; separately trained policies do not enforce the exact ordering.',
 }
 atref=json.loads((ROOT/'tmp/expansion/pricing/refinement_595620AT/refinement_summary.json').read_text())
 ats=json.loads((ROOT/'tmp/expansion/pricing/refinement_595620AT/green_state_sensitivity.json').read_text())
 rest=g.loc[g.code.ne('595620AT')]
 vals['AT_DIAGNOSTIC']=(
  f'The largest correction, for MidAmerican AT, is concentrated in a contract outside its conventional maturity envelope. '
  f'Excluding AT, the mean absolute same-contract correction across the remaining 31 green bonds is {rest.redemption_effect_bp.abs().mean():.3f} basis points; '
  f'the full-sample median absolute correction is {g.redemption_effect_bp.abs().median():.3f}. '
  f'For AT, doubling training and evaluation paths to 1,536 and 4,608, using 64 conditional fixing draws and a 15-day grid with an independent seed, '
  f'changes the correction from {atref["reported_correction_bp"]:.3f} to {atref["refined_correction_bp"]:.3f} basis points. '
  f'The {abs(atref["same_contract_redemption_correction_change_bp"]):.3f}-basis-point refinement difference is small relative to that conditional correction. '
  f'The common green state, however, leaves an AT yield residual of {ats["original_common_fit_yield_residual_bp"]:+.2f} basis points. '
  f'Using its individual fixed-option implied state, {ats["individual_fixed_option_implied_state_bp"]:.2f} rather than {ats["common_green_state_bp"]:.2f} basis points, '
  f'and repricing the option once at the same conventional curve reduces the correction to {ats["individual_state_same_contract_redemption_correction_bp"]:.3f} basis points '
  f'and the green option from {ats["common_green_option_per100"]:.5f} to {ats["individual_state_green_option_per100"]:.5f} per 100. '
  f'This repricing retains a {ats["changed_option_after_individual_state_yield_residual_bp"]:+.2f}-basis-point yield residual because the analytical inversion used the original fixed option. '
  'It is a state-sensitivity calculation, not a new common-state estimate or a recursively fitted callable-price root. '
  'The numerical check supports the stability of the chosen-state valuation, while the state comparison shows why its magnitude cannot yet be treated as a precisely identified market greenium correction.')
 body=(MAN/'empirical_expanded_template.tex').read_text()
 for k,v in vals.items():body=body.replace('@@'+k+'@@',v)
 assert '@@' not in body,'Unfilled empirical tokens'
 (MAN/'empirical_expanded.tex').write_text(body)
 full=(MAN/'merged_base.tex').read_text()
 full=re.sub(r'% BEGIN EMPIRICAL REPLACEMENT BLOCK.*?% END EMPIRICAL REPLACEMENT BLOCK',lambda m:body,full,flags=re.S)
 abstract=r'''\noindent Green valuation changes both the value of promised corporate-bond payments and the issuer's incentive to redeem them. We develop a joint arbitrage-free Nelson--Siegel framework for conventional and green claims of the same issuer, with Treasury, effective credit and green convenience components and explicit contractual redemption. A closed-form zero-coupon price ratio separates expected green service from covariance and convexity effects. The embedded green and conventional options have no universal ordering, although deterministic service of one sign gives a restricted ordering. Conditional on the conventional curve, parameters and own-option adjustment, a coupon price has a unique implied green state and zero-coupon greenium curve. Actual make-whole floors, fixing rules and notice enter a numerical stopping problem. The empirical application combines 34 green bonds and 2,624 monthly green observations with a complete conditional valuation of 98 current contracts across eight issuers. Eight additional conventional issues materially improve maturity information: for one short NSP green bond, the pre-option same-cash-flow differential falls from 153.53 to 35.04 basis points. Matched estimates change by 3.43 basis points on average in absolute value when the comparator design changes on a common sample. We report Treasury, conventional and green zero curves, own redemption values and an exact reconciliation of observed matched yields into cash-flow, contract, green and residual components. The evidence separates conditional pricing and benchmark sensitivity from unrestricted dynamic identification.'''
 full=re.sub(r'\\begin\{abstract\}.*?\\end\{abstract\}',lambda m:r'\begin{abstract}'+'\n\n'+abstract+'\n\n'+r'\end{abstract}',full,flags=re.S)
 intro=r'''The empirical application extends across eight corporate issuers. The original legal register and eight additional conventional issues support 114 historical contracts and 10,398 monthly cash-flow observations. The green comparison covers 34 verified green bonds and 2,624 supported green bond-months. A dated callable calculation values 98 bonds on 31 August 2026, including all 32 green contracts with supported current observations. The Treasury block reproduces the supplied GSW initial discount curve through a deterministic AFNS shift. Credit and green diffusion are suppressed in the conditional application, and the credit level retains the driftless AFNS restriction. Each issuer's common green state is fitted conditional on a fixed maturity profile, with both signs permitted.

The wider conventional set changes the interpretation of the green estimates. Adding a noncallable short NSP Minnesota bond and two intermediate conventional maturities reduces a short green bond's pre-option same-cash-flow differential from about 154 to 35 basis points, while sharply improving the conditioning of the issuer curve. MidAmerican exhibits a similar sensitivity to missing short and intermediate conventional information. These differences arise before interpreting any residual as green preferences. The matching comparison supplies a separate result: on an identical 619 observations, the choice between a nearest comparator and a nonnegative bracket changes the raw estimate by 3.43 basis points on average in absolute value and reverses its sign in 96 cases.

For every current contract the calculation reports Treasury-discounted payments, the conventional issuer deduction, the green price increment and the own redemption option. It also values each green contract under the conventional kernel. The resulting exact yield reconciliation keeps coupon-and-curve differences, contractual option differences, the change in the green contract's own option and both fitting residuals separate. The monthly comparison remains pre-option, whereas the dated expansion includes the contractual option calculation. The evidence therefore establishes a broader conditional pricing application and explicit measurement sensitivities without attributing full dynamic identification or production pricing accuracy to a successful quote inversion.

'''
 full=re.sub(r'The empirical application values 26 Verizon contracts.*?(?=% ROOT UPDATE|Section~\\ref\{sec:literature\})',lambda m:intro,full,count=1,flags=re.S)
 full=full.replace('presents the Verizon application','presents the expanded corporate application')
 full=full.replace("The empirical specialization used below has this property. Its small negative simulated option differences are consequently numerical outcomes, not evidence of a reversal of that restricted ordering.", "The positive-state empirical cases satisfy this restriction; deterministic negative-state cases satisfy the reverse ordering after interchanging the kernels. Estimated violations of the appropriate price-option ordering are assessed against simulation and policy-approximation error.")
 full=full.replace('The Verizon application connects its fitted coupon-bond green premium to the zero-coupon greenium through common cash flows and explicit coupon and redemption adjustments; it does not report a new provider-OAS or independently matched-yield comparison.',
 'The empirical application connects fitted coupon-bond green premia to zero-coupon greenia and compares them with an adapted monthly matching design on common cash flows. It reports no provider-OAS comparison and does not claim to reproduce the full liquidity-adjusted Zerbib estimator.')
 full=full.replace('Section~\\ref{sec:empirical} implements a conditional cross-sectional specialization: it fixes the Treasury dynamics, estimates the issuer-curve coefficients and one green state, and sets credit and green diffusion to zero. No full seven-factor panel likelihood, event-intensity estimation or bootstrap is reported for that application.',
 'Section~\\ref{sec:empirical} implements separate dated pre-option fits across a monthly sample and a current multi-issuer callable specialization. The latter fixes Treasury dynamics, estimates issuer-curve coefficients and a common green state for each issuer, and sets credit and green diffusion to zero. No full seven-factor panel likelihood, event-intensity estimation or bootstrap is reported.')
 full=full.replace('The completed application below uses a single dated issuer cross-section and reports conditional valuation uncertainty appropriate to that scope.',
 'The completed application reports monthly pre-option comparisons and a dated callable cross-section across eight issuers, with conditional numerical uncertainty stated separately from the broader estimation framework.')
 conclusion=r'''\section{Conclusion}
\label{sec:conclusion}

Corporate greenium measurement depends on the rights that determine when investors receive the promised payments. A common valuation system can price a green and a conventional claim under their own contractual terms, allow green valuation to enter the issuer's continuation decision and map the resulting option-adjusted coupon price to a zero-coupon greenium curve. The framework developed here makes those relationships explicit while preserving the established AFNS, reduced-form credit and callable-bond foundations.

The analytical structure supplies the green multiplier, its maturity profile and sensitivities, the exact Gaussian transition and a monotone conditional coupon-price inverse. The full contracted callable bond remains a numerical stopping problem when floors, notice and stochastic Treasury fixing are present. A positive current full-maturity greenium does not universally order the two embedded options. A deterministic service of constant sign gives a useful restricted ordering and a diagnostic for numerical differences. Neither the conditional inverse nor the use of a matrix exponential supplies unrestricted parameter identification; that question depends on the observed contracts, maturities and pricing sensitivities.

The empirical extension supplies 34 green bonds and 2,624 supported monthly green observations, together with a conditional callable valuation of 98 current contracts across eight issuers. The added conventional bonds reveal the importance of maturity information. An apparently large short-end green component can fall sharply when actual short and intermediate conventional issues enter the curve fit. Matched comparisons independently show consequential sensitivity to comparator choice, cash-flow standardization and the interpretation of the source price. These effects are comparable to, and in some cases substantially larger than, the green differentials being measured.

The dated valuation reports both kernels for every included contract and separates Treasury discounting, the effective issuer spread, the green component and own redemption. The observed matched yield is then reconciled exactly into common-contract green valuation, coupon-and-curve differences, contractual option differences and the remaining pricing residuals. A common green state leaves those residuals visible; choosing one inverse state per quote would reproduce adjusted prices without resolving their economic interpretation.

The current evidence is conditional on fixed green shape, the maintained diffusion restrictions and the recorded contract and price conventions. The broader monthly comparison has not yet been valued with redemption on every date, and the full joint dynamic likelihood and liquidity-adjusted comparison are not reported. The contribution at this stage is the joint contractual framework, its exact measurement identities and a reproducible multi-issuer application showing where conventional maturity support and quotation construction determine the recovered greenium. These results specify the additional information required for a fully estimated corporate panel and make the next valuation extensions testable.

'''
 full=re.sub(r'\\section\{Conclusion\}.*?(?=\\appendix)',lambda m:conclusion,full,count=1,flags=re.S)
 # Add signed-service counterpart directly after the existing empirical bridge.
 signed_text=(ROOT/'tmp/expansion/reporting/review/Signed_Green_Ordering_Corollary.tex').read_text()
 pos=full.index('A deterministic reduction illustrates the point.')
 full=full[:pos]+signed_text+'\n'+full[pos:]
 lemma=(ROOT/'tmp/expansion/reporting/review/Minimum_Notice_Lemma.tex').read_text()
 extra='\n'+r'\section{Notice dominance and the numerical action grid}'+'\n'+r'\label{app:minimum_notice}'+'\n\n'+lemma+'\n'
 extra+=r'\section{Complete dated bond-price results}'+'\n'+r'\label{app:expanded-prices}'+'\n\n'+grouped_longtable(p,'all')+'\n'
 full=full.replace(r'\section{Replication materials}',extra+r'\section{Replication materials}')
 old_start=full.index('The empirical replication directory contains the frozen Verizon')
 old_end=full.index(r'\bibliographystyle',old_start)
 repl=r'''The empirical replication directories retain the original 111-contract register, the eight additional conventional contract records, original and expanded monthly cash flows, GSW Treasury inputs, H.15 observations, source manifests and the conditional contract assumptions. The monthly scripts reproduce the 19-green matching design and expand the issuer-curve calculations to 34 green bonds. The dated scripts prepare exact Treasury transitions, fit each issuer with own options inside calibration, evaluate both kernels, invert adjusted green prices and produce the component reconciliations. The archive includes the frozen pre-anchor comparison and the eight-issuer expanded outputs.

The source package distinguishes regeneration of tables and figures from the more expensive callable calculations. It includes unrounded observations, issuer parameters, all 98 actual-label prices, both kernels, conditional paired uncertainty, zero curves and analytical inversion results. Exact Gaussian simulation, regression continuation, fixing integration and finite decision-grid approximations remain separately identified. Provider quotation conventions and unobserved subsequent lifecycle events are not verified by reproducing a calculation from frozen inputs. The source-price files originate in the supplied FactSet extraction; their reuse remains subject to the user's applicable data terms.

The manuscript tables and figures correspond to those frozen outputs. Changing a source quote, cash-flow schedule, contract convention or pricing restriction requires regenerating the affected fit and exhibits. The complete 20,106-code inventory and unresolved verification queue are retained separately from completed valuations. Candidate membership is never represented as an option-valued observation.

'''
 full=full[:old_start]+repl+full[old_end:]
 full=re.sub(r'^% ROOT UPDATE:.*\n','',full,flags=re.M)
 assert '26 Verizon' not in full and 'four green fitting' not in full
 assert '@@' not in full
 target=OUT/'Redemption_Rights_AFNS_Master_rev6.tex';target.write_text(full)
 labels=re.findall(r'\\label\{([^}]+)\}',full);refs=re.findall(r'\\(?:eqref|ref)\{([^}]+)\}',full)
 missing=sorted(set(refs)-set(labels));dups=sorted({x for x in labels if labels.count(x)>1})
 if missing or dups:raise ValueError({'undefined_labels':missing,'duplicate_labels':dups})
 (OUT/'data/Manuscript_Build_Checks.json').write_text(json.dumps(dict(contracts=len(p),green=len(g),labels=len(labels),undefined_labels=missing,duplicate_labels=dups),indent=2))
 print(str(target))

if __name__=='__main__':main()
