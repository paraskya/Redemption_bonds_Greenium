"""Independent audit from raw observed/fitted yields, without calling reporting code."""
from pathlib import Path
import json
import pandas as pd

ROOT=Path(__file__).resolve().parents[3]
review=ROOT/'tmp/expansion/reporting/review'
review.mkdir(exist_ok=True)
paths=list((ROOT/'tmp/expansion/pricing/results').glob('*/all_bond_prices.csv'))
paths+=list((ROOT/'tmp/expansion/pricing/results_expanded').glob('*/all_bond_prices.csv'))
by_issuer={}
for p in paths:
    if (p.parent/'summary.json').exists():
        f=pd.read_csv(p)
        by_issuer[f.issuer.iloc[0]]=(p,f,json.loads((p.parent/'summary.json').read_text()))
prices=pd.concat([v[1] for v in by_issuer.values()],ignore_index=True)
assert not prices.code.duplicated().any()
by=prices.set_index('code')
monthly=pd.read_csv(ROOT/'tmp/expansion/benchmarks/matched_panel_monthly_gsw.csv')
reg=json.loads((ROOT/'restored/Zero_Coupon_Greenium_Data_and_Code/inventory/inputs/comparison/results/normalized_contracts.json').read_text())['contracts']
legal_keys={r['source_code']:r.get('legal_issuer_key') for r in reg}
rows=[];sourcegaps=[]
for row in monthly[monthly.month_label.eq('2026-08-31')].to_dict('records'):
    legs=[(row['brown1_code'],row['weight1'],1)]
    if pd.notna(row['brown2_code']) and row['weight2']!=0:
        legs.append((row['brown2_code'],row['weight2'],2))
    if row['green_code'] not in by.index or any(c not in by.index for c,w,k in legs):continue
    g=by.loc[row['green_code']]
    direct=(sum(w*by.loc[c,'observed_yield_pct'] for c,w,k in legs)-g.observed_yield_pct)*100
    gs=(g.brown_straight_yield_pct-g.green_straight_yield_pct)*100
    term_curve=(sum(w*by.loc[c,'brown_straight_yield_pct'] for c,w,k in legs)-g.brown_straight_yield_pct)*100
    term_contract=sum(w*(by.loc[c,'brown_callable_yield_pct']-by.loc[c,'brown_straight_yield_pct'])*100 for c,w,k in legs)-(g.brown_callable_yield_pct-g.brown_straight_yield_pct)*100
    term_green=((g.brown_callable_yield_pct-g.brown_straight_yield_pct)-(g.green_callable_yield_pct-g.green_straight_yield_pct))*100
    term_res_b=sum(w*(by.loc[c,'observed_yield_pct']-by.loc[c,'brown_callable_yield_pct'])*100 for c,w,k in legs)
    term_res_g=(g.green_callable_yield_pct-g.observed_yield_pct)*100
    total=gs+term_curve+term_contract+term_green+term_res_b+term_res_g
    raw=row['matched_greenium_clean_assumed_bp']
    rows.append(dict(green_code=g.name,method=row['comparison_method'],direct_raw_bp=direct,reported_raw_bp=raw,component_total_bp=total,identity_error_bp=total-direct,source_alignment_error_bp=direct-raw,straight_bp=gs,couponcurve_bp=term_curve,contract_bp=term_contract,greenoption_bp=term_green,brownres_bp=term_res_b,greenres_bp=term_res_g))
    for c,w,k in legs:
        b=by.loc[c]
        sourcegaps.append(dict(green_code=g.name,code=c,role='brown',is_expected_label=not b.is_green,issuer_match=b.issuer==g.issuer and legal_keys.get(c)==legal_keys.get(g.name),valuation_match=b.valuation_date==row['valuation_date']==g.valuation_date,yield_gap_bp=(b.observed_yield_pct-row[f'brown{k}_ytm_pct'])*100,price_gap=b.observed_clean_per100-row[f'brown{k}_P_PRICE']))
    sourcegaps.append(dict(green_code=g.name,code=g.name,role='green',is_expected_label=bool(g.is_green),issuer_match=legal_keys.get(g.name)==row['legal_issuer'],valuation_match=g.valuation_date==row['valuation_date'],yield_gap_bp=(g.observed_yield_pct-row['green_ytm_pct'])*100,price_gap=g.observed_clean_per100-row['green_P_PRICE']))
d=pd.DataFrame(rows);sg=pd.DataFrame(sourcegaps)
d.to_csv(review/'independent_matched_reconciliation.csv',index=False)
sg.to_csv(review/'matched_source_alignment.csv',index=False)
checks={
 'completed_files':[str(v[0]) for v in by_issuer.values()],
 'contracts':len(prices),'green_bonds':int(prices.is_green.sum()),'issuers':int(prices.issuer.nunique()),'matched_comparisons':len(d),
 'max_identity_error_bp':float(d.identity_error_bp.abs().max()),'max_source_alignment_error_bp':float(d.source_alignment_error_bp.abs().max()),
 'max_leg_yield_gap_bp':float(sg.yield_gap_bp.abs().max()),'max_leg_price_gap_per100':float(sg.price_gap.abs().max()),
 'leg_date_mismatches':int((~sg.valuation_match).sum()),'leg_issuer_mismatches':int((~sg.issuer_match).sum()),'label_mismatches':int((~sg.is_expected_label).sum()),
 'max_actual_error_definition_gap_bp':float((prices.actual_yield_error_bp-100*(prices.actual_callable_yield_pct-prices.observed_yield_pct)).abs().max()),
 'max_brown_wedge_definition_gap_bp':float((prices.brown_option_yield_wedge_bp-100*(prices.brown_callable_yield_pct-prices.brown_straight_yield_pct)).abs().max()),
 'max_green_wedge_definition_gap_bp':float((prices.green_option_yield_wedge_bp-100*(prices.green_callable_yield_pct-prices.green_straight_yield_pct)).abs().max()),
 'green_parameters':[],
}
for p,f,s in by_issuer.values():
    gr=s['green_fit']
    checks['green_parameters'].append(dict(issuer=s['issuer'],mu=gr['mu'],theta_bp=gr['theta_bp'],diffusion=gr['green_diffusion'],z_bp=gr['z_bp'],maximum_row_vs_summary_z_gap_bp=float((f.green_state_bp-gr['z_bp']).abs().max())))
(review/'independent_checks.json').write_text(json.dumps(checks,indent=2)+'\n')
print(json.dumps(checks,indent=2))
print(d.to_string(index=False))
