#!/usr/bin/env python3
"""Execute an explicit frozen-input replication stage, preserving archived outputs."""
from __future__ import annotations
import argparse,json,shlex,shutil,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3]
HERE=Path(__file__).resolve().parent
STEPS=('baseline','expanded','monthly','postprocess','figures')

def make_commands(spec,run,workers):
    num=spec['numerical_settings'];common=[]
    for flag,k in [('workers','workers'),('train','train'),('evaluation','evaluation'),('qmc-power','qmc_power'),('seed','seed'),('step-days','step_days'),('maxiter','maxiter')]:
        common += ['--'+flag,str(workers if k=='workers' and workers is not None else num[k])]
    pricing='tmp/expansion/pricing/run_expanded_batch.py';inverse='tmp/expansion/pricing/append_exact_inversions.py'
    def branch(label,register,prices,issuers=()):
        out=(run/label).as_posix()
        cmd=[pricing,'--register',register,'--prices',prices,'--month',spec['valuation_month'],'--out',out,*common]
        for issuer in issuers:cmd+=['--issuer',issuer]
        return [cmd,[inverse,'--out',out,'--register',register,'--prices',prices]]
    return {
      'baseline':branch('baseline',spec['base_register'],spec['base_prices']),
      'expanded':[[spec['expanded_driver'],'--base-results',(run/'baseline').as_posix(),'--register',spec['expanded_register'],'--prices',spec['expanded_prices'],'--out',(run/'expanded').as_posix()]],
      'monthly': [[(run/'monthly_baseline/run_monthly.py').as_posix()],[(run/'monthly_baseline/summarize_monthly.py').as_posix()],[(run/'monthly/run_monthly.py').as_posix(),'--extra-contracts',(run/'monthly/inputs/replication/extra_contracts.json').as_posix()],[(run/'monthly/summarize_monthly.py').as_posix()],[(run/'monthly/compare_anchor_results.py').as_posix()]],
      'postprocess':[['tmp/expansion/reporting/build_empirical_outputs.py','--pricing',(run/'expanded').as_posix(),'--monthly',(run/'monthly').as_posix(),'--out',(run/'report/data').as_posix()]],
      'figures':[['tmp/expansion/reporting/plot_expansion.py','--data',(run/'report/data').as_posix(),'--monthly',(run/'monthly').as_posix(),'--out',(run/'report/figures').as_posix()]]}

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--step',choices=(*STEPS,'all'),default='all')
    ap.add_argument('--run-root',type=Path,default=Path('tmp/reproduction'))
    ap.add_argument('--workers',type=int)
    ap.add_argument('--plan',action='store_true')
    ap.add_argument('--commands',type=Path,default=HERE/'replication_commands.json')
    args=ap.parse_args();spec=json.loads(args.commands.read_text())
    run=args.run_root
    if run.is_absolute():
        run=run.resolve().relative_to(ROOT)
    runpath=(ROOT/run).resolve()
    if runpath==ROOT or ROOT.is_relative_to(runpath):raise ValueError('Choose a dedicated output subdirectory')
    selected=STEPS if args.step=='all' else (args.step,)
    commands=make_commands(spec,run,args.workers)
    if args.plan:
        for step in selected:
            print('# '+step)
            for cmd in commands[step]:print(shlex.join(['python',*cmd]))
        return
    if not spec.get('finalized',False) and any(s in selected for s in ['expanded','postprocess','figures']):
        raise SystemExit('Expanded replication manifest has not been finalized by the empirical pipeline.')
    if 'monthly' in selected:
        source=ROOT/'tmp/expansion/benchmarks';inp=source/'inputs/replication'
        if not (inp/'extra_contracts.json').exists():raise SystemExit('Portable monthly input set is incomplete.')
        for folder in ['monthly','monthly_baseline']:
            dest=runpath/folder;dest.mkdir(parents=True,exist_ok=True)
            for name in ['run_monthly.py','summarize_monthly.py','compare_anchor_results.py']:shutil.copy2(source/name,dest/name)
            shutil.copytree(inp,dest/'inputs/replication',dirs_exist_ok=True)
    for step in selected:
        for cmd in commands[step]:
            if step=='monthly' and Path(cmd[0]).name=='compare_anchor_results.py':
                dest=runpath/'monthly/baseline';dest.mkdir(parents=True,exist_ok=True)
                for source in (runpath/'monthly_baseline').iterdir():
                    if source.is_file() and source.suffix in {'.csv','.json','.pdf','.png','.svg'}:shutil.copy2(source,dest/source.name)
            print(shlex.join([sys.executable,*cmd]),flush=True)
            subprocess.run([sys.executable,*cmd],cwd=ROOT,check=True)

if __name__=='__main__':main()
