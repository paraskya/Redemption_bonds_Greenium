"""Publication figures from completed, unrounded expansion results."""
from pathlib import Path
import argparse
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

ROOT=Path(__file__).resolve().parents[3]
SHORT={'Apple Inc.':'Apple','Boston Properties Limited Partnership':'Boston Properties',
 'DTE Electric Company':'DTE Electric','Equinix, Inc.':'Equinix',
 'MidAmerican Energy Company':'MidAmerican Energy',
 'Northern States Power Company (Minnesota)':'NSP Minnesota',
 'Public Service Company of Colorado':'PSC Colorado','Verizon Communications Inc.':'Verizon'}
BLUE='#20547c';GREEN='#13846c';ORANGE='#bb6b29';GREY='#74818a'
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'axes.titlesize':10,
 'axes.labelsize':9,'xtick.labelsize':8,'ytick.labelsize':8,'axes.spines.top':False,
 'axes.spines.right':False,'pdf.fonttype':42,'savefig.bbox':'tight'})

def finish(fig,out,name):
 fig.savefig(out/(name+'.pdf'));fig.savefig(out/(name+'.png'),dpi=190);plt.close(fig)

def main():
 a=argparse.ArgumentParser();a.add_argument('--data',default=str(ROOT/'output/expanded_master/data'))
 a.add_argument('--out',default=str(ROOT/'output/expanded_master/figures'))
 a.add_argument('--monthly',default=str(ROOT/'tmp/expansion/benchmarks'));args=a.parse_args()
 data=Path(args.data);out=Path(args.out);out.mkdir(parents=True,exist_ok=True)
 p=pd.read_csv(data/'All_Bond_Prices_and_Components.csv');c=pd.read_csv(data/'Treasury_Credit_and_Green_Zero_Curves.csv')
 s=pd.read_csv(data/'Issuer_Pricing_Summary.csv');issuers=s.sort_values('issuer').issuer.tolist()
 fig,axes=plt.subplots(4,2,figsize=(7.0,9.1),sharex=True)
 for ax,issuer in zip(axes.flat,issuers):
  cc=c.loc[c.issuer.eq(issuer)].sort_values('tenor_years');pp=p.loc[p.issuer.eq(issuer)];b=pp.loc[pp.split.eq('conventional_fit')]
  t=cc.tenor_years.to_numpy();lo=b.final_payment_horizon_years.min();hi=b.final_payment_horizon_years.max()
  ax.axvspan(lo,min(hi,40),color=BLUE,alpha=.06,lw=0)
  ax.plot(t,cc.treasury_zero_pct,color=GREY,lw=1.1,ls=':',label='Treasury')
  ax.plot(t,cc.brown_zero_pct,color=BLUE,lw=1.4,label='Conventional')
  ax.plot(t,cc.green_zero_pct,color=GREEN,lw=1.4,ls='--',label='Green')
  ax.set(title=SHORT.get(issuer,issuer),xlim=(0,40),ylabel='Zero yield (%)');ax.grid(alpha=.16)
 for ax in axes[-1]:ax.set_xlabel('Remaining horizon (years)')
 fig.legend(*axes.flat[0].get_legend_handles_labels(),loc='upper center',ncol=3,frameon=False,bbox_to_anchor=(.5,1.015))
 fig.tight_layout(h_pad=1.5,w_pad=2);finish(fig,out,'Expanded_Zero_Yields')

 fig,axes=plt.subplots(4,2,figsize=(7.0,8.4),sharex=True)
 for ax,issuer in zip(axes.flat,issuers):
  cc=c.loc[c.issuer.eq(issuer)].sort_values('tenor_years');pp=p.loc[p.issuer.eq(issuer)];b=pp.loc[pp.split.eq('conventional_fit')];g=pp.loc[pp.is_green]
  t=cc.tenor_years.to_numpy();lo=b.final_payment_horizon_years.min();hi=b.final_payment_horizon_years.max();y=cc.greenium_zero_bp.to_numpy()
  inside=(t>=lo)&(t<=hi);ax.plot(t,y,color=GREEN,lw=1.2,ls='--');ax.plot(t,np.where(inside,y,np.nan),color=GREEN,lw=1.8)
  for _,r in g.iterrows():
   ax.scatter(r.final_payment_horizon_years,r.endpoint_zero_greenium_bp,s=22,
    facecolor=GREEN if r.inside_conventional_maturity_support else 'white',edgecolor=GREEN,zorder=4)
  ax.axhline(0,color=GREY,lw=.65);ax.set(title=SHORT.get(issuer,issuer),xlim=(0,40),ylabel='Greenium (bp)');ax.grid(alpha=.16)
 for ax in axes[-1]:ax.set_xlabel('Remaining horizon (years)')
 fig.tight_layout(h_pad=1.4,w_pad=2);finish(fig,out,'Expanded_Greenium_Curves')

 fig,axes=plt.subplots(4,2,figsize=(7.0,8.5),sharex=True)
 for ax,issuer in zip(axes.flat,issuers):
  pp=p.loc[p.issuer.eq(issuer)]
  for green,color,marker in [(False,BLUE,'o'),(True,GREEN,'D')]:
   v=pp.loc[pp.is_green.eq(green)];ax.scatter(v.final_payment_horizon_years,v.actual_option_yield_wedge_bp,s=20,c=color,marker=marker,alpha=.85)
  ax.set(title=SHORT.get(issuer,issuer),ylabel='Own option (yield bp)',xlim=(0,48));ax.grid(alpha=.16)
 for ax in axes[-1]:ax.set_xlabel('Final payment horizon (years)')
 handles=[Line2D([0],[0],marker='o',color='none',markerfacecolor=BLUE,markeredgecolor=BLUE,label='Conventional'),Line2D([0],[0],marker='D',color='none',markerfacecolor=GREEN,markeredgecolor=GREEN,label='Green')]
 fig.legend(handles=handles,loc='upper center',ncol=2,frameon=False,bbox_to_anchor=(.5,1.015));fig.tight_layout(h_pad=1.5,w_pad=2)
 finish(fig,out,'Expanded_Contract_Options')

 m=pd.read_csv(Path(args.monthly)/'matched_panel_monthly_gsw.csv');m=m.loc[m.comparison_method.eq('nearest_single')].copy()
 m['date']=pd.to_datetime(m.month_label);agg=m.groupby('date').agg(raw=('matched_greenium_clean_assumed_bp','mean'),standardized=('gsw_owncf_yield_greenium_clean_assumed_bp','mean'),bonds=('green_code','nunique'))
 fig,(ax,low)=plt.subplots(2,1,figsize=(7.0,4.8),sharex=True,gridspec_kw={'height_ratios':[3,1]})
 ax.plot(agg.index,agg.raw,color=BLUE,lw=1.2,label='Observed nearest matched yield')
 ax.plot(agg.index,agg.standardized,color=GREEN,lw=1.2,label='GSW cash-flow standardized')
 ax.axhline(0,color=GREY,lw=.7);ax.set_ylabel('Monthly mean (bp)');ax.legend(frameon=False,loc='best',fontsize=8);ax.grid(alpha=.16)
 low.fill_between(agg.index,agg.bonds,step='mid',color=GREY,alpha=.35);low.set_ylabel('Green bonds');low.set_ylim(0,max(agg.bonds)+1);low.grid(alpha=.12)
 fig.tight_layout();finish(fig,out,'Expanded_Monthly_Comparisons')

 fig,axes=plt.subplots(4,2,figsize=(7.0,8.5),sharex=True)
 for ax,issuer in zip(axes.flat,issuers):
  pp=p.loc[p.issuer.eq(issuer)]
  for green,color,marker in [(False,BLUE,'o'),(True,GREEN,'D')]:
   v=pp.loc[pp.is_green.eq(green)];ax.scatter(v.final_payment_horizon_years,v.actual_yield_error_bp,s=20,c=color,marker=marker)
  h=pp.loc[pp.split.eq('conventional_holdout')]
  if len(h):ax.scatter(h.final_payment_horizon_years,h.actual_yield_error_bp,s=48,facecolors='none',edgecolors=ORANGE,lw=1.3)
  ax.axhline(0,color=GREY,lw=.7);ax.set(title=SHORT.get(issuer,issuer),ylabel='Model minus quote (bp)',xlim=(0,48));ax.grid(alpha=.16)
 for ax in axes[-1]:ax.set_xlabel('Final payment horizon (years)')
 fig.tight_layout(h_pad=1.5,w_pad=2);finish(fig,out,'Expanded_Pricing_Residuals')

if __name__=='__main__':main()
