"""Create exact empirical reconciliations from completed expansion outputs.

No pricing is done here. Every reported option is imported from a completed
issuer fit. The monthly series remains explicitly pre-option.
"""
from pathlib import Path
import argparse,json
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parents[3]

def read_completed(path):
    frames=[];summaries=[];curves=[]
    for sp in sorted(Path(path).glob('*/summary.json')):
        d=sp.parent
        if not (d/'all_bond_prices.csv').exists():continue
        frames.append(pd.read_csv(d/'all_bond_prices.csv'))
        summaries.append(json.loads(sp.read_text()))
        if (d/'zero_curves.csv').exists():curves.append(pd.read_csv(d/'zero_curves.csv'))
    if not frames:raise ValueError('No completed issuer results')
    return pd.concat(frames,ignore_index=True),summaries,pd.concat(curves,ignore_index=True)

def summarize(prices,summaries):
    ans=[]
    for s in summaries:
        p=prices.loc[prices.issuer.eq(s['issuer'])];g=p.loc[p.is_green];b=p.loc[p.split.eq('conventional_fit')]
        gf=s['green_fit'];cf=s['conventional_fit'];z=gf['z_bp']
        ans.append(dict(issuer=s['issuer'],total=len(p),green=len(g),conventional=len(p)-len(g),conventional_fit=len(b),
            conventional_holdout=int(p.split.eq('conventional_holdout').sum()),
            conventional_yield_rmse_bp=float(np.sqrt(np.mean(b.actual_yield_error_bp**2))),
            green_yield_rmse_bp=float(np.sqrt(np.mean(g.actual_yield_error_bp**2))),
            conventional_weighted_price_rmse_bp=cf['weighted_price_rmse_bp'],
            green_weighted_price_rmse_bp=gf['weighted_price_rmse_bp'],
            common_green_state_bp=z,zero_greenium_5y_bp=z*(-np.expm1(-.5))/.5,
            zero_greenium_20y_bp=z*(-np.expm1(-2))/2,
            green_inside_conventional_maturity_support=int(g.inside_conventional_maturity_support.sum()),
            conventional_min_maturity_years=float(b.final_payment_horizon_years.min()),
            conventional_max_maturity_years=float(b.final_payment_horizon_years.max()),
            maximum_own_option_per100=float(p.actual_option_value_per100.max()),
            maximum_own_option_yield_bp=float(p.actual_option_yield_wedge_bp.max()),
            maximum_green_own_option_per100=float(g.actual_option_value_per100.max()),
            maximum_absolute_green_same_contract_redemption_bp=float(g.redemption_effect_bp.abs().max()),
            conventional_optimizer_success=cf['optimizer_success'],green_optimizer_success=gf['optimizer_success'],
            minimum_credit_forward_bp=cf['global_minimum_forward_bp']))
    return pd.DataFrame(ans)

def matched_decomposition(prices,monthly):
    """Reconcile observed matched yield with model primitives, exactly in bp."""
    ob=prices.set_index('code');latest=prices.month_label.iloc[0]
    sample=monthly.loc[monthly.month_label.eq(latest)];rows=[]
    for r in sample.to_dict('records'):
        codes=[r['brown1_code']];weights=[float(r['weight1'])]
        if pd.notna(r['brown2_code']) and r['weight2']!=0:
            codes.append(r['brown2_code']);weights.append(float(r['weight2']))
        gc=r['green_code']
        if gc not in ob.index or any(c not in ob.index for c in codes):continue
        g=ob.loc[gc];b=ob.loc[codes];w=np.array(weights)
        if not np.isclose(w.sum(),1):raise ValueError('Weights do not sum to one')
        raw=float(r['matched_greenium_clean_assumed_bp'])
        ownstraight=float(g.same_contract_straight_greenium_yield_bp)
        couponcurve=float((w@b.brown_straight_yield_pct-g.brown_straight_yield_pct)*100)
        optioncontract=float(w@b.brown_option_yield_wedge_bp-g.brown_option_yield_wedge_bp)
        optiongreen=float(g.brown_option_yield_wedge_bp-g.green_option_yield_wedge_bp)
        brownres=float(-w@b.actual_yield_error_bp);greenres=float(g.actual_yield_error_bp)
        total=ownstraight+couponcurve+optioncontract+optiongreen+brownres+greenres
        rows.append(dict(issuer=g.issuer,green_code=gc,comparison_method=r['comparison_method'],
            brown1_code=codes[0],brown2_code=codes[1] if len(codes)>1 else '',weight1=weights[0],weight2=weights[1] if len(weights)>1 else 0,
            raw_observed_matched_greenium_bp=raw,
            same_contract_straight_greenium_bp=ownstraight,
            matched_conventional_coupon_curve_difference_bp=couponcurve,
            conventional_contract_option_difference_bp=optioncontract,
            green_effect_on_own_option_yield_bp=optiongreen,
            weighted_conventional_observed_minus_model_yield_bp=brownres,
            green_model_minus_observed_yield_bp=greenres,
            reconstructed_raw_matched_greenium_bp=total,
            exact_reconciliation_error_bp=total-raw,
            gsw_same_cashflow_standardized_preoption_greenium_bp=r['gsw_owncf_yield_greenium_clean_assumed_bp'],
            same_contract_callable_greenium_bp=g.same_contract_callable_greenium_yield_bp,
            common_endpoint_zero_greenium_bp=g.endpoint_zero_greenium_bp,
            inside_conventional_maturity_support=g.inside_conventional_maturity_support))
    return pd.DataFrame(rows)

def monthly_statistics(monthly):
    a=[]
    for name,g in monthly.groupby('comparison_method'):
        raw=g.matched_greenium_clean_assumed_bp;standard=g.gsw_owncf_yield_greenium_clean_assumed_bp
        a.append(dict(method=name,bonds=g.green_code.nunique(),issuers=g.legal_issuer.nunique(),bond_months=len(g),
            raw_mean_bp=raw.mean(),raw_median_bp=raw.median(),standardized_mean_bp=standard.mean(),
            standardized_median_bp=standard.median(),mean_standardization_bp=(standard-raw).mean(),
            mean_absolute_standardization_bp=(standard-raw).abs().mean(),
            mean_absolute_price_basis_sensitivity_bp=g.price_basis_sensitivity_bp.abs().mean(),
            within_quarter_year_screen=int(g.all_legs_at_least_quarter_year.sum())))
    return pd.DataFrame(a)

def main():
    p=argparse.ArgumentParser();p.add_argument('--pricing',required=True);p.add_argument('--override',action='append',default=[])
    p.add_argument('--monthly',default=str(ROOT/'tmp/expansion/benchmarks'));p.add_argument('--out',default=str(ROOT/'output/expanded_master/data'))
    args=p.parse_args();out=Path(args.out);out.mkdir(parents=True,exist_ok=True)
    prices,summaries,curves=read_completed(args.pricing)
    for alt in args.override:
        pp,ss,cc=read_completed(alt);issuers=set(pp.issuer);prices=pd.concat([prices.loc[~prices.issuer.isin(issuers)],pp],ignore_index=True)
        summaries=[s for s in summaries if s['issuer'] not in issuers]+ss
        curves=pd.concat([curves.loc[~curves.issuer.isin(issuers)],cc],ignore_index=True)
    if prices.code.duplicated().any():raise ValueError('Duplicate code across combined results')
    monthly=pd.read_csv(Path(args.monthly)/'matched_panel_monthly_gsw.csv')
    stats=summarize(prices,summaries);decomp=matched_decomposition(prices,monthly)
    prices.sort_values(['issuer','maturity_date']).to_csv(out/'All_Bond_Prices_and_Components.csv',index=False)
    stats.sort_values('issuer').to_csv(out/'Issuer_Pricing_Summary.csv',index=False)
    curves.to_csv(out/'Treasury_Credit_and_Green_Zero_Curves.csv',index=False)
    decomp.to_csv(out/'Matched_Greenium_Exact_Decomposition.csv',index=False)
    monthly_statistics(monthly).to_csv(out/'Monthly_Matched_Summary.csv',index=False)
    green=prices.loc[prices.is_green].copy()
    green['ordering_expected_sign']=np.sign(green.green_state_bp)
    green['signed_option_difference_per100']=green.same_contract_green_minus_brown_option_per100*green.ordering_expected_sign
    se=green.same_contract_option_difference_paired_mc_se_per100
    green['ordering_violation_in_paired_mc_se']=np.where(se>0,np.maximum(0,-green.signed_option_difference_per100)/se,0)
    green.to_csv(out/'Green_Bond_Diagnostics.csv',index=False)
    checks=dict(contracts=len(prices),green_bonds=len(green),issuers=prices.issuer.nunique(),
        maximum_price_decomposition_error_per100=float(prices.price_decomposition_error_per100.abs().max()),
        maximum_yield_bridge_error_bp=float(prices.exact_yield_bridge_error_bp.abs().max()),
        completed_matched_comparisons=len(decomp),
        maximum_matched_decomposition_error_bp=float(decomp.exact_reconciliation_error_bp.abs().max()) if len(decomp) else None,
        same_contract_green_redemption_mean_bp=float(green.redemption_effect_bp.mean()),
        same_contract_green_redemption_mean_absolute_bp=float(green.redemption_effect_bp.abs().mean()),
        green_inside_maturity_support=int(green.inside_conventional_maturity_support.sum()),
        maximum_ordering_violation_paired_se=float(green.ordering_violation_in_paired_mc_se.max()),
        max_own_option_per100=float(prices.actual_option_value_per100.max()),
        max_own_option_yield_bp=float(prices.actual_option_yield_wedge_bp.max()),
        max_same_contract_green_redemption_abs_bp=float(green.redemption_effect_bp.abs().max()),
        monthly_options_valued=False,filtered_states_estimated=False)
    (out/'Empirical_Verification.json').write_text(json.dumps(checks,indent=2))
    print(json.dumps(checks,indent=2))

if __name__=='__main__':main()
