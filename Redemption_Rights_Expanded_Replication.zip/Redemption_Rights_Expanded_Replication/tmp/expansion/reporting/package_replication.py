#!/usr/bin/env python3
"""Build a portable, explicit-input replication tree and optionally archive it.

Default use only stages/records files. A ZIP is made only with --zip and after
final manuscript, figures and result checks pass. Paths below are deliberately
project-relative, preserving the original pricing engines' ROOT calculations.
No preparation pickle, credential file or broad vendor-price dump is selected.
"""
from __future__ import annotations
import argparse
import csv
import hashlib
import json
from pathlib import Path
import shutil
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent
ENGINE = Path('tmp/paper_pricing/engine')
BASE_INPUT = Path('restored/Zero_Coupon_Greenium_Data_and_Code/inventory/inputs/comparison/results')
ALLOWED = {'.py','.md','.txt','.diff','.json','.csv','.gz','.npz','.pdf','.png','.svg','.tex','.bib','.bbl','.sty','.cls','.xlsx','.html','.htm'}
BAD_PARTS = {'__pycache__','cache','caches','.git','.venv','venv','private_library_helpers','smoke','qa','rendered','page_images'}
BAD_NAMES = {'.env','credentials.json','token.json','tokens.json','client_secret.json','service_account.json'}
BAD_SUFFIXES = {'.pkl','.pickle','.pyc','.pyo','.zip','.log','.aux','.out','.toc','.fls','.fdb_latexmk','.synctex','.bak','.tmp'}


def digest(path: Path) -> str:
    h=hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
    return h.hexdigest()


def acceptable(path: Path) -> bool:
    name=path.name.lower()
    return (not any(x in BAD_PARTS or x.startswith('.') for x in path.parts)
            and name not in BAD_NAMES
            and not any(x in name for x in ('credential','client_secret','access_token','refresh_token','library_upload_receipt','materialize_receipt'))
            and path.suffix.lower() in ALLOWED
            and path.suffix.lower() not in BAD_SUFFIXES)


def choose(master: Path, extra: list[str]):
    selected:dict[Path,str]={}
    required=[]
    def file(rel,reason,mandatory=True):
        rel=Path(rel)
        if rel.is_absolute():rel=rel.relative_to(ROOT)
        if mandatory:required.append(rel)
        if (ROOT/rel).is_file():selected[rel]=reason
    def tree(rel,reason,predicate=None):
        rel=Path(rel)
        if rel.is_absolute():rel=rel.relative_to(ROOT)
        p=ROOT/rel
        if p.exists():
            for q in sorted(p.rglob('*')):
                if q.is_file() and acceptable(q.relative_to(ROOT)) and (predicate is None or predicate(q)):
                    selected[q.relative_to(ROOT)]=reason
    # Active new code plus all frozen completed pricing branches; never caches.
    tree('tmp/expansion/pricing','expanded contractual AFNS++ code, scenario inputs and archived results',
         lambda p: p.parent==ROOT/'tmp/expansion/pricing' or 'scenario_inputs' in p.parts or any(x in p.parts for x in ('results','results_expanded','refinement_595620AT','accrued_sensitivity_AL_AN','warm_restart_MidAmerican','archived_MidAmerican_before_warm_restart','archived_Boston_before_calendar_ceiling_correction')))
    monthly_keep={'run_monthly.py','summarize_monthly.py','compare_anchor_results.py','README.md','requirements.txt','environment.json','summary.json'}
    tree('tmp/expansion/benchmarks','monthly code, verified-code input subset, baseline and expanded diagnostics',
         lambda p: ('baseline' in p.parts or 'replication' in p.parts or (p.parent==ROOT/'tmp/expansion/benchmarks' and (p.name in monthly_keep or p.suffix=='.csv' or p.name.startswith('Monthly_Preoption_Greenium.')))))
    file('tmp/expansion/benchmarks/inputs/bond_month_values_final.csv','final merged monthly cashflow input for the expanded contractual pricing branch')
    file('tmp/expansion/benchmarks/inputs/normalized_contracts_final.json','final merged contract register used by the full-universe inventory builder')
    tree('tmp/expansion/contracts','normalized contract facts, source URLs/checksums, record builders and field-level evidence',
         lambda p:p.suffix in {'.json','.csv','.md','.py'})
    tree('tmp/expansion/reporting','postprocessing, plots and replication utilities',
         lambda p: p.parent==HERE and p.suffix in {'.py','.md','.json','.txt'} and p.name!='replication_selection_manifest.json')
    tree('tmp/expansion/reporting/review','independent postprocessing review, reconciliations and theory insert sources')
    tree('tmp/expansion/manuscript','manuscript working sources, merge history, bibliography and empirical template')
    for rel in ['tmp/expansion/reporting/assemble_master.py',
                'tmp/expansion/manuscript/merged_base.tex',
                'tmp/expansion/manuscript/empirical_expanded_template.tex',
                'tmp/expansion/reporting/review/Minimum_Notice_Lemma.tex',
                'tmp/expansion/reporting/review/Signed_Green_Ordering_Corollary.tex']:
        file(rel,'required manuscript assembly source')
    # These metadata ledgers cover the source universe; no broad raw price
    # history is included. The pre-extension ledger supports its final builder.
    tree('tmp/expansion/inventory/final','final full-universe verification ledger, review queue, coverage and reproducible inventory builder')
    for name in ['all_20106_source_codes_inventory_final.csv','contract_verification_ledger_119.csv',
                 'latest_98_contracts_inventory.csv','final_inventory_summary.json']:
        file(Path('tmp/expansion/inventory/final')/name,'required final contract coverage ledger')
    file('tmp/expansion/inventory/all_20106_source_codes_inventory.csv','unchanged pre-extension metadata ledger required to rebuild the final inventory')
    for name in ['README_Expansion_Inventory.md','README_Additional_Conventional_Candidates.md',
                 'expansion_inventory_summary.json','latest_conditional_contracts.json',
                 'latest_conditional_pricing_universe.csv','missing_terms_long.csv',
                 'reviewed_contracts_and_missing_terms.csv','reviewed_issuer_month_coverage.csv',
                 'verified_issuer_expansion_summary.csv','nsp_identity_exclusions.csv',
                 'source_green_issuer_candidate_coverage.csv','additional_conventional_shortlist.csv',
                 'additional_conventional_shortlist_summary.json']:
        file(Path('tmp/expansion/inventory')/name,'frozen contract coverage and inventory diagnostics',False)
    # Original engine modules used by imports. Alternative code is small and
    # preserved together so inherited helpers retain their original identity.
    tree(ENGINE/'alternative/code','original AFNS++ and contractual scheduling modules',lambda p:p.suffix=='.py')
    file(ENGINE/'corporate/code/corporate_data.py','original deterministic credit and green curve classes')
    file(ENGINE/'treasury/code/treasury_curves.py','original Treasury initial-curve code')
    for rel in ['treasury/results/curve_parameters.json','previous/pricing/inputs/selected_latest_config.json',
                'previous/pricing/inputs/treasury_daily_percent.csv']:
        file(ENGINE/rel,'frozen Treasury curve parameters, AFNS covariance or contractual H15 observations')
    for name in ['normalized_contracts.json','contract_eligibility.csv','bond_month_values.csv',
                 'matched_panel_monthly.csv','pair_registry.csv']:
        file(BASE_INPUT/name,'original reviewed register, dated cashflows and pair registry')
    # The contract record builders use the existing selected source universe.
    file('tmp/csv_bond_universe/source/bond_universe.csv','selected original source universe used by normalized contract record builders')
    # Monthly scripts use their own subset when present. Keep the source GSW
    # file as well for provenance and ROOT-based utility compatibility.
    file('tmp/model_comparison/treasury/inputs/gsw_daily_percent.csv','frozen published GSW daily coefficients')
    for name in ['normalized_contracts.json','contract_eligibility.csv','bond_month_values.csv',
                 'matched_panel_monthly.csv','pair_registry.csv','gsw_daily_percent.csv',
                 'monthly_prices.csv.gz','source_provenance.json','extra_contracts.json']:
        file(Path('tmp/expansion/benchmarks/inputs/replication')/name,'portable verified-code monthly inputs')
    tree('output/full_paper/synthetic_replication','complete retained synthetic numerical experiments')
    tree('output/full_paper/literature_verification','verified literature source notes and bibliographic evidence')
    file('output/full_paper/Redemption_Rights_AFNS_Framework_September_25_2026.tex','unchanged prior master source used by the documented theory and literature merge')
    file('output/full_paper/Redemption_Rights_References.bib','unchanged prior bibliography used by the documented theory and literature merge')
    file('upload/Redemption_Rights_AFNS_Framework_September_25_2026_rev5.tex','immutable user-supplied revision 5 source reference')
    tree(master,'final manuscript source, bibliography, PDF, empirical result tables and publication figures')
    for item in extra:file(item,'additional final artifact explicitly requested for the archive')
    missing=[str(p) for p in required if not (ROOT/p).is_file()]
    return selected,missing


def rebase(value):
    prefix=ROOT.as_posix()+'/'
    if isinstance(value,str):return value[len(prefix):] if value.startswith(prefix) else value
    if isinstance(value,list):return [rebase(x) for x in value]
    if isinstance(value,dict):return {rebase(k):rebase(v) for k,v in value.items()}
    return value


def final_checks(master:Path,selected:dict[Path,str]):
    root=ROOT/master
    failures=[]
    if not list(root.glob('*.tex')):failures.append('No final manuscript .tex at master root')
    if not list(root.glob('*.pdf')):failures.append('No final manuscript .pdf at master root')
    if not list(root.glob('*.bib')):failures.append('No bibliography .bib at master root')
    if not list((root/'figures').glob('*.pdf')):failures.append('No publication PDF figures')
    for name in ['All_Bond_Prices_and_Components.csv','Issuer_Pricing_Summary.csv',
                 'Treasury_Credit_and_Green_Zero_Curves.csv','Empirical_Verification.json',
                 'Monthly_Matched_Summary.csv','Matched_Greenium_Exact_Decomposition.csv',
                 'Manuscript_Build_Checks.json']:
        if not (root/'data'/name).is_file():failures.append('Missing final empirical table: '+name)
    for branch in ['results','results_expanded']:
        folder=ROOT/'tmp/expansion/pricing'/branch
        cfg=folder/'run_configuration.json'
        if not cfg.exists():failures.append('Missing pricing configuration: '+branch);continue
        run=json.loads(cfg.read_text());expected=set(run.get('codes',[]));found=[]
        for table in folder.glob('*/all_bond_prices.csv'):
            with table.open(newline='') as f:found.extend(row['code'] for row in csv.DictReader(f))
        if expected!=set(found) or len(found)!=len(set(found)):
            failures.append('Incomplete or duplicate completed pricing rows in '+branch+': expected '+str(len(expected))+'; unique found '+str(len(set(found))))
    commands=HERE/'replication_commands.json'
    if not commands.is_file():failures.append('Final replication_commands.json not recorded')
    elif not json.loads(commands.read_text()).get('finalized',False):failures.append('Replication commands still marked provisional')
    return failures


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--master',type=Path,default=Path('output/expanded_master'))
    ap.add_argument('--stage',type=Path,default=Path('tmp/expansion/replication_stage/Redemption_Rights_Expanded_Replication'))
    ap.add_argument('--manifest-only',action='store_true')
    ap.add_argument('--allow-partial',action='store_true',help='permit a draft staging inventory; never permitted with --zip')
    ap.add_argument('--zip',type=Path,help='explicit final archive path; omitted by default')
    ap.add_argument('--extra-include',action='append',default=[])
    args=ap.parse_args()
    master=args.master.resolve().relative_to(ROOT) if args.master.is_absolute() else args.master
    stage=args.stage if args.stage.is_absolute() else ROOT/args.stage
    stage=stage.resolve()
    if stage==ROOT or ROOT.is_relative_to(stage):raise ValueError('Stage must not contain or replace the live project root')
    if any(stage==ROOT/p or stage.is_relative_to(ROOT/p) for p in ['tmp/expansion/pricing','tmp/expansion/benchmarks','tmp/expansion/contracts','tmp/expansion/reporting',str(master)]):
        raise ValueError('Stage must be outside selected live source/result directories')
    selected,missing=choose(master,args.extra_include)
    checks=final_checks(master,selected)
    if args.zip and (args.allow_partial or missing or checks):
        raise SystemExit(json.dumps({'error':'Final ZIP refused: incomplete or provisional deliverables','missing_inputs':missing,'final_checks':checks},indent=2))
    if missing and not args.allow_partial:raise SystemExit(json.dumps({'missing_inputs':missing},indent=2))
    codes=set()
    for reg in [ROOT/BASE_INPUT/'normalized_contracts.json',ROOT/'tmp/expansion/benchmarks/inputs/replication/extra_contracts.json']:
        if reg.exists():
            parsed=json.loads(reg.read_text()); rows=parsed.get('contracts',parsed) if isinstance(parsed,dict) else parsed
            for row in rows:
                code=row.get('source_code') or row.get('issue_code') or row.get('Code')
                if code:codes.add(code)
    files=[]
    for rel,reason in sorted(selected.items()):
        source=ROOT/rel
        if not acceptable(rel):continue
        if not source.resolve().is_relative_to(ROOT):raise ValueError('Source resolves outside project: '+str(rel))
        if source.stat().st_size>64*1024*1024:raise ValueError('Unexpected large selected file: '+str(rel))
        files.append({'path':rel.as_posix(),'purpose':reason,'bytes':source.stat().st_size,'source_sha256':digest(source)})
    overview={'project':'Redemption Rights and the Greenium — expanded empirical replication',
              'source_root_at_build':str(ROOT),'master_path':str(master),'file_count':len(files),
              'source_bytes':sum(x['bytes'] for x in files),'missing_inputs':missing,'final_checks':checks,
              'exclusions':['preparation pickle caches','__pycache__ and bytecode','credentials and connector-transfer helpers',
                            'the broad raw 20,106-code vendor-price file','LaTeX build and visual-QA intermediates','previous ZIP archives'],
              'files':files}
    if args.manifest_only:
        dest=HERE/'replication_selection_manifest.json';dest.write_text(json.dumps(overview,indent=2)+'\n')
        print(json.dumps({'manifest':str(dest),'file_count':len(files),'source_bytes':overview['source_bytes'],'missing_inputs':missing,'final_checks':checks},indent=2));return
    stage.mkdir(parents=True,exist_ok=True)
    wanted=set()
    for item in files:
        rel=Path(item['path']);source=ROOT/rel;dest=stage/rel
        dest.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(source,dest);wanted.add(dest)
        if rel.as_posix()=='tmp/csv_bond_universe/source/bond_universe.csv':
            with source.open(newline='') as f:
                reader=csv.DictReader(f);fieldnames=reader.fieldnames;rows=[row for row in reader if row.get('Code') in codes]
            with dest.open('w',newline='') as f:
                writer=csv.DictWriter(f,fieldnames=fieldnames);writer.writeheader();writer.writerows(rows)
            item['transformation']='Only rows for original reviewed or newly added verified contract codes retained; original cell strings unchanged.'
            item['subset_rows']=len(rows)
        if source.name=='run_configuration.json':
            original=dest.with_name('run_configuration.original.json')
            shutil.copy2(source,original);wanted.add(original)
            dest.write_text(json.dumps(rebase(json.loads(source.read_text())),indent=2)+'\n')
            item['transformation']='Only project-root prefixes in path strings rebased to archive-relative paths; original JSON preserved alongside.'
        item['archive_sha256']=digest(dest)
        item['archive_bytes']=dest.stat().st_size
    readme=stage/'README.md';readme_text=(HERE/'README_REPLICATION.md').read_text()
    manuscripts=sorted((ROOT/master).glob('*.tex'))
    if len(manuscripts)==1:readme_text=readme_text.replace('MANUSCRIPT',manuscripts[0].stem)
    readme.write_text(readme_text);wanted.add(readme)
    for name in ['requirements-replication.txt','replication_environment.json','replication_commands.json']:
        source=HERE/name
        if source.exists():dest=stage/name;shutil.copy2(source,dest);wanted.add(dest)
    manifest=stage/'REPLICATION_MANIFEST.json';manifest.write_text(json.dumps(overview,indent=2)+'\n');wanted.add(manifest)
    # Remove stale files only inside this dedicated staging directory, never
    # in the live workspace. This avoids shipping superseded result branches.
    for old in stage.rglob('*'):
        if old.is_file() and old not in wanted:old.unlink()
    for old in sorted(stage.rglob('*'),reverse=True):
        if old.is_dir() and not any(old.iterdir()):old.rmdir()
    checksum=stage/'MANIFEST.sha256'
    checksum.write_text(''.join(digest(f)+'  '+f.relative_to(stage).as_posix()+'\n' for f in sorted(stage.rglob('*')) if f.is_file() and f!=checksum))
    message={'stage':str(stage),'files':sum(p.is_file() for p in stage.rglob('*')),'source_bytes':overview['source_bytes'],'missing_inputs':missing,'final_checks':checks}
    if args.zip:
        target=args.zip if args.zip.is_absolute() else ROOT/args.zip
        if target.resolve().is_relative_to(stage):raise ValueError('ZIP must be outside staging tree')
        target.parent.mkdir(parents=True,exist_ok=True)
        with zipfile.ZipFile(target,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
            for f in sorted(stage.rglob('*')):
                if f.is_file():z.write(f,Path(stage.name)/f.relative_to(stage))
        message.update(zip=str(target),zip_bytes=target.stat().st_size,zip_sha256=digest(target))
    print(json.dumps(message,indent=2))

if __name__=='__main__':main()
