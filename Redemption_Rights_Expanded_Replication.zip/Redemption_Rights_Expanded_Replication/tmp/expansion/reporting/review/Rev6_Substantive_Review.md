# Substantive review of expanded rev6 master

Reviewed `output/expanded_master/Redemption_Rights_AFNS_Master_rev6.tex` against the final expanded data, monthly summaries, refinement output, and independent matched reconciliation. No master source was changed. This memo records the master before the parent's final MidAmerican optimizer and AT diagnostic additions.

## Outcome

The expanded empirical scope is internally consistent: 114 historical contracts and 10,398 monthly cash-flow observations; 34 green bonds and 2,624 supported green bond-months; and 98 dated callable-valued contracts, comprising 32 green and 66 conventional contracts across eight issuers. The 19-green adapted matching exercise is correctly distinguished from the broader 34-green issuer-curve coverage. All 98 contracts have both-kernel calculations; the 37 matched decompositions reconcile at numerical precision.

The abstract, empirical section and conclusion properly distinguish monthly pre-option conditional fits from the one-date callable valuation. Neither is described as a filtered dynamic state-space estimation. The AFNS++ Treasury fit, driftless credit-level restriction, zero empirical credit/green diffusion and imposed green maturity shape are visible. The earlier stochastic-credit pilot is described as a development diagnostic, not pooled into the new option estimates. Matched-yield comparison is accurately distinguished from provider-OAS testing and Zerbib's liquidity-regression stage.

## Exact text corrections

### 1. Introduction: signed option ordering

In the paragraph beginning “The two embedded rights need separate valuations,” replace:

> The empirical specialization used below has this property. Its small negative simulated option differences are consequently numerical outcomes, not evidence of a reversal of that restricted ordering.

with:

> The positive-state empirical cases satisfy this restriction; deterministic negative-state cases satisfy the reverse ordering after interchanging the kernels. Estimated violations of the appropriate price-option ordering are assessed against simulation and policy-approximation error.

The positive-only sentence is stale because Boston Properties and Equinix have negative common green states. The signed counterpart already appears after the deterministic-ordering proposition and in the empirical diagnostics. It applies to option prices, not automatically to their nonlinear yield wedges.

### 2. Monthly matching table

In `tab:expanded_matched`, change the column heading **Months** to **Bond-months**. The values 1,395, 807 and 619 count observations, not distinct months.

### 3. Issuer fit table objective

In the footnote to the issuer fit table, change:

> optimization minimizes squared price residuals divided by observed DV01

to:

> optimization minimizes squared DV01-scaled price residuals

The objective is the square of the price residual divided by DV01, so the existing wording can incorrectly suggest division by DV01 only once. Exact yield RMSE and option yield wedges are separately and correctly calculated by yield inversion.

### 4. Matched reconciliation output location

After equation `eq:expanded-matched-decomposition`, “The accompanying table gives every available latest-date matched reconciliation” can imply a manuscript table, but the 37-row table is in the deliverable data. Suggested replacement:

> The accompanying data file `Matched_Greenium_Exact_Decomposition.csv` gives every available latest-date matched reconciliation on unrounded data.

Use `\path{Matched_Greenium_Exact_Decomposition.csv}` in TeX if retaining the filename.

## AT refinement and state-sensitivity paragraph

The largest redemption correction is concentrated in MidAmerican `595620AT`, whose maturity lies outside the conventional fitting envelope. The green mean absolute correction across 32 bonds is 0.146469 bp; excluding AT it is 0.036610 bp, and the full-sample median absolute correction is 0.014970 bp. The mean therefore should not be presented as broadly representative of the cross-section without this concentration information. The AT common-state callable yield residual is −19.847240 bp.

The reference-to-refined numerical comparison holds parameters fixed and uses an independent simulation seed: training paths rise from 768 to 1,536; evaluation paths from 2,304 to 4,608; the grid step falls from 30 to 15 days; and fixing quadrature points rise from 32 to 64. The correction changes from −3.552116 to −3.530399 bp, a +0.021717 bp change. This is a numerical sensitivity, not a global stopping-error bound.

The larger sensitivity is to the green state. Suggested source-consistent wording:

> At fixed conventional parameters, replacing the common green state of 60.913 bp by the bond-specific state of 38.932 bp obtained from a frozen-option straight-price inversion reduces the same-contract redemption correction from −3.552 to −1.076 bp after one option reprice. The resulting callable yield residual is −2.506 bp, so this is a state-sensitivity diagnostic, not a completed recursive callable inversion or a confidence interval.

The common-state own option is 0.118974 per 100; one repricing at the individual state gives 0.058734. The 38.932 bp state is **not** a self-consistent callable-price inversion: its initial straight inversion holds the common-state option add-back fixed, and the option is repriced only once. The correction's state-sensitivity shift is +2.476522 bp, far larger than the +0.021717 bp numerical refinement shift. Report it as maintained-state sensitivity, not formally estimated parameter uncertainty. The fixed-shape common fit's residuals remain the primary empirical fit diagnostic.

## Checks completed

- Coverage counts, maturity-support counts, issuer RMSE/state numbers, monthly means and sensitivity aggregates agree with the stored outputs. Fifteen of the 32 current green maturities are inside their conventional fitting envelopes; MidAmerican has zero of seven, and NSP one of five. The figures show this support distinction.
- The independent reconciliation rerun covers all 98 contracts and all 37 matched comparisons. Maximum identity error is 8.8818e-14 bp and maximum source alignment error is 2.4347e-10 bp; all leg prices, dates, issuers and labels agree. No sign or unit correction is needed in the decomposition.
- Nearest-comparator monthly matching has 1,395 observations over 19 green bonds; nearest within two years has 807 over 12; maturity bracketing has 619 over nine. The common-sample comparator sensitivity is correctly stated as 3.43 bp mean absolute difference, with 96 sign reversals out of 619 (15.5%).
- The price-basis sensitivity is correctly described as unresolved source metadata rather than evidence selecting the correct field interpretation. The two failed monthly optimizer alternatives belong to the dirty-assumed sensitivity, not the primary clean-assumed branch; the manuscript does not claim all alternatives converged.
- NSP's genuinely noncallable 2028 instrument is distinguished from finite-path zero estimates on callable contracts. MidAmerican's unusual 2036 terminal interest stub and later security status are retained.
- The minimum-notice appendix includes the necessary finite-grid closure qualification, preserves the same redemption/fixing cash flows, and does not overextend the result to funded-versus-unfunded cancellation choices or notice-relative fixing contracts.
- No duplicate labels, undefined references or missing referenced figure files were found in the reviewed source. The greenium-curve and monthly-comparison figures visually match their captions and sample scope.

Optional figure wording: the legend “Observed nearest matched yield” can be made more precise as “Observed nearest matched greenium”; the plotted quantity is the yield differential. This is a presentation improvement, not a numerical issue.

## Remaining parent-owned integration

Apply the four narrow text corrections, append the AT concentration/refinement/state-sensitivity diagnostic, and document the final MidAmerican optimizer disposition after its warm restart. A failed convergence flag should not silently become a claim of converged estimation; convergence is distinct from the fact that every contract can be valued at the maintained parameter vector. No further theory or literature rewrite is required for this revision.
