# Independent review of empirical reconciliation and scope

Reviewed `tmp/expansion/reporting/build_empirical_outputs.py` and the source definitions in `pricing/run_expanded_batch.py`, `pricing/expansion_data.py`, and `benchmarks/run_monthly.py`. No reporting script or master manuscript was changed. The row audit is reproducible with `tmp/expansion/reporting/review_reconciliation.py`.

## Finding: the matched reconciliation is correct

Let yields below be expressed in basis points. Write `e_j = y_j(call, model) - y_j(observed)` and `q_j^B = y_j(B, call) - y_j(B, straight)`, with the corresponding green wedge `q_g^G`. The weighted matched observed spread is exactly:

\[
\begin{aligned}
\sum_b w_b y_b^{obs}-y_g^{obs}
={}&(y_g^{B,str}-y_g^{G,str})\\
&+(\sum_b w_b y_b^{B,str}-y_g^{B,str})\\
&+(\sum_b w_b q_b^B-q_g^B)\\
&+(q_g^B-q_g^G)\\
&-\sum_b w_b e_b+e_g.
\end{aligned}
\]

These are precisely the six terms in `matched_decomposition`. There is no missing option term and no sign reversal to fix.

| Saved term | Meaning and sign |
|---|---|
| Same-contract straight greenium | Conventional-minus-green fitted straight yields on the green bond's schedule |
| Conventional coupon/curve difference | Weighted conventional straight yields minus the green schedule's conventional straight yield |
| Conventional contract option difference | Weighted comparator option yield wedges minus the green contract's conventional wedge |
| Green effect on own option yield | Conventional-minus-green wedge on the green contract; equals callable-minus-straight same-contract greenium |
| Conventional residual contribution | Weighted observed-minus-model conventional yield |
| Green residual contribution | Model-minus-observed green yield |

`*_yield_pct` is in percentage points and is multiplied by 100 to obtain bp. `*_yield_error_bp` and `*_option_yield_wedge_bp` are already in bp and receive no further scaling. Source code calculates each wedge by solving the two exact yield equations; it does not replace it with option price divided by DV01. DV01 division is used separately for the approximate yield-unit price objective and conditional Monte Carlo error, whose labels distinguish it from the exact yield RMSE.

The option-contract term's sign follows the matched-yield convention. Its price-premium counterpart can have the opposite-looking sign because it starts from a green-minus-conventional price difference. One must retain each formula's units and orientation when describing it.

## Independent completed-row check

At audit time, four completed issuer directories supplied 29 contracts and 12 green bonds. Eleven latest-date matched comparisons had every leg available. Raw observed yields and model straight/callable yields, rather than the stored component columns, reproduce the six-term identity with maximum error **8.9e-14 bp**. The direct observed spread differs from the archived monthly raw spread by at most **2.44e-10 bp**. Prices agree exactly; no date, legal-issuer or green/conventional label mismatch was found. Error and option-wedge definitions agree with their raw yields to less than **1e-13 bp**. These checks cover the completed subset at that time, not the final still-running expansion.

The audit outputs are `independent_checks.json`, `independent_matched_reconciliation.csv`, and `matched_source_alignment.csv`.

### Final expanded-sample rerun

The subsequent rerun covers **all 98 contracts, 32 green bonds, eight issuers and 37 matched comparisons**. The maximum independently reconstructed identity error is **8.8818e-14 bp**; maximum discrepancy from the monthly matched source is **2.4347e-10 bp**. Individual leg yields agree within **2.2889e-10 bp**, prices agree exactly, and all date, issuer and label checks pass. Yield-error and option-wedge definitions agree within **1.7e-13 bp**. All eight issuer outputs maintain `mu=.1`, `theta=0`, zero green diffusion, and row-level states agreeing with the summary. The JSON and CSV audit outputs now refer to this final expanded sample. They supersede the provisional completed-subset coverage above.

## Interpretation and narrow guardrails

1. The coupon/curve term is not a pure coupon effect: it includes the complete fitted conventional curve and weighted comparator schedules. The endpoint-zero bridge likewise combines coupon, curve and payment-timing effects after the exact compounding term.
2. Green diagnostics correctly test option ordering in **price units**. The negative deterministic fixed-sign case follows by interchanging B/G in the nonnegative-service proposition. `Signed_Green_Ordering_Corollary.tex` supplies this missing explanation. The present reviewed parameters have `mu=.1`, `theta=0`, and zero green diffusion, so their sign is fixed over the horizon. Current negative-state cases are not covered by the positive-service statement alone.
3. If the program is reused with nonzero long-run green level, nonzero diffusion, or sign-changing deterministic service, `sign(current z)` is insufficient for the ordering diagnostic. It should then be suppressed or conditioned on a verified full-path ordering. At exactly zero state under the present specification, equality should be checked directly; multiplying the difference by `sign(0)=0` would conceal an implementation mismatch. A positive violation with zero reported SE must not be silently converted to zero significance.
4. The hard-coded five- and twenty-year zero-greenium formulas are correct for the current `mu=.1`, `theta=0`, zero-diffusion specification. They should be checked against `green_fit` metadata or read from the curve output before reuse with other shape restrictions. The inspected row states agree with their summary states to numerical precision.
5. The report assumes a single aligned valuation date and month across all combined issuer directories. That holds for the inspected data. A one-line uniqueness assertion and leg-level price/date consistency checks would prevent a future override from silently mixing vintages. An explicit finite reconciliation tolerance, e.g. `1e-6 bp`, would turn the currently exported maximum-error diagnostic into a failure gate. No current numerical failure was found.
6. The reported green redemption means are unweighted means across green bonds, not equal-issuer means or panel estimates. Their signed mean can cancel across bonds. Paired Monte Carlo SEs are conditional on learned policies and maintained parameters; they exclude fit, policy and specification uncertainty. Current maximum ordering deviation was 1.86 paired SE before further refinements.

## Minimum-notice result

`Minimum_Notice_Lemma.tex` formalizes the contract audit's tower-property argument. It applies to frictionless funded irrevocable commitments when delaying notice preserves the same redemption/fixing cash flows. Positivity of the effective kernel suffices; neither nonnegative green service nor deterministic credit is needed. The finite-grid result requires closure under `(notice, redemption) -> (latest admissible notice, same redemption)`. Notice-relative fixing families, binding financing changes, conditional-cancellation rights and intensity-restricted policies are outside the result. The source is the maintained commitment valuation in the manuscript and the implementation assessment in `contracts/Contract_Adapter_Audit.md`; this is a deduction within that model, not a new legal claim.

## Stale bridges to check in root's new empirical master

- Abstract, introduction and roadmap must replace the old 26-Verizon-only counts and results.
- The Pietsch/OAS literature paragraph must acknowledge the completed adapted matching comparison while retaining the absence of provider-OAS testing and of Zerbib's liquidity-regression stage.
- The estimation section must distinguish monthly **pre-option dated fits** from the refined callable **dated issuer cross-sections**. Neither is a filtered-state panel estimator. Zero credit/green diffusion cannot simultaneously support an independently stochastic physical law through equivalent-measure drift adjustment.
- The deterministic-ordering bridge must be conditional on positive service, with the signed corollary if negative-state order is reported. Neither order should be read directly as an order of yield wedges.
- The empirical Treasury specification is AFNS++ fitted to the GSW initial curve; old H.15 Treasury-kernel fit errors belong only in the older pilot discussion. H.15 observations continue to enter contracts that actually specify them.
- The old stochastic-spread pilot's tail shares and coarse Monte Carlo averages are diagnostic history, not new panel option results. More monthly rows do not refine those option runs.
- Unverified source price metadata, actual dealer fixing proxies, funded-notice restrictions and calendar approximations must remain visible without calling all input terms fully verified.
- Conclusion and replication notes must give the final actual completed counts and separate candidate-universe, schedule-covered, matched, and callable-valued coverage.
