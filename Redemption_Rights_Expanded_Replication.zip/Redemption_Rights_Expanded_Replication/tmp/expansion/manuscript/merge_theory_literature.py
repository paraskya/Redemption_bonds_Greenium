"""Build the expansion master from the audited latest theory; preserve empirical text."""
from pathlib import Path
import re
import shutil

ROOT = Path(__file__).resolve().parents[3]
BASE = ROOT/'output/full_paper/Redemption_Rights_AFNS_Framework_September_25_2026.tex'
OUT = ROOT/'tmp/expansion/manuscript'
OUT.mkdir(parents=True,exist_ok=True)
s=BASE.read_text()

tips = r'''A related identification strategy appears in \citet{AndreasenChristensenRiddell2021}. Their arbitrage-free nominal--real term-structure model extracts a common liquidity factor from individual TIPS prices using security-specific loadings tied to time since issuance. Their price equation also includes the embedded deflation option. This is a useful precedent for connecting a fitted valuation component to individual contractual prices, and for distinguishing the component's dynamics from the bond-level variation that identifies its exposure. Here the additional component concerns green valuation within an issuer, and the relevant contractual contingency is issuer redemption. The identification conditions therefore depend on the available conventional and green securities and their effective payment exposures.'''
anchor = 'Corporate pricing also draws on the reduced-form approach'
assert s.count(anchor)==1
s=s.replace(anchor,tips+'\n\n'+anchor)

caramichael = r'''The issuance literature also allows the effect of callability to vary with market conditions. In the working-paper version of \citet{CaramichaelRapp2024}, \citet{CaramichaelRapp2022} interact a callable-bond indicator with the level, slope, curvature and realized volatility of the sovereign yield curve. These controls recognize state dependence in the pricing of call features. The present model specifies the underlying redemption terms and evaluates their continuation and commitment values jointly with the green component. Its contribution should therefore be assessed against existing state-dependent controls as well as provider OAS and matched-yield methods.'''
anchor = '\\citet{PietschSalakhova2025} use Bloomberg option-adjusted spreads'
assert s.count(anchor)==1
s=s.replace(anchor,caramichael+'\n\n'+anchor)

old = 'The empirical green path, with positive current state, zero diffusion and zero long-run mean, satisfies this restriction. Small estimated negative differences between its two option values must therefore be assessed as simulation or policy-approximation outcomes. They cannot serve as empirical examples of the lack of an ordering in the unrestricted model. The latter result concerns green valuation that can change sign over future remaining horizons, as in the following example.'
new = 'Whenever the conditional empirical specialization uses a positive current green state, zero green diffusion and zero long-run mean, its green path satisfies this restriction. Small estimated negative differences between the two option values in that case must therefore be assessed as simulation or policy-approximation outcomes. They cannot serve as empirical examples of the lack of an ordering in the unrestricted model. A fitted negative green state falls outside this sufficient condition. The general result also permits green valuation that changes sign over future remaining horizons, as in the following example.'
assert s.count(old)==1
s=s.replace(old,new)
s=s.replace('\\subsection{Local identification and singular cases}\n','\\subsection{Local identification and singular cases}\n\\label{sec:identification}\n')

emp_start='\\section{Conventional and green bond prices in the Verizon application}'
emp_end='\\section{Conclusion}'
start=s.index(emp_start);end=s.index(emp_end,start)
old_empirical=s[start:end]
s=s[:start]+'% BEGIN EMPIRICAL REPLACEMENT BLOCK -- original latest cross-section preserved verbatim\n'+old_empirical+'% END EMPIRICAL REPLACEMENT BLOCK\n\n'+s[end:]

# Mark the other frozen result-dependent passages without changing their claims yet.
s=s.replace('\\begin{abstract}\n','\\begin{abstract}\n% ROOT UPDATE: replace dated empirical claims from completed expanded outputs.\n',1)
s=s.replace('The empirical application values 26 Verizon contracts on 31 August 2026.', '% BEGIN INTRODUCTION EMPIRICAL REPLACEMENT -- three paragraphs\nThe empirical application values 26 Verizon contracts on 31 August 2026.',1)
s=s.replace('Section~\\ref{sec:literature} situates the contribution.','% END INTRODUCTION EMPIRICAL REPLACEMENT\n\nSection~\\ref{sec:literature} situates the contribution.',1)
s=s.replace('\\section{Conclusion}\n','\\section{Conclusion}\n% ROOT UPDATE: conclusion retains the old cross-section until expanded outputs are inserted.\n',1)
s=s.replace('\\section{Replication materials}\n','\\section{Replication materials}\n% ROOT UPDATE: replace archive inventory and empirical scope for the expansion package.\n',1)

(OUT/'merged_base.tex').write_text(s)
assert old_empirical == BASE.read_text().split(emp_start,1)[1].split(emp_end,1)[0].join([emp_start,''])

bib=(ROOT/'output/full_paper/Redemption_Rights_References.bib').read_text()
extra=r'''

% Additions from rev5, verified against publisher/author-institution sources.
@article{AndreasenChristensenRiddell2021,
  author = {Andreasen, Martin M. and Christensen, Jens H. E. and Riddell, Simon},
  title = {The {TIPS} Liquidity Premium},
  journal = {Review of Finance},
  year = {2021},
  volume = {25},
  number = {6},
  pages = {1639--1675},
  doi = {10.1093/rof/rfab018},
  url = {https://academic.oup.com/rof/article/25/6/1639/6410663}
}

@techreport{CaramichaelRapp2022,
  author = {Caramichael, John and Rapp, Andreas C.},
  title = {The Green Corporate Bond Issuance Premium},
  institution = {Board of Governors of the Federal Reserve System},
  type = {International Finance Discussion Papers},
  number = {1346},
  year = {2022},
  doi = {10.17016/IFDP.2022.1346},
  url = {https://www.federalreserve.gov/econres/ifdp/files/ifdp1346.pdf}
}

@article{CaramichaelRapp2024,
  author = {Caramichael, John and Rapp, Andreas C.},
  title = {The Green Corporate Bond Issuance Premium},
  journal = {Journal of Banking and Finance},
  year = {2024},
  volume = {162},
  pages = {107126},
  doi = {10.1016/j.jbankfin.2024.107126},
  url = {https://www.sciencedirect.com/science/article/pii/S0378426624000463}
}
'''
for key in ['AndreasenChristensenRiddell2021','CaramichaelRapp2022','CaramichaelRapp2024']:
    assert not re.search(r'@\w+\{'+key+r'\s*,',bib)
(OUT/'Redemption_Rights_References.bib').write_text(bib+extra)

refs=set()
for match in re.finditer(r'\\cite\w*\*?(?:\[[^\]]*\])*\{([^}]+)\}',s):
    refs.update(x.strip() for x in match.group(1).split(','))
keys=re.findall(r'@\w+\{([^,]+),',bib+extra)
assert len(keys)==len(set(keys)), 'Duplicate bibliography keys'
assert not refs-set(keys), refs-set(keys)
labels=re.findall(r'\\label\{([^}]+)\}',s)
assert len(labels)==len(set(labels)), 'Duplicate labels'
print('Created merged_base.tex and bibliography; empirical block unchanged.')
print('Bibliography entries:',len(keys),'Cited keys:',len(refs),'Labels:',len(labels))
