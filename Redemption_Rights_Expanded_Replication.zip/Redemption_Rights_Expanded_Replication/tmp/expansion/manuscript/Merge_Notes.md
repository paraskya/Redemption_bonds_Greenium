# Theory and literature merge for the expansion

## Files

- `merged_base.tex`: latest audited theory and original latest empirical section, with bounded additions below.
- `Redemption_Rights_References.bib`: latest verified bibliography plus three entries from rev5.
- `empirical_scope.tex`: optional replacement-section prose; no uncompleted counts or results supplied.
- `merge_theory_literature.py`: deterministic merge and citation/label checks.
- `theory_branch_differences.txt`: full body comparison of latest theory versus rev5.

## Base and preservation

Base: `output/full_paper/Redemption_Rights_AFNS_Framework_September_25_2026.tex`. The supplied rev5 remains unmodified. Author names, title, style, complete equations/propositions/proofs and all numerical tables from the latest baseline are retained. The empirical section beginning `Conventional and green bond prices in the Verizon application` is preserved verbatim between the explicit `BEGIN/END EMPIRICAL REPLACEMENT BLOCK` comments for root to replace.

The merge retains the dedicated Related Literature section, the explicit holding-service equation and issuer-objective qualification, the driftless AFNS credit-level baseline, optional mean-reverting extension, the full-rank/range condition for measure equivalence, the AFNS++ deterministic initial-curve shift, and the deterministic nonnegative-green-service ordering proposition and proof. It also retains the bounded-intensity regularity qualification and the distinction between a forward Van Loan covariance computation and identification of a generator from data. None of these is replaced with rev5's older formulation.

## Exact substantive changes

1. Added one paragraph in **Related Literature / Affine and Nelson--Siegel term structures** on Andreasen–Christensen–Riddell: individual TIPS prices, a common liquidity factor with security-age loadings, and explicit deflation-option valuation. This is the useful methodological analogy in rev5; no claim that the green factor is thereby identified is made.
2. Added one paragraph in **Related Literature / Green valuation and empirical greenium measurement** on Caramichael–Rapp's state-dependent callability controls. The specific interaction claim cites the 2022 working paper; the 2024 final publication is also retained.
3. Added the rev5 cross-reference label `sec:identification` to **Local identification and singular cases**.
4. Qualified only the empirical bridge following Proposition `prop:deterministicordering`: the sufficient ordering holds when the conditional green state is positive with zero diffusion and zero long-run mean. The expanded signed-state fits do not all satisfy nonnegativity. Proposition and proof are unchanged.
5. Added comments marking result-dependent abstract, introduction, empirical, conclusion and replication text for replacement. These comments make no new empirical claims.

No other theory rewrite was made. The newer nearby predecessors remain: Agliardi–Agliardi; Kanamura; D'Amico–Klausmann–Pancost; Mercuri–Rroji–Stefani; Feldhütter–Halskov–Krebbers; and the full AFNS, callable, make-whole and matching/OAS lineage.

## Primary verification for additions

**Andreasen, Christensen and Riddell (2021), The TIPS Liquidity Premium.** Publisher metadata verifies *Review of Finance* 25(6), 1639–1675, DOI 10.1093/rof/rfab018: [publisher](https://academic.oup.com/rof/article/25/6/1639/6410663). The [author-institution working paper](https://www.frbsf.org/wp-content/uploads/wp2017-11.pdf), Section 3.3 and Section 4.2, supplies the precise pricing and identification analogy. Equation (15) includes the deflation option; the loading normalization is discussed on printed p. 16. The new text describes the method, not their numeric premium estimates.

**Caramichael and Rapp (2022/2024), The Green Corporate Bond Issuance Premium.** The [Federal Reserve working paper](https://www.federalreserve.gov/econres/ifdp/files/ifdp1346.pdf), printed p. 12 (PDF p. 12 zero-based), explicitly interacts callability with sovereign-curve level, slope, curvature and realized volatility. The [publisher article](https://www.sciencedirect.com/science/article/pii/S0378426624000463) verifies the final DOI 10.1016/j.jbankfin.2024.107126; rev5's final journal/year/volume/article metadata is retained. The interaction attribution remains version-specific because the complete final text was not available. No publication permission request is needed to cite this public working paper.

## Result-sensitive bridges root must update with its empirical section

Beyond the bounded replacement section, update the abstract, the three empirical introduction paragraphs, and the introduction roadmap; the last sentence of the Pietsch/OAS literature paragraph still says the old Verizon application supplies neither matched-yield nor OAS comparison. The new matching results require changing that sentence without implying an OAS comparison. **Observation channels and staged estimation** and the final **Empirical estimands and comparison design** paragraph still describe the old single dated issuer scope; these should distinguish monthly pre-option fits and the new dated callable expansion. The exact initial-curve subsection can retain its caution that reconditioning at multiple dates is a sequence of conditional fits. Update conclusion and replication inventory. All relevant comments are in `merged_base.tex`.

`empirical_scope.tex` provides concise draft language for the starting universe versus verified valuation sample, monthly pre-option versus callable scope, signed conditional green curves, Zerbib matching versus the full estimator, and old stochastic-pilot diagnostics. It intentionally supplies no changing coverage counts.

## Validation performed

The merge script asserts that the old empirical section is unchanged, checks all cited keys against the combined bibliography, rejects duplicate bibliography keys and duplicate labels, and leaves actual PDF compilation/rendering to root after inserting the expanded results. Figure dependencies remain the original `figures/` directory and must be copied with the finished manuscript. Do not circulate this intermediate base before the marked result-dependent passages are replaced.
