# Expanded monthly bond comparisons

The completed panel contains 10,398 dated cash-flow observations across 114 verified eligible contracts. A same-issuer conventional curve is available for 2,624 green bond-months, covering 34 green bonds and eight legal issuers. Of these, 1,395 lie within the observed conventional maturity range. Availability of a conventional quote and maturity support are distinct conditions.

## Valuation and estimation

Every cash flow uses the contractual coupon schedule, US 30/360 accrual, a common Federal Reserve banking-calendar approximation, following payment dates and ACT/365.25 discount horizons. The archived 9,374 cash-flow observations and both clean/dirty yield calculations are independently reproduced before the expanded fit. Newly verified contracts, when supplied through `--extra-contracts`, have separate input provenance and do not count as reproductions of an archived observation.

The valuation proxy is the last GSW observation in each month. Every bond and Treasury discount curve uses this same date. This aligns the supplied calculations; the exact timestamp and basis of the FactSet P_PRICE field remain unverified. Source prices are treated as clean in the principal calculation and dirty in a separate sensitivity. The latter becomes especially sensitive immediately before a coupon or redemption and remains a diagnostic.

The initial Treasury discount function is the published GSW Svensson curve. This is precisely the initial curve matched by the maintained AFNS++ deterministic shift. No AFNS covariance, risk-premium parameter or future-state path is fitted by these calculations. GSW values outside its published one-to-thirty-year zero-yield grid are flagged as curve extrapolation.

Within legal issuer, currency and security class, the conventional spread uses a fixed Nelson–Siegel decay of 0.3 per year, a driftless level and zero credit diffusion. One conventional quote fits the level, two fit level and slope, and three or more fit level, slope and curvature. The instantaneous conventional forward spread is constrained to be nonnegative at all nonnegative horizons, with an exact check of interior extrema and the long-run limit. The objective is squared price error divided by the observed bond DV01 squared. All positive remaining horizons are included so that the latest sample agrees with the callable pricing exercise; observations below a quarter year are separately flagged.

The green shape has fixed decay 0.1, zero long-run mean and zero diffusion. The current green state is unrestricted in sign. Each issuer-month has a common-state fit to all its green quotes, while individual green inversions give a conditional residual diagnostic. Green quotes never enter the conventional curve fit. The resulting declining or increasing maturity profile follows from the fixed green shape and is not an independently estimated term-structure shape.

These are pre-option calculations. Each callable conventional quote is used as a straight-price target. Its fitted spread therefore absorbs the effect of the omitted option along with curve residuals and other pricing components. All option corrections remain uncomputed; no zero option is imputed. Join these results to the separate contractual callable calculations before reporting a redemption correction or interpreting a spread as stripped credit.

## Outputs and comparisons

`matched_panel_monthly_gsw.csv` preserves the original fixed ex-post pair registry and raw matched yield calculations. It covers 19 green bonds and 1,395 nearest-single bond-months, nine green bonds and 619 strict-bracketing bond-months, and 12 green bonds and 807 nearest-two sensitivity observations. The nearest-two sensitivity can extrapolate and is explicitly labeled. These are uncontrolled matching diagnostics inspired by matched-bond methods, not the full Zerbib regression/liquidity estimator.

`green_independent_inversions.csv` contains the full conventional-curve same-cashflow comparisons and conditional zero-greenium inversions. `issuer_month_parameters.csv` and `full_curve_bond_residuals.csv` retain every coefficient, optimizer result, Jacobian condition number and bond pricing error. `issuer_zero_curves.csv` supplies Treasury, conventional and conditional green zero yields with maturity-support indicators. `matched_to_full_curve_decomposition.csv` separates pair cash-flow standardization from the change to a full issuer conventional curve.

`green_zero_coupon_decomposition.csv` decomposes the conditional same-cashflow yield difference into its zero-coupon greenium, compounding convention and coupon/curve-shape component. It leaves the option correction blank because it is not calculated here. `full_curve_price_basis_sensitivity.csv` records the clean/dirty assumption effect without treating either interpretation as provider verified.

The plotted lines are dated descriptive medians. A new observation or a change in the issuer's maturity support can move them. They are neither filtered green states nor causal preference estimates. Large discrepancies for short utility green bonds when the conventional sample consists only of long maturities demonstrate weak extrapolation support. A small in-sample conventional fit error does not resolve that problem.

## Reproduce

Run `python run_monthly.py --extra-contracts inputs/replication/extra_contracts.json`, then `python summarize_monthly.py` and `python compare_anchor_results.py` from this directory. The runner automatically uses portable inputs in `inputs/replication`; no broad vendor database is required. The `baseline` folder preserves the completed fit before the eight additional conventional bonds. Running `python run_monthly.py` without the extra-contract argument reproduces that baseline. The `summary.json` file records source and code hashes, observation counts and numerical checks. `environment.json` records the numerical-library versions.
