#!/usr/bin/env python3
"""Reconcile the frozen pre-anchor and expanded monthly conventional curves."""
from pathlib import Path
import json
import numpy as np
import pandas as pd

OUT=Path(__file__).resolve().parent


def main():
    baseline=pd.read_csv(OUT/'baseline/green_independent_inversions.csv')
    final=pd.read_csv(OUT/'green_independent_inversions.csv')
    keys=['code','month_label','legal_issuer','security_group','price_basis']
    merged=baseline.merge(final,on=keys,suffixes=('_before','_after'),validate='one_to_one')
    for col in ['same_cashflow_yield_greenium_bp','independent_endpoint_zero_greenium_bp',
                'common_z_bp','common_endpoint_zero_greenium_bp','conventional_yield_rmse_bp']:
        merged[col+'_change']=merged[col+'_after']-merged[col+'_before']
    merged.to_csv(OUT/'additional_conventional_bonds_effect_monthly.csv',index=False)
    latest=merged[merged.month_label==merged.month_label.max()]
    latest.to_csv(OUT/'additional_conventional_bonds_effect_latest.csv',index=False)
    bp=pd.read_csv(OUT/'baseline/issuer_month_parameters.csv')
    fp=pd.read_csv(OUT/'issuer_month_parameters.csv')
    params=bp.merge(fp,on=['month_label','legal_issuer','security_group','price_basis'],
                    suffixes=('_before','_after'),validate='one_to_one')
    rows=[]
    for issuer,frame in merged[merged.price_basis=='clean_assumed'].groupby('legal_issuer'):
        pp=params[(params.legal_issuer==issuer)&(params.price_basis=='clean_assumed')]
        lp=pp[pp.month_label==pp.month_label.max()].iloc[0]
        selected=frame[frame.month_label==frame.month_label.max()]
        rows.append(dict(legal_issuer=issuer,issuer_name=frame.iloc[0].issuer_name_after,
            green_bond_months=len(frame),new_conventional_bonds_latest=int(lp.n_conventional_after-lp.n_conventional_before),
            mean_same_cashflow_greenium_change_bp=frame.same_cashflow_yield_greenium_bp_change.mean(),
            mean_absolute_same_cashflow_greenium_change_bp=frame.same_cashflow_yield_greenium_bp_change.abs().mean(),
            maximum_absolute_same_cashflow_greenium_change_bp=frame.same_cashflow_yield_greenium_bp_change.abs().max(),
            latest_common_z_before_bp=lp.common_z_bp_before,latest_common_z_after_bp=lp.common_z_bp_after,
            latest_green_fit_rmse_before_bp=lp.common_green_yield_rmse_bp_before,
            latest_green_fit_rmse_after_bp=lp.common_green_yield_rmse_bp_after,
            latest_conventional_fit_rmse_before_bp=lp.conventional_yield_rmse_bp_before,
            latest_conventional_fit_rmse_after_bp=lp.conventional_yield_rmse_bp_after,
            latest_conventional_jacobian_condition_before=lp.price_jacobian_condition_before,
            latest_conventional_jacobian_condition_after=lp.price_jacobian_condition_after,
            latest_within_maturity_range_before=int((selected.conventional_maturity_support_before=='within_range').sum()),
            latest_within_maturity_range_after=int((selected.conventional_maturity_support_after=='within_range').sum())))
    table=pd.DataFrame(rows)
    table.to_csv(OUT/'additional_conventional_bonds_effect_summary.csv',index=False)
    unchanged=table[table.new_conventional_bonds_latest==0]
    summary=json.loads((OUT/'summary.json').read_text())
    summary.update(additional_conventional_bonds_effect=rows,
        baseline_and_expanded_green_observations_match=(len(merged)==len(baseline)==len(final)),
        unaffected_issuers_maximum_change_bp=float(unchanged.maximum_absolute_same_cashflow_greenium_change_bp.max()))
    (OUT/'summary.json').write_text(json.dumps(summary,indent=2,default=lambda v:v.item() if isinstance(v,np.generic) else str(v)))
    print(table[table.new_conventional_bonds_latest>0].to_string(index=False))


if __name__=='__main__':main()
