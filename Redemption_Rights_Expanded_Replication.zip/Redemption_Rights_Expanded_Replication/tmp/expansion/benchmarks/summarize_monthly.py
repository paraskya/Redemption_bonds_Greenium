#!/usr/bin/env python3
"""Summarize the completed monthly comparison without assigning causal meaning."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from run_monthly import svensson_zero, ns_integral, green_h, GSW_FILE

OUT=Path(__file__).resolve().parent


def summarize():
    inv=pd.read_csv(OUT/'green_independent_inversions.csv')
    par=pd.read_csv(OUT/'issuer_month_parameters.csv')
    matched=pd.read_csv(OUT/'matched_panel_monthly_gsw.csv')
    bond=pd.read_csv(OUT/'bond_month_values_gsw.csv')
    summary=json.loads((OUT/'summary.json').read_text())
    treasury=pd.read_csv(GSW_FILE).set_index('observation_date')
    pidx=par.set_index(['month_label','legal_issuer','security_group','price_basis'])
    decomposition=[]
    for row in inv.to_dict('records'):
        p=pidx.loc[(row['month_label'],row['legal_issuer'],row['security_group'],row['price_basis'])]
        t=float(row['maturity_years'])
        beta=np.array([p.beta_level_bp,p.beta_slope_bp,p.beta_curvature_bp])
        brown=float(svensson_zero(np.array([t]),treasury.loc[row['valuation_date']])[0])
        brown+=float(ns_integral(np.array([t]))[0] @ beta)*1e-4/t
        g=float(row['independent_endpoint_zero_greenium_bp'])*1e-4
        nominal=2*np.exp(brown/2)*(-np.expm1(-g/2))*1e4
        row.update(zero_compounding_conversion_bp=nominal-g*1e4,
                   same_compounding_zero_yield_differential_bp=nominal,
                   coupon_and_curve_shape_effect_bp=row['same_cashflow_yield_greenium_bp']-nominal,
                   coupon_decomposition_sum_bp=g*1e4+(nominal-g*1e4)+(row['same_cashflow_yield_greenium_bp']-nominal),
                   option_correction_bp=np.nan,
                   option_correction_status='not_calculated_in_monthly_preoption_layer')
        decomposition.append(row)
    decomposition=pd.DataFrame(decomposition)
    decomposition.to_csv(OUT/'green_zero_coupon_decomposition.csv',index=False)
    idx=decomposition.set_index(['code','month_label','price_basis'])
    bridge=[]
    for row in matched.to_dict('records'):
        for basis in ['clean_assumed','dirty_assumed']:
            key=(row['green_code'],row['month_label'],basis)
            if key not in idx.index:
                continue
            r=idx.loc[key]
            raw=row[f'matched_greenium_{basis}_bp']
            paircf=row[f'gsw_owncf_yield_greenium_{basis}_bp']
            fullcf=r['same_cashflow_yield_greenium_bp']
            bridge.append(dict(green_code=row['green_code'],month_label=row['month_label'],
                legal_issuer=row['legal_issuer'],comparison_method=row['comparison_method'],
                price_basis=basis,raw_matched_greenium_bp=raw,
                same_schedule_pair_curve_greenium_bp=paircf,
                same_schedule_full_issuer_curve_greenium_bp=fullcf,
                pair_cashflow_standardization_bp=paircf-raw,
                conventional_curve_selection_and_fit_bp=fullcf-paircf,
                total_fullcurve_minus_raw_bp=fullcf-raw,
                decomposition_reconciliation_error_bp=(paircf-raw)+(fullcf-paircf)-(fullcf-raw),
                full_curve_endpoint_zero_greenium_bp=r['independent_endpoint_zero_greenium_bp'],
                full_curve_maturity_support=r['conventional_maturity_support'],
                full_curve_conventional_yield_rmse_bp=r['conventional_yield_rmse_bp'],
                pair_extrapolates=bool(row['extrapolates']),
                all_legs_at_least_quarter_year=bool(row['all_legs_at_least_quarter_year']),
                option_adjustment_applied=False))
    bridge=pd.DataFrame(bridge)
    bridge.to_csv(OUT/'matched_to_full_curve_decomposition.csv',index=False)
    sensitivity=decomposition.pivot(index=['code','month_label','legal_issuer','issuer_name','maturity_years','conventional_maturity_support'],
                                    columns='price_basis',values=['independent_endpoint_zero_greenium_bp','same_cashflow_yield_greenium_bp','common_endpoint_zero_greenium_bp'])
    sensitivity.columns=['_'.join(c) for c in sensitivity.columns]
    sensitivity=sensitivity.reset_index()
    for measure in ['independent_endpoint_zero_greenium_bp','same_cashflow_yield_greenium_bp','common_endpoint_zero_greenium_bp']:
        sensitivity[measure+'_dirty_minus_clean']=sensitivity[measure+'_dirty_assumed']-sensitivity[measure+'_clean_assumed']
    sensitivity.to_csv(OUT/'full_curve_price_basis_sensitivity.csv',index=False)
    aggregates=[]
    for method,frame in matched.groupby('comparison_method'):
        for screen,selected in [('all_retained_pair_months',frame),
                                ('all_legs_at_least_quarter_year',frame[frame.all_legs_at_least_quarter_year])]:
            aggregates.append(dict(method=method,screen=screen,green_bonds=selected.green_code.nunique(),
                bond_months=len(selected),
                mean_raw_matched_greenium_bp=selected.matched_greenium_clean_assumed_bp.mean(),
                median_raw_matched_greenium_bp=selected.matched_greenium_clean_assumed_bp.median(),
                mean_cashflow_standardization_bp=selected.coupon_curve_standardization_clean_assumed_bp.mean(),
                mean_abs_cashflow_standardization_bp=selected.coupon_curve_standardization_clean_assumed_bp.abs().mean(),
                mean_price_basis_sensitivity_bp=selected.price_basis_sensitivity_bp.mean(),
                mean_abs_price_basis_sensitivity_bp=selected.price_basis_sensitivity_bp.abs().mean()))
    pd.DataFrame(aggregates).to_csv(OUT/'matched_method_summary.csv',index=False)
    main=decomposition[decomposition.price_basis=='clean_assumed']
    latest=main[main.month_label==main.month_label.max()].copy()
    latest.to_csv(OUT/'latest_green_diagnostics_with_coupon_components.csv',index=False)
    monthly=[]
    for (issuer,month),frame in main.groupby(['legal_issuer','month_label']):
        within=frame[frame.conventional_maturity_support=='within_range']
        monthly.append(dict(legal_issuer=issuer,issuer_name=frame.iloc[0].issuer_name,month_label=month,
            n_green=len(frame),n_green_within_conventional_maturity_range=len(within),
            median_all_conditional_same_cashflow_greenium_bp=frame.same_cashflow_yield_greenium_bp.median(),
            median_within_maturity_range_conditional_same_cashflow_greenium_bp=within.same_cashflow_yield_greenium_bp.median(),
            mean_conventional_yield_rmse_bp=frame.conventional_yield_rmse_bp.mean(),
            common_z_bp=frame.iloc[0].common_z_bp))
    monthly=pd.DataFrame(monthly)
    monthly.to_csv(OUT/'issuer_month_greenium_diagnostics.csv',index=False)
    names={'CIK0000028385':'DTE Electric','CIK0000081018':'Public Service Colorado',
        'CIK0000320193':'Apple','CIK0000732712':'Verizon','CIK0000928576':'MidAmerican Energy',
        'CIK0001043121':'Boston Properties LP','CIK0001101239':'Equinix',
        'CIK0001123852':'Northern States Power MN'}
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False})
    fig,axes=plt.subplots(4,2,figsize=(12,12),sharex=True)
    for ax,(issuer,frame) in zip(axes.ravel(),monthly.groupby('legal_issuer')):
        dates=pd.to_datetime(frame.month_label)
        ax.plot(dates,frame.median_all_conditional_same_cashflow_greenium_bp,
                color='#90969e',lw=1.3,ls='--',label='All observed green maturities')
        ax.plot(dates,frame.median_within_maturity_range_conditional_same_cashflow_greenium_bp,
                color='#176b85',lw=1.8,label='Within conventional maturity range')
        ax.axhline(0,color='#555555',lw=.7)
        ax.set_title(names.get(issuer,issuer),loc='left',fontweight='bold')
        ax.set_ylabel('Basis points')
        ax.grid(axis='y',alpha=.16)
    fig.suptitle('Monthly conditional greenium before option adjustment',fontsize=17,x=.07,ha='left',y=.99)
    fig.text(.07,.953,'Median same-cashflow yield difference by issuer. Separate dated fits; axes have different scales.',fontsize=11)
    handles,labels=axes.flat[0].get_legend_handles_labels()
    fig.legend(handles,labels,loc='lower left',bbox_to_anchor=(.06,.025),ncol=2,frameon=False)
    fig.text(.07,.008,'P_PRICE is assumed clean. Dashed observations can require conventional-curve extrapolation. These are not option-adjusted or preference estimates.',fontsize=8.5)
    fig.tight_layout(rect=(.03,.06,.99,.945))
    for ext in ['png','pdf','svg']:
        fig.savefig(OUT/f'Monthly_Preoption_Greenium.{ext}',dpi=180,bbox_inches='tight')
    plt.close(fig)
    summary.update(matched_aggregate_statistics=aggregates,
        latest_within_conventional_maturity_range=int((latest.conventional_maturity_support=='within_range').sum()),
        latest_extrapolated_green_count=int((latest.conventional_maturity_support!='within_range').sum()),
        coupon_decomposition_max_reconciliation_error_bp=float((decomposition.coupon_decomposition_sum_bp-decomposition.same_cashflow_yield_greenium_bp).abs().max()),
        matched_fullcurve_bridge_max_reconciliation_error_bp=float(bridge.decomposition_reconciliation_error_bp.abs().max()),
        median_absolute_fullcurve_price_basis_effect_bp=float(sensitivity.same_cashflow_yield_greenium_bp_dirty_minus_clean.abs().median()),
        n_green_months_under_quarter_year=int((main.maturity_years<.25).sum()),
        n_latest_issuer_fits_with_coefficient_bound=int(par[(par.month_label==main.month_label.max())&(par.price_basis=='clean_assumed')].any_coefficient_bound.sum()))
    (OUT/'summary.json').write_text(json.dumps(summary,indent=2,default=lambda x:x.item() if isinstance(x,np.generic) else str(x)))
    readme=f'''# Expanded monthly bond comparisons

The completed panel contains {summary['n_reproduced_bond_months']:,} dated cash-flow observations across {summary['n_priced_distinct_contracts']} verified eligible contracts. A same-issuer conventional curve is available for {summary['n_supported_green_bond_months']:,} green bond-months, covering {summary['n_supported_distinct_green_bonds']} green bonds and eight legal issuers. Of these, {summary['n_independent_inversions_within_conventional_maturity_range']:,} lie within the observed conventional maturity range. Availability of a conventional quote and maturity support are distinct conditions.

## Valuation and estimation

Every cash flow uses the contractual coupon schedule, US 30/360 accrual, a common Federal Reserve banking-calendar approximation, following payment dates and ACT/365.25 discount horizons. The archived 9,374 cash-flow observations and both clean/dirty yield calculations are independently reproduced before the expanded fit. Newly verified contracts, when supplied through `--extra-contracts`, have separate input provenance and do not count as reproductions of an archived observation.

The valuation proxy is the last GSW observation in each month. Every bond and Treasury discount curve uses this same date. This aligns the supplied calculations; the exact timestamp and basis of the FactSet P_PRICE field remain unverified. Source prices are treated as clean in the principal calculation and dirty in a separate sensitivity. The latter becomes especially sensitive immediately before a coupon or redemption and remains a diagnostic.

The initial Treasury discount function is the published GSW Svensson curve. This is precisely the initial curve matched by the maintained AFNS++ deterministic shift. No AFNS covariance, risk-premium parameter or future-state path is fitted by these calculations. GSW values outside its published one-to-thirty-year zero-yield grid are flagged as curve extrapolation.

Within legal issuer, currency and security class, the conventional spread uses a fixed Nelson–Siegel decay of 0.3 per year, a driftless level and zero credit diffusion. One conventional quote fits the level, two fit level and slope, and three or more fit level, slope and curvature. The instantaneous conventional forward spread is constrained to be nonnegative at all nonnegative horizons, with an exact check of interior extrema and the long-run limit. The objective is squared price error divided by the observed bond DV01 squared. All positive remaining horizons are included so that the latest sample agrees with the callable pricing exercise; observations below a quarter year are separately flagged.

The green shape has fixed decay 0.1, zero long-run mean and zero diffusion. The current green state is unrestricted in sign. Each issuer-month has a common-state fit to all its green quotes, while individual green inversions give a conditional residual diagnostic. Green quotes never enter the conventional curve fit. The resulting declining or increasing maturity profile follows from the fixed green shape and is not an independently estimated term-structure shape.

These are pre-option calculations. Each callable conventional quote is used as a straight-price target. Its fitted spread therefore absorbs the effect of the omitted option along with curve residuals and other pricing components. All option corrections remain uncomputed; no zero option is imputed. Join these results to the separate contractual callable calculations before reporting a redemption correction or interpreting a spread as stripped credit.

## Outputs and comparisons

`matched_panel_monthly_gsw.csv` preserves the original fixed ex-post pair registry and raw matched yield calculations. It covers 19 green bonds and 1,395 nearest-single bond-months, nine green bonds and 619 strict-bracketing bond-months, and 12 green bonds and 807 nearest-two sensitivity observations. The nearest-two sensitivity can extrapolate and is explicitly labeled. These are uncontrolled matching diagnostics inspired by matched-bond methods, not the full Zerbib regression/liquidity estimator.

`green_independent_inversions.csv` contains the full conventional-curve same-cashflow comparisons and conditional zero-greenium inversions. `issuer_month_parameters.csv` and `full_curve_bond_residuals.csv` retain every coefficient, optimizer result, Jacobian condition number and bond pricing error. `issuer_zero_curves.csv` supplies Treasury, conventional and conditional green zero yields with maturity-support indicators. `matched_to_full_curve_decomposition.csv` separates pair cash-flow standardization from the change to a full issuer conventional curve.

`green_zero_coupon_decomposition.csv` decomposes the conditional same-cashflow yield difference into its zero-coupon greenium, compounding convention and coupon/curve-shape component. It leaves the option correction blank because it is not calculated here. `full_curve_price_basis_sensitivity.csv` records the clean/dirty assumption effect without treating either interpretation as provider verified.

The plotted lines are dated descriptive medians. A new observation or a change in the issuer's maturity support can move them. They are neither filtered green states nor causal preference estimates. Large discrepancies for short utility green bonds when the conventional sample consists only of long maturities demonstrate weak extrapolation support. A small in-sample conventional fit error does not resolve that problem.

## Reproduce

Run `python run_monthly.py --extra-contracts inputs/replication/extra_contracts.json`, then `python summarize_monthly.py` and `python compare_anchor_results.py` from this directory. The runner automatically uses the portable inputs in `inputs/replication`; no broad vendor database is required. The `baseline` folder preserves the completed fit before the eight additional conventional bonds. Running `python run_monthly.py` without the extra-contract argument reproduces that baseline. The `summary.json` file records source and code hashes, observation counts and numerical checks. `environment.json` records the Python and numerical-library versions.
'''
    (OUT/'README.md').write_text(readme)
    print(json.dumps({k:summary[k] for k in ['n_supported_green_bond_months','latest_within_conventional_maturity_range',
        'latest_extrapolated_green_count','median_absolute_fullcurve_price_basis_effect_bp',
        'coupon_decomposition_max_reconciliation_error_bp']},indent=2))


if __name__=='__main__':
    summarize()
