#!/usr/bin/env python3
"""Expand dated, pre-option green/conventional comparisons on verified contracts.

The GSW discount curve is the exact initial curve of the maintained AFNS++
specification. No callable option or future-state dynamics are estimated here.
All source quotes remain explicitly clean-price assumptions with a dirty-price
sensitivity. Positive greenium means conventional yield exceeds green yield.
"""
from __future__ import annotations

import os
for _key in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ[_key] = "1"
import argparse
import calendar
import hashlib
import json
from datetime import date, timedelta
from functools import lru_cache
from pathlib import Path
import numpy as np
import pandas as pd
from pandas.tseries.holiday import USFederalHolidayCalendar
from scipy.optimize import brentq, least_squares, minimize

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
COMPARISON = ROOT / "restored/Zero_Coupon_Greenium_Data_and_Code/inventory/inputs/comparison/results"
GSW_FILE = ROOT / "tmp/model_comparison/treasury/inputs/gsw_daily_percent.csv"
RAW_FILE = ROOT / "output/csv_bond_contracts/monthly_prices.csv.gz"
LOCAL_INPUTS = OUT / 'inputs' / 'replication'
if (LOCAL_INPUTS/'normalized_contracts.json').exists():
    COMPARISON=LOCAL_INPUTS
    GSW_FILE=LOCAL_INPUTS/'gsw_daily_percent.csv'
    RAW_FILE=LOCAL_INPUTS/'monthly_prices.csv.gz'
DECAY_F = .3
DECAY_Z = .1
MIN_HORIZON = 0.


def as_date(value):
    return value if isinstance(value, date) else date.fromisoformat(str(value))


def years(start, end):
    return (end - start).days / 365.25


def thirty360(start, end):
    last_feb = lambda d: d.month == 2 and d.day == calendar.monthrange(d.year, 2)[1]
    d1 = 30 if start.day == 31 or last_feb(start) else start.day
    d2 = end.day
    if (d2 == 31 and d1 >= 30) or (last_feb(start) and last_feb(end)):
        d2 = 30
    return ((end.year-start.year)*360+(end.month-start.month)*30+d2-d1)/360


@lru_cache(maxsize=100)
def holidays(year):
    return frozenset(USFederalHolidayCalendar().holidays(
        date(year-1, 1, 1), date(year+1, 12, 31)).date)


def following(d):
    while d.weekday() >= 5 or d in holidays(d.year):
        d += timedelta(days=1)
    return d


class Bond:
    def __init__(self, contract):
        self.contract = contract
        self.code = contract['source_code']
        self.coupon = float(contract['coupon_pct'])
        self.frequency = int(contract['frequency'])
        self.first = as_date(contract['first_coupon_date'])
        self.maturity = as_date(contract['maturity_date'])
        self.accrual_start = as_date(contract.get('interest_accrual_start_date') or contract['issue_date'])
        self.economic_issue = as_date(contract['economic_issue_date'])
        self.green = bool(contract.get('eligible_as_verified_green'))
        self.issuer = contract['legal_issuer_key']
        self.security_group = contract['security_group']
        verified=contract.get('verified_contractual_cashflows')
        if verified:
            self.schedule=[]
            for item in sorted(verified,key=lambda r:r.get('contractual_date',r.get('unadjusted_date'))):
                contractual=as_date(item.get('contractual_date',item.get('unadjusted_date')))
                coupon=float(item.get('coupon_amount_per100',item.get('interest_per100')))
                principal=float(item['principal_per100'])
                amount=float(item['cashflow_per100'])
                if abs(amount-coupon-principal)>1e-9:
                    raise ValueError(f'Verified cashflow components do not reconcile: {self.code}')
                self.schedule.append((contractual,following(contractual),amount,coupon,principal))
            if self.schedule[-1][0]!=self.maturity:
                raise ValueError(f'Verified schedule omits terminal payment: {self.code}')
            return
        mmdd = contract.get('coupon_dates_mmdd')
        if not mmdd:
            mmdd = [self.first.strftime('%m-%d'),
                    f'{(self.first.month+5)%12+1:02d}-{self.first.day:02d}']
        self.schedule = []
        previous = self.accrual_start
        for year in range(self.first.year, self.maturity.year+1):
            for md in sorted(mmdd):
                month, day = map(int, md.split('-'))
                contractual = date(year, month, min(day, calendar.monthrange(year, month)[1]))
                if not self.first <= contractual <= self.maturity:
                    continue
                amount = self.coupon / self.frequency
                if contractual == self.first:
                    explicit = contract.get('first_coupon_amount_per100')
                    amount = float(explicit) if explicit is not None else self.coupon * thirty360(previous, contractual)
                principal = 100. if contractual == self.maturity else 0.
                self.schedule.append((contractual, following(contractual), amount+principal, amount, principal))
                previous = contractual
        if not self.schedule or self.schedule[-1][0] != self.maturity:
            raise ValueError(f'Unsupported terminal schedule: {self.code}')

    def cashflows(self, valuation):
        selected = [r for r in self.schedule if r[1] > valuation]
        return (np.array([years(valuation, r[1]) for r in selected]),
                np.array([r[2] for r in selected]))

    def accrued(self, valuation):
        previous = max([self.accrual_start] + [r[0] for r in self.schedule if r[0] <= valuation])
        return self.coupon * thirty360(previous, valuation)


def price_yield(t, cf, y):
    return float(cf @ np.exp(-2*t*np.log1p(y/2)))


def yield_price(t, cf, dirty):
    if dirty <= 0:
        raise ValueError('Nonpositive dirty target')
    lower=-.49;upper=2.
    while price_yield(t,cf,lower)<dirty and lower>-1.999:
        lower=-2+(lower+2)/2
    while price_yield(t,cf,upper)>dirty and upper<1000:
        upper=2*upper+1
    return brentq(lambda y: price_yield(t, cf, y)-dirty, lower, upper, xtol=2e-14)


def dv01(t, cf, y):
    return float((cf*t) @ np.exp((-2*t-1)*np.log1p(y/2)))*1e-4


def svensson_zero(t, row):
    t = np.asarray(t, float)
    x = t/float(row['TAU1'])
    y = t/float(row['TAU2'])
    b1 = np.divide(-np.expm1(-x), x, out=np.ones_like(x), where=x!=0)
    b2 = np.divide(-np.expm1(-y), y, out=np.ones_like(y), where=y!=0)
    return (row['BETA0'] + row['BETA1']*b1 + row['BETA2']*(b1-np.exp(-x))
            + row['BETA3']*(b2-np.exp(-y)))/100.


def ns_integral(t):
    t = np.asarray(t, float)
    k = -np.expm1(-DECAY_F*t)/DECAY_F
    return np.column_stack((t, k, k-t*np.exp(-DECAY_F*t)))


def ns_forward(t):
    t = np.atleast_1d(np.asarray(t, float))
    e = np.exp(-DECAY_F*t)
    return np.column_stack((np.ones_like(t), e, DECAY_F*t*e))


def minimum_forward(beta, horizon):
    beta = np.pad(np.asarray(beta), (0, 3-len(beta)))
    b0, b1, b2 = beta
    points = [0., float(horizon)]
    if b2 != 0:
        critical = (b2-b1)/(DECAY_F*b2)
        if critical > 0 and np.isfinite(critical):
            points.append(float(critical))
    values = np.r_[ns_forward(points) @ beta, b0]
    points.append(float('inf'))
    k = int(np.argmin(values))
    return float(values[k]), float(points[k])


def green_h(t):
    return -np.expm1(-DECAY_Z*np.asarray(t))/DECAY_Z


def fit_conventional(rows, basis):
    n = min(3, len(rows))
    horizon = max(float(r['t'][-1]) for r in rows)
    target = np.array([r[basis]['dirty'] for r in rows])
    scales = np.array([r[basis]['dv01'] for r in rows])
    def evaluate(beta, jac=False):
        px, dx = [], []
        for row in rows:
            loading = row['F'][:, :n]
            pv = row['cf_tsy']*np.exp(np.clip(-1e-4*(loading @ beta), -700, 700))
            px.append(np.sum(pv))
            if jac:
                dx.append(-1e-4*(pv @ loading))
        if jac:
            return (np.asarray(px)-target)/scales, np.asarray(dx)/scales[:, None]
        return (np.asarray(px)-target)/scales
    start = np.zeros(n)
    start[0] = max(0., float(np.median([r[basis]['zspread_bp'] for r in rows])))
    unconstrained = least_squares(evaluate, start, jac=lambda b:evaluate(b,True)[1],
                                  bounds=(-5000,5000), xtol=1e-11, ftol=1e-11, gtol=1e-10,
                                  max_nfev=300)
    forward_min, _ = minimum_forward(unconstrained.x, horizon)
    constrained = forward_min < -1e-8
    candidates = [unconstrained]
    beta = unconstrained.x
    status = bool(unconstrained.success)
    message = str(unconstrained.message)
    optimality = float(unconstrained.optimality)
    if constrained:
        grid = np.unique(np.r_[0., np.linspace(0,horizon,321)])
        objective_scale=max(1.,float(np.mean(evaluate(start)**2)))
        def exact_constraint(b):
            return minimum_forward(b,horizon)[0]
        def exact_constraint_jac(b):
            _,point=minimum_forward(b,horizon)
            return np.array([1.,0.,0.])[:n] if np.isinf(point) else ns_forward([point])[0,:n]
        for attempt in range(12):
            A = np.vstack([ns_forward(grid),[1.,0.,0.]])[:, :n]
            def objective(b):
                r,j=evaluate(b,True)
                return float(.5*(r @ r))/objective_scale, (j.T @ r)/objective_scale
            initial = start if attempt == 0 else beta
            sol = minimize(objective, initial, jac=True, method='SLSQP',
                           bounds=[(-5000,5000)]*n,
                           constraints=[dict(type='ineq',fun=lambda b:A@b,jac=lambda b:A),
                                        dict(type='ineq',fun=exact_constraint,jac=exact_constraint_jac)],
                           options=dict(ftol=1e-10,maxiter=500))
            beta=sol.x
            exact_min, critical=minimum_forward(beta,horizon)
            status=bool(sol.success)
            message=str(sol.message)
            optimality=float(np.linalg.norm(objective(beta)[1],ord=np.inf))
            if exact_min >= -1e-7 and status:
                break
            grid=np.unique(np.r_[grid,critical])
    residual,jac=evaluate(beta,True)
    singular=np.linalg.svd(jac,compute_uv=False)
    fullbeta=np.pad(beta,(0,3-n))
    prices=[float(np.sum(r['cf_tsy']*np.exp(-1e-4*(r['F'] @ fullbeta)))) for r in rows]
    yerrors=[1e4*(yield_price(r['t'],r['cf'],p)-r[basis]['yield']) for r,p in zip(rows,prices)]
    fmin,where=minimum_forward(fullbeta,horizon)
    return fullbeta, dict(n_conventional=len(rows), n_parameters=n, lambdaF=DECAY_F,
         beta_level_bp=float(fullbeta[0]), beta_slope_bp=float(fullbeta[1]), beta_curvature_bp=float(fullbeta[2]),
         minimum_fitted_forward_bp=fmin, minimum_forward_horizon_years=where,
         constraint_horizon_years=horizon, forward_constraint_applied=constrained,
         minimum_conventional_maturity_years=min(float(r['t'][-1]) for r in rows),
         maximum_conventional_maturity_years=horizon,
         conventional_codes=','.join(r['code'] for r in rows),
         conventional_yield_rmse_bp=float(np.sqrt(np.mean(np.square(yerrors)))),
         conventional_price_over_dv01_rmse_bp=float(np.sqrt(np.mean(residual**2))),
         optimizer_success=status, optimizer_message=message, optimizer_optimality=optimality,
         price_jacobian_rank=int(np.linalg.matrix_rank(jac)),
         price_jacobian_condition=float(singular[0]/singular[-1]),
         any_coefficient_bound=bool(np.any(np.abs(fullbeta)>4999.999)),
         finite_sample_parameter_identification_asserted=False,
         maximum_absolute_yield_residual_bp=float(np.max(np.abs(yerrors)))),prices,yerrors


def fit_green(rows, beta, basis):
    def price(row,z):
        base=row['cf_tsy']*np.exp(-1e-4*(row['F'] @ beta))
        return float(np.sum(base*np.exp(np.clip(z*1e-4*row['h'],-700,700))))
    def residual(z):
        return np.array([(price(r,z[0])-r[basis]['dirty'])/r[basis]['dv01'] for r in rows])
    def jac(z):
        return np.array([[np.sum(r['cf_tsy']*np.exp(-1e-4*(r['F']@beta))
                     *np.exp(z[0]*1e-4*r['h'])*r['h']*1e-4)/r[basis]['dv01']] for r in rows])
    sol=least_squares(residual,[0.],jac=jac,bounds=(-5000,5000),
                       xtol=1e-12,ftol=1e-12,gtol=1e-10,max_nfev=300)
    px=[price(r,sol.x[0]) for r in rows]
    errors=[1e4*(yield_price(r['t'],r['cf'],p)-r[basis]['yield']) for r,p in zip(rows,px)]
    return float(sol.x[0]), dict(n_green=len(rows),green_codes=','.join(r['code'] for r in rows),
         muZ=DECAY_Z,thetaZ_bp=0.,sigmaZ=0.,common_z_bp=float(sol.x[0]),
         common_green_any_bound=bool(abs(sol.x[0])>4999.999),
         common_green_yield_rmse_bp=float(np.sqrt(np.mean(np.square(errors)))),
         common_green_max_abs_yield_residual_bp=float(np.max(np.abs(errors))),
         common_green_optimizer_success=bool(sol.success)),px,errors


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--verify-only',action='store_true')
    parser.add_argument('--latest-only',action='store_true')
    parser.add_argument('--extra-contracts',type=Path,
                        help='Additional independently verified normalized contract records')
    args=parser.parse_args()
    OUT.mkdir(parents=True,exist_ok=True)
    contracts=json.loads((COMPARISON/'normalized_contracts.json').read_text())['contracts']
    contracts={r['source_code']:r for r in contracts}
    eligible=pd.read_csv(COMPARISON/'contract_eligibility.csv')
    eligible_codes=set(eligible.loc[eligible.eligible,'code'])
    extra_codes=set()
    if args.extra_contracts:
        extras=json.loads(args.extra_contracts.read_text())
        extras=(extras['contracts'] if 'contracts' in extras else [extras]) if isinstance(extras,dict) else extras
        for r in extras:
            code=r['source_code']
            if code in contracts:
                raise ValueError(f'Extra contract would overwrite existing contract {code}')
            if r['currency']!='USD' or int(r['frequency'])!=2 or not r.get('legal_issuer_key') or not r.get('security_group'):
                raise ValueError(f'Incomplete extra cashflow classification {code}')
            if not (r.get('eligible_as_verified_green') or r.get('eligible_as_verified_conventional')):
                raise ValueError(f'Extra contract not classified from verified source {code}')
            contracts[code]=r
            eligible_codes.add(code)
            extra_codes.add(code)
    bonds={code:Bond(contracts[code]) for code in sorted(eligible_codes)}
    old=pd.read_csv(COMPARISON/'bond_month_values.csv')
    oldmatched=pd.read_csv(COMPARISON/'matched_panel_monthly.csv')
    pair_registry=pd.read_csv(COMPARISON/'pair_registry.csv')
    gsw=pd.read_csv(GSW_FILE)
    gsw_dates=pd.to_datetime(gsw.observation_date)
    gsw_bydate={r['observation_date']:r for r in gsw.to_dict('records')}
    raw=pd.read_csv(RAW_FILE,usecols=['Code','Date','P_PRICE'])
    raw=raw[raw.Code.isin(eligible_codes)].set_index(['Code','Date'])
    if raw.index.has_duplicates:
        raise ValueError('Duplicate raw code/month prices')
    if extra_codes:
        monthly_gsw=gsw.assign(month_label=gsw_dates.dt.to_period('M').dt.to_timestamp('M').dt.strftime('%Y-%m-%d')).groupby('month_label').tail(1).set_index('month_label')
        extra_rows=[]
        for code in sorted(extra_codes):
            bond=bonds[code];contract=contracts[code]
            for (_,month),rr in raw.loc[raw.index.get_level_values(0)==code].iterrows():
                if month not in monthly_gsw.index or not np.isfinite(rr.P_PRICE) or rr.P_PRICE<=0:
                    continue
                valuation=as_date(monthly_gsw.loc[month,'observation_date'])
                if not bond.economic_issue<=valuation<bond.maturity:
                    continue
                if valuation<following(bond.first) and not (contract.get('regular_first_coupon_supported') or contract.get('first_stub_calculation_verified')):
                    continue
                t,cf=bond.cashflows(valuation);ai=bond.accrued(valuation)
                extra_rows.append(dict(Code=code,green=bond.green,month_label=month,
                    valuation_date=str(valuation),P_PRICE=float(rr.P_PRICE),accrued_per100=np.nan,
                    ytm_clean_assumed_decimal=np.nan,ytm_dirty_assumed_decimal=np.nan,
                    maturity_years=np.nan,cashflows_n=np.nan,_new_contract=True,
                    calendar_status='Common Federal Reserve banking calendar; local trustee/city closures unverified',
                    principal_adjustment_status='explicit_following' if contract.get('principal_following_explicit') else 'common_following_convention_unverified'))
        old=pd.concat([old,pd.DataFrame(extra_rows)],ignore_index=True)
    checks=[]; prepared={}; bond_month=[]
    for row in old.to_dict('records'):
        code=row['Code']; month=row['month_label']; bond=bonds[code]
        if args.latest_only and month!=old.month_label.max():
            continue
        valuation=as_date(row['valuation_date'])
        if str(valuation) not in gsw_bydate:
            raise ValueError(f'No date-aligned GSW input {valuation}')
        tr=gsw_bydate[str(valuation)]
        if gsw_dates[(gsw_dates<=pd.Timestamp(month)) & (gsw_dates.dt.to_period('M')==pd.Period(month,'M'))].max()!=pd.Timestamp(valuation):
            raise ValueError(f'Valuation is not last GSW observation in month {month}')
        t,cf=bond.cashflows(valuation)
        accrued=bond.accrued(valuation)
        quoted=float(raw.loc[(code,month),'P_PRICE'])
        dirty=quoted+accrued
        y=yield_price(t,cf,dirty)
        yd=yield_price(t,cf,quoted)
        checks.append(dict(code=code,month_label=month,
            archived_observation_reproduced=not bool(row.get('_new_contract',False)==True),
            source_price_error=quoted-row['P_PRICE'],
            accrued_error=accrued-row['accrued_per100'],
            clean_yield_reproduction_error_bp=(y-row['ytm_clean_assumed_decimal'])*1e4,
            dirty_yield_reproduction_error_bp=(yd-row['ytm_dirty_assumed_decimal'])*1e4,
            archived_contractual_maturity_error=years(valuation,bond.maturity)-row['maturity_years'],
            final_payment_delay_years=t[-1]-years(valuation,bond.maturity),
            cashflow_count_error=len(t)-row['cashflows_n']))
        discount=np.exp(-t*svensson_zero(t,tr))
        base=cf*discount
        r=dict(code=code,month_label=month,valuation_date=str(valuation),bond=bond,t=t,cf=cf,
            cf_tsy=base,F=ns_integral(t),h=green_h(t),treasury=tr,
            legal_issuer=bond.issuer,security_group=bond.security_group,green=bond.green,
            observed_price=quoted,accrued=accrued)
        output=dict(Code=code,month_label=month,valuation_date=str(valuation),
            legal_issuer=bond.issuer,issuer_name=contracts[code].get('legal_issuer_name') or contracts[code]['issuer'],
            security_group=bond.security_group,currency='USD',green=bond.green,P_PRICE=quoted,accrued_per100=accrued,
            maturity_years=float(t[-1]),coupon_pct=bond.coupon,
            min_quarter_year=t[-1]>=.25,treasury_curve_date=str(valuation),
            treasury_date_gap_days=0,month_label_to_valuation_days=(as_date(month)-valuation).days,
            price_basis_verified=False,price_source_timestamp_verified=False,
            option_adjustment_applied=False,treasury_initial_curve='GSW_Svensson_AFNSplusplus_exact_shift',
            treasury_endpoint_beyond_30_year_published_grid=bool(t[-1]>30),
            treasury_cashflow_below_1_year_published_grid=bool(t[0]<1),
            calendar_status=row['calendar_status'],principal_adjustment_status=row['principal_adjustment_status'])
        for basis,target,yy in [('clean_assumed',dirty,y),('dirty_assumed',quoted,yd)]:
            zfun=lambda s:float(np.sum(base*np.exp(np.clip(-s*t,-700,700))))-target
            lo=-.5;hi=2.
            while zfun(lo)<0:lo*=2
            while zfun(hi)>0:hi*=2
            z=brentq(zfun,lo,hi,xtol=1e-13)
            r[basis]=dict(dirty=target,yield_=yy,dv01=dv01(t,cf,yy),zspread_bp=z*1e4)
            r[basis]['yield']=yy
            output.update({basis+'_dirty_target_per100':target,basis+'_yield_pct':yy*100,
                           basis+'_zspread_bp':z*1e4,basis+'_dv01_per100':r[basis]['dv01']})
        r['output']=output
        prepared[(code,month)]=r
        bond_month.append(output)
    checks=pd.DataFrame(checks)
    checks.to_csv(OUT/'cashflow_reproduction_checks.csv',index=False)
    summary_checks={col:float(checks[col].abs().max()) for col in checks.columns if col not in ('code','month_label','archived_observation_reproduced')}
    print('Cashflow reproduction',summary_checks,flush=True)
    if max(summary_checks[k] for k in ('source_price_error','accrued_error','archived_contractual_maturity_error','cashflow_count_error'))>1e-8 or max(summary_checks[k] for k in ('clean_yield_reproduction_error_bp','dirty_yield_reproduction_error_bp'))>1e-5:
        raise AssertionError('Cashflow/yield reproduction does not agree with archived validated panel')
    if args.verify_only:
        return
    pd.DataFrame(bond_month).to_csv(OUT/'bond_month_values_gsw.csv',index=False)

    # The fixed prior nearest/bracketing registry is reproduced. Its data-rich
    # selection is an ex-post benchmark, with liquidity controls unavailable.
    matched=[]
    for oldrow in oldmatched.to_dict('records'):
        month=oldrow['month_label'];gcode=oldrow['green_code']
        if (gcode,month) not in prepared:
            continue
        g=prepared[gcode,month]; b1=prepared[oldrow['brown1_code'],month]
        has_second=pd.notna(oldrow['brown2_code'])
        b2=prepared[oldrow['brown2_code'],month] if has_second else None
        w1=float(oldrow['weight1']);w2=float(oldrow['weight2'])
        output={k:v for k,v in oldrow.items() if not (k.startswith('afns_') or k.startswith('coupon_curve_') or k.startswith('conventional_counterfactual_') or k.startswith('treasury_'))}
        output.update(treasury_curve_date=g['valuation_date'],treasury_date_gap_days=0,
            treasury_initial_curve='GSW_Svensson_AFNSplusplus_exact_shift',option_adjustment_applied=False,
            comparison_status='Zerbib_style_uncontrolled_matching_not_full_Zerbib_estimator',
            matched_selection_uses_full_sample_availability=True)
        for basis in ['clean_assumed','dirty_assumed']:
            z=w1*b1[basis]['zspread_bp']+(w2*b2[basis]['zspread_bp'] if b2 else 0.)
            rawg=1e4*(w1*b1[basis]['yield']+(w2*b2[basis]['yield'] if b2 else 0.)-g[basis]['yield'])
            counter=float(np.sum(g['cf_tsy']*np.exp(-z*1e-4*g['t'])))
            standardized=1e4*(yield_price(g['t'],g['cf'],counter)-g[basis]['yield'])
            output.update({f'matched_greenium_{basis}_bp':rawg,
                f'gsw_interpolated_z_greenium_{basis}_bp':z-g[basis]['zspread_bp'],
                f'gsw_owncf_yield_greenium_{basis}_bp':standardized,
                f'coupon_curve_standardization_{basis}_bp':standardized-rawg,
                f'conventional_counterfactual_{basis}_per100':counter,
                f'raw_matched_reproduction_error_{basis}_bp':rawg-oldrow[f'matched_greenium_{basis}_bp']})
        output['price_basis_sensitivity_bp']=output['matched_greenium_dirty_assumed_bp']-output['matched_greenium_clean_assumed_bp']
        matched.append(output)
    matched=pd.DataFrame(matched)
    matched.to_csv(OUT/'matched_panel_monthly_gsw.csv',index=False)
    pair_registry.to_csv(OUT/'matched_pair_registry.csv',index=False)

    # Conventional coefficients use every eligible same-obligor/seniority quote
    # in that month; green quotes do not enter the conventional fitting objective.
    frames={name:[] for name in ['issuer_month_parameters','full_curve_bond_residuals',
                                  'green_independent_inversions','issuer_zero_curves',
                                  'excluded_green_months','short_maturity_observations']}
    panel=pd.DataFrame(bond_month)
    for idx,((month,issuer,security,currency),group) in enumerate(panel.groupby(['month_label','legal_issuer','security_group','currency'])):
        rows=[prepared[c,month] for c in group.Code]
        for r in rows:
            if r['t'][-1]<.25:
                frames['short_maturity_observations'].append(dict(code=r['code'],month_label=month,
                    legal_issuer=issuer,green=r['green'],maturity_years=float(r['t'][-1]),
                    reason='included_but_less_than_quarter_year_remaining'))
        rows=[r for r in rows if r['t'][-1]>MIN_HORIZON]
        brown=[r for r in rows if not r['green']]
        green=[r for r in rows if r['green']]
        if not brown:
            for r in green:
                frames['excluded_green_months'].append(dict(code=r['code'],month_label=month,
                    legal_issuer=issuer,reason='no_same_legal_issuer_security_conventional_quote'))
            continue
        for basis in ['clean_assumed','dirty_assumed']:
            beta,summary,bpx,byerr=fit_conventional(brown,basis)
            common=dict(month_label=month,valuation_date=rows[0]['valuation_date'],legal_issuer=issuer,
                issuer_name=group.iloc[0]['issuer_name'],security_group=security,currency=currency,price_basis=basis,
                option_adjustment_applied=False,treasury_date_gap_days=0,
                treasury_initial_curve='GSW_Svensson_AFNSplusplus_exact_shift',
                credit_level_Q_drift=0.,credit_diffusion=0.,issuer_delta=0.,
                conventional_fit_optimizer_success=summary['optimizer_success'])
            summary={**common,**summary}
            if not summary['optimizer_success'] or summary['minimum_fitted_forward_bp'] < -1e-5:
                print('FIT FLAG',month,issuer,basis,summary,flush=True)
            if green:
                z,gsummary,gpx,gyerr=fit_green(green,beta,basis)
                summary.update(gsummary)
            else:
                z=np.nan;gpx=[];gyerr=[]
                summary.update(n_green=0,green_codes='',common_z_bp=np.nan)
            frames['issuer_month_parameters'].append(summary)
            for r,p,ye in zip(brown+green,bpx+gpx,byerr+gyerr):
                frames['full_curve_bond_residuals'].append({**common,
                    'code':r['code'],'green':r['green'],'maturity_years':float(r['t'][-1]),
                    'coupon_pct':r['bond'].coupon,'P_PRICE':r['observed_price'],
                    'accrued_per100':r['accrued'],'target_dirty_per100':r[basis]['dirty'],
                    'observed_yield_pct':100*r[basis]['yield'],
                    'fitted_preoption_dirty_per100':p,
                    'fitted_preoption_clean_per100':p-r['accrued'],
                    'price_error_per100':p-r[basis]['dirty'],
                    'exact_yield_error_bp':ye,
                    'within_conventional_maturity_range':summary['minimum_conventional_maturity_years']<=r['t'][-1]<=summary['maximum_conventional_maturity_years'],
                    'past_30_year_published_treasury_grid':r['t'][-1]>30})
            for r in green:
                t=r['t']; base=r['cf_tsy']*np.exp(-1e-4*(r['F']@beta))
                counter=float(np.sum(base))
                rootfun=lambda zz:float(np.sum(base*np.exp(np.clip(zz*1e-4*r['h'],-700,700))))-r[basis]['dirty']
                low=-5000.;high=5000.
                while rootfun(low)>0:low*=2
                while rootfun(high)<0:high*=2
                root=brentq(rootfun,low,high,xtol=1e-10)
                support='below_shortest' if t[-1]<summary['minimum_conventional_maturity_years'] else ('beyond_longest' if t[-1]>summary['maximum_conventional_maturity_years'] else 'within_range')
                frames['green_independent_inversions'].append({**common,'code':r['code'],
                    'maturity_years':float(t[-1]),'coupon_pct':r['bond'].coupon,
                    'P_PRICE':r['observed_price'],'target_dirty_per100':r[basis]['dirty'],
                    'owncf_conventional_counterfactual_dirty_per100':counter,
                    'owncf_conventional_counterfactual_clean_per100':counter-r['accrued'],
                    'same_cashflow_yield_greenium_bp':1e4*(yield_price(t,r['cf'],counter)-r[basis]['yield']),
                    'independent_z_bp':root,
                    'independent_endpoint_zero_greenium_bp':root*green_h(t[-1])/t[-1],
                    'common_z_bp':z,'common_endpoint_zero_greenium_bp':z*green_h(t[-1])/t[-1],
                    'conventional_maturity_support':support,
                    'minimum_conventional_maturity_years':summary['minimum_conventional_maturity_years'],
                    'maximum_conventional_maturity_years':summary['maximum_conventional_maturity_years'],
                    'n_conventional':len(brown),'n_green_in_common_fit':len(green),
                    'conventional_yield_rmse_bp':summary['conventional_yield_rmse_bp'],
                    'independent_root_price_error_per100':float(np.sum(base*np.exp(root*1e-4*r['h'])))-r[basis]['dirty'],
                    'muZ':DECAY_Z,'thetaZ_bp':0.,'green_term_structure_shape_estimated':False})
            if green:
                maxt=max(float(r['t'][-1]) for r in rows)
                tenors=np.unique(np.r_[.25,.5,1.,2.,3.,5.,7.,10.,15.,20.,25.,30.,maxt,
                                      [float(r['t'][-1]) for r in green]])
                ty=svensson_zero(tenors,rows[0]['treasury']); sp=(ns_integral(tenors)@beta)/tenors
                greenium=z*green_h(tenors)/tenors
                for tt,tsy,s,g in zip(tenors,ty,sp,greenium):
                    frames['issuer_zero_curves'].append({**common,'tenor_years':float(tt),
                        'treasury_zero_yield_pct':float(tsy*100),
                        'conventional_effective_zero_spread_bp':float(s),
                        'conventional_zero_yield_pct':float(tsy*100+s/100),
                        'green_zero_yield_pct':float(tsy*100+(s-g)/100),
                        'conditional_zero_greenium_bp':float(g),
                        'within_conventional_maturity_range':summary['minimum_conventional_maturity_years']<=tt<=summary['maximum_conventional_maturity_years'],
                        'within_green_maturity_range':min(float(r['t'][-1]) for r in green)<=tt<=max(float(r['t'][-1]) for r in green),
                        'outside_1_to_30_year_published_treasury_grid':bool(tt<1 or tt>30),
                        'green_term_structure_shape_estimated':False})
        if idx%100==0:
            print('Fitted issuer-month groups',idx+1,month,issuer,flush=True)
    for name,records in frames.items():
        pd.DataFrame(records).to_csv(OUT/(name+'.csv'),index=False)
    params=pd.DataFrame(frames['issuer_month_parameters'])
    inv=pd.DataFrame(frames['green_independent_inversions'])
    fit=pd.DataFrame(frames['full_curve_bond_residuals'])
    maininv=inv[inv.price_basis=='clean_assumed']
    mainparams=params[params.price_basis=='clean_assumed']
    latest=panel.month_label.max()
    issuer_summary=[]
    for issuer,gg in maininv.groupby('legal_issuer'):
        pp=mainparams[(mainparams.legal_issuer==issuer)&(mainparams.month_label.isin(gg.month_label))]
        last=gg[gg.month_label==latest]
        issuer_summary.append(dict(legal_issuer=issuer,issuer_name=gg.iloc[0].issuer_name,
            green_bonds=gg.code.nunique(),green_bond_months=len(gg),months=gg.month_label.nunique(),
            first_month=gg.month_label.min(),last_month=gg.month_label.max(),
            within_conventional_support_bond_months=int((gg.conventional_maturity_support=='within_range').sum()),
            mean_same_cashflow_greenium_bp=float(gg.same_cashflow_yield_greenium_bp.mean()),
            median_same_cashflow_greenium_bp=float(gg.same_cashflow_yield_greenium_bp.median()),
            mean_independent_zero_greenium_bp=float(gg.independent_endpoint_zero_greenium_bp.mean()),
            median_conventional_fit_rmse_bp=float(pp.conventional_yield_rmse_bp.median()),
            maximum_conventional_fit_rmse_bp=float(pp.conventional_yield_rmse_bp.max()),
            latest_green_bonds=len(last),latest_common_z_bp=float(last.iloc[0].common_z_bp) if len(last) else np.nan,
            latest_conventional_fit_rmse_bp=float(last.iloc[0].conventional_yield_rmse_bp) if len(last) else np.nan))
    pd.DataFrame(issuer_summary).to_csv(OUT/'issuer_summary.csv',index=False)
    inv[inv.month_label==latest].to_csv(OUT/'latest_green_diagnostics.csv',index=False)
    fit[fit.month_label==latest].to_csv(OUT/'latest_bond_prices_preoption.csv',index=False)
    summary=dict(status='completed_conditional_pre_option_monthly_expansion',
        n_verified_contracts_in_register=len(contracts),n_cashflow_eligible_contracts=len(bonds),
        n_reproduced_bond_months=len(panel),n_reproduced_green_bond_months=int(panel.green.sum()),
        n_bond_month_observations=len(panel),
        n_archived_bond_months_reproduced=int(checks.archived_observation_reproduced.sum()),
        n_new_verified_bond_months=int((~checks.archived_observation_reproduced).sum()),
        n_priced_distinct_contracts=panel.Code.nunique(),
        n_supported_green_bond_months=len(maininv),n_supported_distinct_green_bonds=maininv.code.nunique(),
        n_supported_legal_issuers=maininv.legal_issuer.nunique(),
        n_conventional_issuer_month_fits=len(mainparams),
        n_issuer_months_with_green_quotes=int((mainparams.n_green>0).sum()),
        n_latest_green_bonds=int((maininv.month_label==latest).sum()),
        first_month=panel.month_label.min(),latest_month=latest,
        n_preoption_price_predictions_clean_basis=int((fit.price_basis=='clean_assumed').sum()),
        n_latest_preoption_price_predictions_clean_basis=int(((fit.price_basis=='clean_assumed')&(fit.month_label==latest)).sum()),
        n_independent_inversions_within_conventional_maturity_range=int((maininv.conventional_maturity_support=='within_range').sum()),
        maximum_inversion_price_error=float(inv.independent_root_price_error_per100.abs().max()),
        minimum_constraint_forward_bp=float(params.minimum_fitted_forward_bp.min()),
        fit_coefficient_bound_flags=int(params.any_coefficient_bound.sum()),
        common_green_bound_flags=int(params.common_green_any_bound.fillna(False).astype(bool).sum()),
        clean_basis_optimizer_failures=int((~mainparams.optimizer_success).sum()),
        dirty_basis_optimizer_failures=int((~params.loc[params.price_basis=='dirty_assumed','optimizer_success']).sum()),
        optimizer_failures=int((~params.optimizer_success).sum()),
        green_optimizer_failures=int((params.common_green_optimizer_success==False).sum()),
        cashflow_reproduction_max_errors=summary_checks,
        matched_method_counts=matched.groupby('comparison_method').agg(green_bonds=('green_code','nunique'),bond_months=('green_code','size')).reset_index().to_dict('records'),
        max_matched_yield_reproduction_error_bp=max(float(matched[f'raw_matched_reproduction_error_{b}_bp'].abs().max()) for b in ['clean_assumed','dirty_assumed']),
        issuer_summaries=issuer_summary,
        scope=dict(price_basis_verified=False,quote_timestamps_verified=False,
            treasury_quote_alignment='same valuation proxy date as GSW, monthly provider quote timestamp unverified',
            treasury_initial_curve='published GSW Svensson curve exactly matched by deterministic AFNS++ shift',
            stochastic_AFNS_transition_calibrated_or_used_in_this_script=False,
            options_valued=False,options_imputed=False,
            credit_curve='effective pre-option conventional discount spread fitted to callable quotes',
            minimum_horizon_years=MIN_HORIZON,maximum_horizon_screen=None,
            conventional_forward_constraint='nonnegative over all nonnegative horizons; exact interior-minimum and infinite-horizon limit check',
            green_shape='deterministic signed common current state, mu=.1 fixed, theta=0, sigma=0',
            estimation='separate dated cross-sections; not filtered states or a panel estimator',
            matching='fixed prior ex-post nearest or bracketing registry; no rating,amount,liquidity controls; not a reproduction of full Zerbib estimator'),
        additional_verified_contracts=sorted(extra_codes),
        additional_contract_source_hash=sha(args.extra_contracts) if args.extra_contracts else None,
        source_hashes={os.path.relpath(p,OUT):sha(p) for p in [COMPARISON/'normalized_contracts.json',
            COMPARISON/'contract_eligibility.csv',COMPARISON/'bond_month_values.csv',
            COMPARISON/'matched_panel_monthly.csv',GSW_FILE,RAW_FILE]},
        code_sha256=sha(__file__))
    (OUT/'summary.json').write_text(json.dumps(summary,indent=2,default=lambda x:x.item() if isinstance(x,np.generic) else str(x)))
    print(json.dumps({k:summary[k] for k in ['n_supported_green_bond_months','n_supported_distinct_green_bonds',
          'n_supported_legal_issuers','n_latest_green_bonds','optimizer_failures','green_optimizer_failures',
          'maximum_inversion_price_error','minimum_constraint_forward_bp']},indent=2),flush=True)


if __name__=='__main__':
    main()
