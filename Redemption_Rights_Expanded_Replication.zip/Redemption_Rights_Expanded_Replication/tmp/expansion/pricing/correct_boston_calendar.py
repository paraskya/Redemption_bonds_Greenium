"""Correct Boston contractual ceiling to calendar months; preserve prior results."""
import argparse,json,shutil,subprocess,sys
from pathlib import Path
from run_expanded_batch import load_inputs,HWSettings,prep_job,save
p=argparse.ArgumentParser();p.add_argument('--base',required=True);p.add_argument('--expanded',required=True);a=p.parse_args()
base=Path(a.base);expanded=Path(a.expanded);slug='Boston_Properties_Limited_Partnership';archive=base.parent/'archived_Boston_before_calendar_ceiling_correction';archive.mkdir(exist_ok=True)
run=json.loads((base/'run_configuration.json').read_text());cfg=run['arguments'];sig=run['cache_signature'];data=load_inputs(cfg['register'],cfg['prices'],cfg['month'],issuer='Boston Properties Limited Partnership');settings=HWSettings(**run['settings']);afns=json.loads(Path(cfg['afns_config']).read_text());afns['epsF']=0.
shutil.copytree(base/slug,archive/'issuer_result',dirs_exist_ok=True)
records=[]
for c in data['terms']:
 cache=base/'cache'/f'{c}_{sig}.pkl';shutil.move(cache,archive/cache.name)
 if cache.with_suffix('.json').exists():shutil.move(cache.with_suffix('.json'),archive/cache.with_suffix('.json').name)
 r=prep_job((c,data['terms'][c],data['valuation'],cfg['month'],cfg['curve_parameters'],afns,settings,cfg['h15'],cache));records.append(r);print(json.dumps(dict(stage='Boston_calendar_corrected',**r)),flush=True)
(base/slug/'summary.json').unlink()
subprocess.run([sys.executable,str(Path(__file__).parent/'fit_prepared_issuer.py'),'--out',str(base),'--issuer','Boston Properties Limited Partnership'],check=True)
shutil.copytree(base/slug,expanded/slug,dirs_exist_ok=True)
expanded_sig=json.loads((expanded/'run_configuration.json').read_text())['cache_signature']
for c in data['terms']:
 target=expanded/'cache'/f'{c}_{expanded_sig}.pkl'
 if target.exists():target.unlink()
 target.hardlink_to(base/'cache'/f'{c}_{sig}.pkl')
for out in (base,expanded):
 save(out/'Boston_calendar_ceiling_correction.json',dict(previous_results_preserved=str(archive),reason='Ceiling counts calendar months with month-end clamping, not ACT365.25 times12.',codes=list(data['terms']),only_Boston_payoffs_changed=True,other_cache_terms_and_numerics_unchanged=True,records=records))
 subprocess.run([sys.executable,str(Path(__file__).parent/'append_exact_inversions.py'),'--out',str(out)],check=True)
