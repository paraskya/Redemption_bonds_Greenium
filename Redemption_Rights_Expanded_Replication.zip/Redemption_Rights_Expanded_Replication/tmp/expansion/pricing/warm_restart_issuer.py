"""Warm-restart one completed issuer on exactly its cached paths, preserving the incumbent."""
import argparse,json,time
from pathlib import Path
import numpy as np
import pandas as pd
from cache_io import load_cached_pricer
from run_expanded_batch import load_inputs,TreasuryCurve,fit_one,price_one,slug,save,clear
p=argparse.ArgumentParser();p.add_argument('--results',required=True);p.add_argument('--issuer',required=True);p.add_argument('--out',required=True);p.add_argument('--maxiter',type=int,default=45);a=p.parse_args()
base=Path(a.results);out=Path(a.out);out.mkdir(parents=True,exist_ok=True)
run=json.loads((base/'run_configuration.json').read_text());cfg=run['arguments'];sig=run['cache_signature']
d=load_inputs(cfg['register'],cfg['prices'],cfg['month'],issuer=a.issuer,holdout_codes=('92343VGK',));part=d['observations'];codes=part.code.tolist()
previous=json.loads((base/slug(a.issuer)/'summary.json').read_text());curve=TreasuryCurve(cfg['month'],'gsw_svensson',cfg['curve_parameters'])
pp={c:load_cached_pricer(base/'cache'/f'{c}_{sig}.pkl') for c in codes}
start=time.time();sp,g,fit,gfit=fit_one(d,curve,pp,out,a.maxiter,initial_parameters_bp=previous['conventional_fit']['parameters_bp']);rows=[]
for c in codes:
 rows.append(price_one(c,d,pp[c],curve,sp,g,out));pd.DataFrame(rows).to_csv(out/'all_bond_prices.csv',index=False)
 print(json.dumps(dict(stage='priced_warm_restart',code=c)),flush=True)
df=pd.DataFrame(rows);support=part.loc[part.split.eq('conventional_fit'),'final_payment_horizon_years'];df['inside_conventional_maturity_support']=df.final_payment_horizon_years.between(support.min(),support.max());df.to_csv(out/'all_bond_prices.csv',index=False)
t=np.unique(np.r_[1/12,.25,.5,np.arange(1,31),np.linspace(.1,40,400)]);r=curve.zero(t);s=sp.zero(t);z=g.zero(t)
pd.DataFrame(dict(issuer=a.issuer,tenor_years=t,treasury_zero_pct=100*r,credit_zero_spread_bp=1e4*s,greenium_zero_bp=1e4*z,brown_zero_pct=100*(r+s),green_zero_pct=100*(r+s-z),conventional_maturity_support_min=support.min(),conventional_maturity_support_max=support.max())).to_csv(out/'zero_curves.csv',index=False)
summary=dict(issuer=a.issuer,contracts=len(rows),conventional_fit=fit,green_fit=gfit,seconds=time.time()-start,overall_yield_rmse_bp=float(np.sqrt(np.mean(df.actual_yield_error_bp**2))),max_decomposition_error=float(df.price_decomposition_error_per100.abs().max()),paired_mc_error_only=True,filtered_dynamic_panel_estimated=False)
save(out/'summary.json',summary)
old=pd.read_csv(base/slug(a.issuer)/'all_bond_prices.csv').set_index('code');new=df.set_index('code')
save(out/'warm_restart_comparison.json',dict(previous_optimizer_success=previous['conventional_fit']['optimizer_success'],optimizer_success=fit['optimizer_success'],previous_rmse_bp=previous['conventional_fit']['weighted_price_rmse_bp'],restarted_rmse_bp=fit['weighted_price_rmse_bp'],old_common_z_bp=previous['green_fit']['z_bp'],new_common_z_bp=gfit['z_bp'],maximum_actual_option_change_per100=float((new.actual_option_value_per100-old.actual_option_value_per100).abs().max()),maximum_green_correction_change_bp=float((new.loc[new.is_green,'same_contract_option_correction_to_greenium_yield_bp']-old.loc[old.is_green,'same_contract_option_correction_to_greenium_yield_bp']).abs().max())))
for p in pp.values():clear(p)
