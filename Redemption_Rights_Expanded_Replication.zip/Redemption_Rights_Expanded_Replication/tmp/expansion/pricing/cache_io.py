"""Optional file-backed arrays for large Treasury-only preparation caches."""
from pathlib import Path
import pickle,os
import numpy as np
import expanded_pricer


def load_cached_pricer(path):
    with Path(path).open('rb') as f:p=pickle.load(f)
    for name,file in getattr(p,'_mmap_array_paths',{}).items():
        setattr(p,name,np.load(file,mmap_mode='r'))
    return p


def compact_cache(path,aliases=()):
    path=Path(path)
    with path.open('rb') as f:p=pickle.load(f)
    if getattr(p,'_mmap_array_paths',None):return {'path':str(path),'already_compacted':True}
    old_inode=(path.stat().st_dev,path.stat().st_ino)
    folder=path.parent/'mmap'/path.stem;folder.mkdir(parents=True,exist_ok=True);mapping={};size=0
    for name,value in list(vars(p).items()):
        if isinstance(value,np.ndarray) and value.nbytes>=1_000_000:
            target=folder/f'{name}.npy';np.save(target,value);mapping[name]=str(target.resolve());size+=value.nbytes;setattr(p,name,None)
    p._mmap_array_paths=mapping
    temp=path.with_suffix('.thin.tmp')
    with temp.open('wb') as f:pickle.dump(p,f,pickle.HIGHEST_PROTOCOL)
    temp.replace(path)
    for alias in aliases:
        alias=Path(alias)
        if alias.exists() and (alias.stat().st_dev,alias.stat().st_ino)==old_inode:
            alias.unlink();os.link(path,alias)
    return {'path':str(path),'array_bytes':size,'arrays':list(mapping),'pickle_bytes':path.stat().st_size}


def load_cached_pricers(paths,heap_budget_bytes=2_000_000_000):
    """Map large cache groups before loading them together to limit heap pressure.

    Mapping changes storage only; exact saved arrays and pricing are unchanged.
    The resulting thin-pickle paths are local cache implementation details and
    are regenerated, not shipped as portable data.
    """
    paths={c:Path(v) for c,v in paths.items()}
    if sum(v.stat().st_size for v in paths.values())>heap_budget_bytes:
        for v in paths.values():
            if v.stat().st_size>1_000_000:compact_cache(v)
    return {c:load_cached_pricer(v) for c,v in paths.items()}
