"""Contract-aware multi-issuer extension of the saved conditional AFNS++ pricer.

Original AFNS++ simulation, discounting, finite-grid policy and evaluation are
reused unchanged. This adapter adds notice-relative fixings, contractual H.15
selection variants and an explicitly declared continuous-par dealer proxy.
It does not synthesize dealer quotations or claim a complete lifecycle audit.
"""
from __future__ import annotations
import os
for key in ('OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS'):
    os.environ[key]='1'
from pathlib import Path
import sys, time
from datetime import timedelta
from dataclasses import replace
from functools import lru_cache
import numpy as np

ENGINE_ROOT=Path(__file__).resolve().parents[2]/'paper_pricing'/'engine'
for folder in ('alternative/code','corporate/code','treasury/code'):
    sys.path.insert(0,str(ENGINE_ROOT/folder))
from afns_shifted_contract_pricer import AFNSContractPricer, psd_root
from hull_white_contract_pricer import HWSettings, HullWhiteCurveModel
from dated_bond_pricer import BondPricer, BondTerms, NumericalSettings, as_date, years, thirty360, add_months
from history_pricer import HistoryBondPricer
from scipy.stats import qmc,norm


class ExpandedSchedule(HistoryBondPricer):
    """Schedule helpers only; actual paths live in ExpandedAFNSPricer."""
    def fixing_dates(self,n,r):
        relative=self.terms.expansion_metadata['fixing_relative_to']
        anchor=n if relative=='notice_date' else r
        f=self.calendar.shift(anchor,-self.terms.fixing_lag_business_days)
        if self.terms.benchmark_method=='h15_weekly_2017':
            monday=f-timedelta(days=f.weekday()+7)
            return tuple(monday+timedelta(days=k) for k in range(5)
                         if self.h15_business(monday+timedelta(days=k)))
        if self.terms.benchmark_method=='h15_daily_2023':
            obs=f
            while not self.h15_business(obs):obs-=timedelta(days=1)
            for _ in range(self.terms.h15_publication_lag_business_days):
                obs-=timedelta(days=1)
                while not self.h15_business(obs):obs-=timedelta(days=1)
            return (obs,)
        return (f,)

    @lru_cache(maxsize=8192)
    def h15_tenor_selection(self,r):
        metadata=self.terms.expansion_metadata
        if metadata['benchmark_class']=='dealer':
            # A selected Treasury quote is unavailable. The maintained proxy
            # is a par bond of exactly the contractual remaining horizon.
            return (12*years(r,self.terms.benchmark_reference_date),),(1.,)
        if metadata['weekly_interpolation']=='legacy_three_month_tolerance':
            return super().h15_tenor_selection(r)
        if self.terms.benchmark_method=='h15_daily_2023':
            return super().h15_tenor_selection(r)
        tenors=np.array([1,3,6,12,24,36,60,84,120,240,360],float)
        life=12*years(r,self.terms.benchmark_reference_date)
        if metadata['weekly_interpolation']=='always_bracket_ceiling_month':
            reference=self.terms.benchmark_reference_date
            months=max(0,12*(reference.year-r.year)+reference.month-r.month)
            while add_months(r,months)<reference:months+=1
            while months>0 and add_months(r,months-1)>=reference:months-=1
            life=float(months)
        else:life=float(np.floor(life+.5))
        match=np.flatnonzero(tenors==life)
        if len(match):return (int(tenors[match[0]]),),(1.,)
        hi=int(np.searchsorted(tenors,life))
        if hi==0:lo,hi=0,1
        elif hi==len(tenors):lo,hi=len(tenors)-2,len(tenors)-1
        else:lo=hi-1
        w=(life-tenors[lo])/(tenors[hi]-tenors[lo])
        return (int(tenors[lo]),int(tenors[hi])),(1-w,w)


class ExpandedAFNSPricer(AFNSContractPricer):
    def __init__(self,terms,valuation,curve,config,settings=None,h15=None,progress=None):
        if float(config.get('epsF',0.))!=0.:
            raise ValueError('Expansion baseline requires driftless Q credit level epsF=0')
        started=time.time();self.terms=terms;self.valuation=as_date(valuation)
        self.afns_config={'lam':float(config['lam']),'covariance':np.asarray(config['covariance'])[:3,:3].tolist(),'epsF':0.}
        self.settings=settings or HWSettings();self.max_treasury_horizon_years=0.
        if terms.expansion_metadata['notice_max_unverified']:
            self.settings=replace(self.settings,notice_lags=(terms.notice_min_days,))
        self.model=HullWhiteCurveModel(curve,1.,1.)
        self.h15=h15 or {};self.progress=progress;self.dtype=np.dtype(self.settings.cache_dtype)
        ns=NumericalSettings(train_paths=self.settings.train_paths,evaluation_paths=self.settings.evaluation_paths,
            step_days=self.settings.step_days,seed=self.settings.seed,qmc_power=self.settings.qmc_power,
            notice_lags=self.settings.notice_lags)
        self.schedule=object.__new__(ExpandedSchedule)
        BondPricer.__init__(self.schedule,terms,None,self.valuation,self.valuation,ns)
        self.dates=self.schedule.dates;self.times=np.array([years(self.valuation,d) for d in self.dates])
        self.ntrain=self.settings.train_paths;self.neval=self.settings.evaluation_paths;self.npath=self.ntrain+self.neval
        self.actions=[];history=set();self.actions_by_node=[]
        for j,n in enumerate(self.dates):
            inds=[]
            if j>0:
                for r in self.schedule.redemption_candidates(n):
                    obs=self.schedule.fixing_dates(n,r) if r<terms.par_call_date else ()
                    for s in obs:
                        if self.valuation<s<=n:history.add(s)
                    inds.append(len(self.actions));self.actions.append((j,n,r,obs))
            self.actions_by_node.append(inds)
        # Minimal exact finite-grid history state: known stochastic fixing
        # dates that enter at least one current or future available action.
        self.history_lag_dates=[]
        for j,n in enumerate(self.dates):
            needed={s for k,_,_,obs in self.actions if k>=j for s in obs
                    if self.valuation<s<=n}
            self.history_lag_dates.append(sorted(needed))
        self.history_dimension=max((len(v) for v in self.history_lag_dates),default=0)
        self.sim_dates=sorted(set(self.dates)|history)
        self.sim_times=np.array([years(self.valuation,d) for d in self.sim_dates])
        self._simulate()
        self.history_features=None
        if self.history_dimension:
            self.history_features=np.zeros((len(self.dates),self.npath,3*self.history_dimension),dtype=self.dtype)
            for j,lag_dates in enumerate(self.history_lag_dates):
                for k,s in enumerate(lag_dates):
                    past=self.all_x[:,self.sim_index[s],:] if s>self.valuation else np.zeros((self.npath,3))
                    self.history_features[j,:,3*k:3*k+3]=(past-self.x[:,j,:])/self.model.factor_scale
        self.cf_dates=[d for d in terms.payment_dates if d>self.valuation]
        self.cf_times=np.array([years(self.valuation,d) for d in self.cf_dates])
        self.cf_amounts=terms.cashflows[np.array([d>self.valuation for d in terms.payment_dates])]
        self.redemption_times=np.array([years(self.valuation,a[2]) for a in self.actions])
        self._prepare();self.preparation_seconds=time.time()-started;self.price_calls=0

    def _conditional_redemption(self,n,r,observations):
        # The superclass obtains contractual H.15 tenors from our schedule.
        # Dealer spot-par proxies use the same Gaussian conditional integral,
        # with a noninteger maturity and one dealer-fixing date.
        return super()._conditional_redemption(n,r,observations)

    def _features_at(self,j,indices,gain):
        base=self._features(self.x[indices,j],gain)
        if self.history_features is None:return base
        return np.column_stack([base,self.history_features[j,indices]])

    def cache_bytes(self):
        return super().cache_bytes()+(0 if self.history_features is None else self.history_features.nbytes)

    def price(self,*args,**kwargs):
        result=self._history_price(*args,**kwargs)
        result['treasury_model']='AFNS three factors with exact initial-curve shift (AFNS++)'
        result['AFNS_lambda']=float(self.afns_config['lam'])
        result['initial_curve_shift_extension']=True
        result['continuation_history_max_known_fixing_dates']=self.history_dimension
        result['continuation_history_published_day_lags']=self.history_dimension # legacy alias, not contiguous lags
        result.update(contract_adapter='multiissuer_v1',
            credit_Q_level_drift=0.,credit_diffusion=0.,green_diffusion=0.,
            contract_scope=self.terms.expansion_metadata)
        return result

    def _history_price(self,spread_integral,green_integral=None,return_samples=False):
        started=time.time();self.price_calls+=1
        def A(t):
            ans=np.asarray(spread_integral(t),float)
            if green_integral is not None:ans=ans-np.asarray(green_integral(t),float)
            return np.broadcast_to(ans,np.asarray(t).shape)
        if abs(float(A(np.array(0.))))>1e-10:raise ValueError('Integrated curves must vanish at zero')
        Acf=A(self.cf_times);An=A(self.times);Ar=A(self.redemption_times)
        cfweights=self.cf_amounts*np.exp(-Acf)
        # Every discount and option is recalculated for the supplied curves.
        H=np.asarray(self.cashflow_basis@cfweights,dtype=float)*np.exp(An)[:,None]
        gains=np.zeros_like(H)
        for j,ais in enumerate(self.actions_by_node):
            if not ais:continue
            for ai in ais:
                cost=np.asarray(self.redemption_tsy_pv[ai],float)*np.exp(An[j]-Ar[ai])
                cpidx=self.coupons_until_redemption[ai]
                if len(cpidx):cost=cost+(self.cashflow_basis[j][:,cpidx]@cfweights[cpidx])*np.exp(An[j])
                gains[j]=np.maximum(gains[j],H[j]-cost)
        gains=np.maximum(gains,0.)
        D=np.exp(-self.integral.T-self.model.phi_integral(self.times)[:,None]-An[:,None])
        policies=[None]*len(self.dates);future=np.zeros(self.ntrain)
        nfeatures=self._features_at(0,np.array([0]),np.zeros(1)).shape[1]
        for j in range(len(self.dates)-1,0,-1):
            itm=gains[j,:self.ntrain]>0
            if not np.any(itm):
                coef=np.zeros(nfeatures);coef[0]=float(np.mean(future/D[j,:self.ntrain]))
                policies[j]=coef
                continue
            idx=np.flatnonzero(itm);F=self._features_at(j,idx,gains[j,idx])
            target=future[idx]/D[j,idx]
            if len(idx)<8:
                coef=np.zeros(F.shape[1]);coef[0]=target.mean()
            else:
                gram=F.T@F;ridge=self.settings.regression_ridge*max(float(np.trace(gram)),1.)/F.shape[1]
                penalty=np.eye(F.shape[1])*ridge;penalty[0,0]=0
                coef=np.linalg.solve(gram+penalty,F.T@target)
            cont=np.maximum(F@coef,0.);take=gains[j,idx]>cont
            selected=idx[take];future[selected]=D[j,selected]*gains[j,selected]
            policies[j]=coef
        # Independent evaluation at the trained policy.
        values=np.zeros(self.neval);alive=np.ones(self.neval,dtype=bool);exercise_indices=np.full(self.neval,-1,int)
        for j in range(1,len(self.dates)):
            if policies[j] is None:continue
            ii=np.flatnonzero(alive&(gains[j,self.ntrain:]>0))
            if not len(ii):continue
            idx=ii+self.ntrain;F=self._features_at(j,idx,gains[j,idx]);cont=np.maximum(F@policies[j],0.)
            take=ii[gains[j,idx]>cont];ti=take+self.ntrain
            values[take]=D[j,ti]*gains[j,ti];alive[take]=False;exercise_indices[take]=j
        option=float(values.mean());half=(self.neval+1)//2
        if self.neval%2==0:
            pair=.5*(values[:half]+values[half:]);se=float(pair.std(ddof=1)/np.sqrt(len(pair)))
        else:se=float(values.std(ddof=1)/np.sqrt(len(values)))
        straight=float(np.exp(self.model.curve.log_discount(self.cf_times)-Acf)@self.cf_amounts)
        result={'straight_dirty':straight,'option_value':option,'model_dirty':straight-option,
            'option_standard_error':se,'evaluation_exercise_probability':float((~alive).mean()),
            'training_option_value':float(future.mean()),'pricing_seconds':time.time()-started,
            'notice_nodes':len(self.dates),'redemption_actions':len(self.actions),
            'maximum_treasury_horizon_used_years':max(self.max_treasury_horizon_years,float(self.cf_times[-1])),
            'treasury_model':'Hull-White one factor with exact initial-curve shift',
            'credit_diffusion':0.,'green_diffusion':0.,'finite_grid':True,
            'history_fixings_retained':True,'own_option_revalued_at_every_price':True,
            'observed_price_used':False,'standard_error_scope':'Antithetic independent policy-evaluation sampling error; excludes policy, grid, fixing integration, parameter and price-input uncertainty.'}
        if return_samples:result['_option_samples']=values;result['_exercise_indices']=exercise_indices
        return result
