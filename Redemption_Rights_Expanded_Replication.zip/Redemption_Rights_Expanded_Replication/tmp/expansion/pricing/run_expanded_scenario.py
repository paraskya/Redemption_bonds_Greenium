"""Expand the frozen original-register branch with verified additional anchors.

Cached old contracts keep exactly the same payoffs and numerical settings.
Only new/changed contracts prepare new caches. Old literal make-whole wording
is explicitly tagged on each affected contract and in the run configuration.
"""
import argparse,json,os,subprocess,sys,time,shutil
from pathlib import Path
from run_expanded_batch import load_inputs,HWSettings,prep_job,slug,save

p=argparse.ArgumentParser();p.add_argument('--base-results',required=True);p.add_argument('--register',required=True);p.add_argument('--prices',required=True);p.add_argument('--out',required=True);a=p.parse_args()
base=Path(a.base_results);out=Path(a.out);out.mkdir(parents=True,exist_ok=True);(out/'cache').mkdir(exist_ok=True)
b=json.loads((base/'run_configuration.json').read_text());cfg=dict(b['arguments']);cfg.update(register=a.register,prices=a.prices,out=str(out),stage='all',codes=None,issuer=None,workers=1)
if (out/'run_configuration.json').exists():sig=json.loads((out/'run_configuration.json').read_text())['cache_signature']
else:sig=b['cache_signature']+'_expanded'
data=load_inputs(a.register,a.prices,cfg['month'],holdout_codes=('92343VGK',));settings=HWSettings(**b['settings']);config=json.loads(Path(cfg['afns_config']).read_text());config['epsF']=0.
original=set(b['codes']);codes=data['observations'].code.tolist();data['observations'].to_csv(out/'observations.csv',index=False)
run=dict(b,arguments=cfg,cache_signature=sig,codes=codes,source_hashes=data['source_hashes'],
    branch='expanded conditional original-term scenario with additional conventional anchors',
    literal_full_schedule_plus_accrued_codes=[c for c,t in data['terms'].items() if t.expansion_metadata.get('literal_accrued_scenario')],
    explicit_noncallable_codes=[c for c,t in data['terms'].items() if not t.callable],
    base_branch_preserved=True,expected_contracts=len(codes))
save(out/'run_configuration.json',run);save(out/'excluded_contracts.json',data['exclusions'])
for c in codes:
 target=out/'cache'/f'{c}_{sig}.pkl'
 if target.exists():continue
 old=base/'cache'/f'{c}_{b["cache_signature"]}.pkl'
 if c in original:
  if old.exists():os.link(old,target)
  continue
 result=prep_job((c,data['terms'][c],data['valuation'],cfg['month'],cfg['curve_parameters'],config,settings,cfg['h15'],target))
 print(json.dumps(dict(stage='prepared_expansion',**result)),flush=True)
for issuer in ['MidAmerican Energy Company','DTE Electric Company','Northern States Power Company (Minnesota)']:
 if (out/slug(issuer)/'summary.json').exists():continue
 needed=data['observations'].loc[data['observations'].issuer.eq(issuer),'code'].tolist()
 for c in needed:
  target=out/'cache'/f'{c}_{sig}.pkl'
  if not target.exists():
   old=base/'cache'/f'{c}_{b["cache_signature"]}.pkl'
   if not old.exists():raise ValueError(f'Original issuer preparation not yet completed: {c}')
   os.link(old,target)
 print(json.dumps(dict(stage='fit_expanded_issuer',issuer=issuer)),flush=True)
 subprocess.run([sys.executable,str(Path(__file__).parent/'fit_prepared_issuer.py'),'--out',str(out),'--issuer',issuer],check=True)
# The five unchanged issuer fits are copied from the completed frozen branch.
others=[i for i in data['observations'].issuer.unique() if i not in ['MidAmerican Energy Company','DTE Electric Company','Northern States Power Company (Minnesota)']]
for issuer in others:
 source=base/slug(issuer)
 while not (source/'summary.json').exists():
  print(json.dumps(dict(stage='waiting_for_original_issuer_fit',issuer=issuer)),flush=True);time.sleep(30)
 shutil.copytree(source,out/slug(issuer),dirs_exist_ok=True)
subprocess.run([sys.executable,str(Path(__file__).parent/'append_exact_inversions.py'),'--out',str(out)],check=True)
print(json.dumps(dict(stage='completed_expanded_branch',expected_contracts=len(codes))),flush=True)
