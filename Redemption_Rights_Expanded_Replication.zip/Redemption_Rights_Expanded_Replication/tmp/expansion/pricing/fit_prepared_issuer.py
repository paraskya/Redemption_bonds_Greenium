"""Fit one already-prepared issuer while other contracts prepare in parallel."""
import argparse,pickle,json,time
from pathlib import Path
import numpy as np
import pandas as pd
from cache_io import load_cached_pricers
from run_expanded_batch import load_inputs,TreasuryCurve,fit_one,price_one,slug,save,clear
p=argparse.ArgumentParser();p.add_argument('--out',required=True);p.add_argument('--issuer',required=True);a=p.parse_args()
out=Path(a.out);run=json.loads((out/'run_configuration.json').read_text());cfg=run['arguments'];sig=run['cache_signature']
d=load_inputs(cfg['register'],cfg['prices'],cfg['month'],issuer=a.issuer,holdout_codes=('92343VGK',));part=d['observations'];codes=part.code.tolist()
dest=out/slug(a.issuer);dest.mkdir(exist_ok=True)
if (dest/'summary.json').exists():raise SystemExit(0)
curve=TreasuryCurve(cfg['month'],'gsw_svensson',cfg['curve_parameters']);pp=load_cached_pricers({c:out/'cache'/f'{c}_{sig}.pkl' for c in codes})
start=time.time();sp,g,fit,gfit=fit_one(d,curve,pp,dest,cfg['maxiter']);rows=[]
for c in codes:
 rows.append(price_one(c,d,pp[c],curve,sp,g,dest));pd.DataFrame(rows).to_csv(dest/'all_bond_prices.csv',index=False)
 print(json.dumps(dict(stage='priced',issuer=a.issuer,code=c,actual_yield_error_bp=rows[-1]['actual_yield_error_bp'])),flush=True)
df=pd.DataFrame(rows);support=part.loc[part.split.eq('conventional_fit'),'final_payment_horizon_years'];df['inside_conventional_maturity_support']=df.final_payment_horizon_years.between(support.min(),support.max());df.to_csv(dest/'all_bond_prices.csv',index=False)
t=np.unique(np.r_[1/12,.25,.5,np.arange(1,31),np.linspace(.1,40,400)]);r=curve.zero(t);s=sp.zero(t);z=g.zero(t)
pd.DataFrame(dict(issuer=a.issuer,tenor_years=t,treasury_zero_pct=100*r,credit_zero_spread_bp=1e4*s,greenium_zero_bp=1e4*z,brown_zero_pct=100*(r+s),green_zero_pct=100*(r+s-z),conventional_maturity_support_min=support.min(),conventional_maturity_support_max=support.max())).to_csv(dest/'zero_curves.csv',index=False)
summary=dict(issuer=a.issuer,contracts=len(rows),conventional_fit=fit,green_fit=gfit,seconds=time.time()-start,overall_yield_rmse_bp=float(np.sqrt(np.mean(df.actual_yield_error_bp**2))),max_decomposition_error=float(df.price_decomposition_error_per100.abs().max()),paired_mc_error_only=True,filtered_dynamic_panel_estimated=False)
save(dest/'summary.json',summary)
for p in pp.values():clear(p)
