"""Resumable actual-contract AFNS++ preparation, issuer fitting and paired pricing.

The preparation cache contains no observed prices. Each fit objective reprices
own options under trial deterministic issuer/green curves. No old stochastic
credit calibration or epsilon=.05 specification is used.
"""
from __future__ import annotations
import os
for k in ('OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS'):os.environ[k]='1'
import argparse,json,time,pickle,gc,hashlib
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor,as_completed
import numpy as np
import pandas as pd
from scipy.optimize import minimize,minimize_scalar,LinearConstraint
from cache_io import load_cached_pricer,load_cached_pricers
from expansion_data import load_inputs,sha256
from expanded_pricer import ExpandedAFNSPricer,HWSettings,ENGINE_ROOT
from corporate_data import NSSpread,GreenIntegral
from treasury_curves import TreasuryCurve
from history_pricer import load_h15

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
REG=ROOT/'restored/Zero_Coupon_Greenium_Data_and_Code/inventory/inputs/comparison/results'

def cleanjson(x):
    if isinstance(x,dict):return {str(k):cleanjson(v) for k,v in x.items()}
    if isinstance(x,(list,tuple)):return [cleanjson(v) for v in x]
    if isinstance(x,np.ndarray):return x.tolist()
    if isinstance(x,np.generic):return x.item()
    if isinstance(x,Path):return str(x)
    return x

def save(path,data):
    path=Path(path);temp=path.with_suffix(path.suffix+'.tmp');temp.write_text(json.dumps(cleanjson(data),indent=2));temp.replace(path)

def slug(s):return ''.join(c if c.isalnum() else '_' for c in s).strip('_')

def clear(p):
    for cls in type(p).__mro__:
        for value in cls.__dict__.values():
            if hasattr(value,'cache_clear'):value.cache_clear()
    for obj in (p.model,getattr(p.model,'base',None),p.schedule):
        if obj is not None:
            for cls in type(obj).__mro__:
                for value in cls.__dict__.values():
                    if hasattr(value,'cache_clear'):value.cache_clear()

def prep_job(args):
    code,terms,valuation,month,curve_path,config,settings,h15_path,cache=args
    start=time.time();curve=TreasuryCurve(month,'gsw_svensson',curve_path)
    p=ExpandedAFNSPricer(terms,valuation,curve,config,settings=settings,h15=load_h15(h15_path))
    result=dict(code=code,seconds=time.time()-start,cache_bytes=p.cache_bytes(),notice_nodes=len(p.dates),
        redemption_actions=len(p.actions),continuation_history_lags=p.history_dimension,
        maximum_treasury_horizon_used_years=max(p.max_treasury_horizon_years,float(p.cf_times[-1])))
    cache=Path(cache);temp=cache.with_suffix('.tmp')
    with temp.open('wb') as f:pickle.dump(p,f,pickle.HIGHEST_PROTOCOL)
    temp.replace(cache);save(cache.with_suffix('.json'),result);clear(p)
    return result


def dimension(n):return min(3,n)

def fit_one(data,curve,pricers,out,maxiter=45,initial_parameters_bp=None):
    obs=data['observations'].set_index('code');codes=data['fitting_codes'];greens=data['green_codes']
    npar=dimension(len(codes));
    if not npar:raise ValueError('No conventional quote to estimate issuer curve')
    transform=(np.array([[1.],[0.],[0.]]) if npar==1 else
               np.array([[1.,0.],[-1.,1.],[0.,0.]]) if npar==2 else
               np.array([[1.,0.,0.],[-1.,1.,0.],[0.,0.,1.]]))
    # Optimize long/short spread levels directly, so the active zero-forward
    # boundary is a simple bound rather than two nearly cancelling variables.
    def beta(x):return transform@np.asarray(x,float)
    caches={};progress=[]
    def prices(x,target_codes,z=None):
        sp=NSSpread(beta(x)/1e4);g=None if z is None else GreenIntegral(z/1e4)
        return {c:pricers[c].price(sp,g) for c in target_codes}
    def objective(x):
        key=tuple(np.round(x,9))
        if key not in caches:
            rr=prices(x,codes);err=np.array([(rr[c]['model_dirty']-obs.loc[c,'observed_dirty_per100'])/obs.loc[c,'dv01_per100'] for c in codes]);val=float(err@err/len(codes));caches[key]=val
            progress.append(dict(evaluation=len(caches),parameters_bp=beta(x).tolist(),weighted_price_rmse_bp=np.sqrt(val)))
            if len(caches)%20==0:save(out/'fit_progress.json',progress);print(json.dumps(dict(stage='fit',issuer=obs.issuer.iloc[0],**progress[-1])),flush=True)
        return caches[key]
    # Analytic straight initializer; no option adjustment is claimed for it.
    packed=[]
    for c in codes:
        t,cf=data['bonds'][c].cashflows(data['valuation']);packed.append((cf*curve.discount(t),NSSpread.integral_loadings(t)@transform,obs.loc[c,'observed_dirty_per100'],obs.loc[c,'dv01_per100']))
    def initial_objective(x):
        e=[];jac=[]
        for base,B,target,dv in packed:
            flow=base*np.exp(-B@x/1e4);e.append((flow.sum()-target)/dv);jac.append(-(flow[:,None]*B).sum(axis=0)/1e4/dv)
        e=np.array(e);jac=np.array(jac);return float(e@e/len(e)),2*jac.T@e/len(e)
    grid=np.r_[0.,np.geomspace(.001,200.,801)];C=NSSpread.forward_loadings(grid)@transform
    constraint=LinearConstraint(C,0.,np.inf);bounds=([(0.,1500.)] if npar==1 else [(0.,1500.),(0.,1500.)]+[(-1500.,1500.)]*(npar-2))
    starts=[np.array([120.,60.,0.])[:npar],np.array([150.,150.,-80.])[:npar]]
    ir=[minimize(initial_objective,x,jac=True,method='SLSQP',bounds=bounds,constraints=[constraint],options=dict(ftol=1e-11,maxiter=200)) for x in starts]
    initial=min(ir,key=lambda x:x.fun)
    def gradient(x):
        g=[];x=np.asarray(x)
        for k in range(npar):
            h=np.zeros(npar);h[k]=.1;g.append((objective(x+h)-objective(x-h))/.2)
        return np.array(g)
    start_point=initial.x if initial_parameters_bp is None else np.linalg.lstsq(transform,np.asarray(initial_parameters_bp,float),rcond=None)[0]
    fit=minimize(objective,start_point,jac=gradient,method='SLSQP',bounds=bounds,constraints=[constraint],options=dict(ftol=1e-4,maxiter=maxiter))
    # Retain the best feasible evaluated candidate if finite policy jumps confuse
    # a local line search; status and objective values remain visible.
    feasible=[(v,np.array(k)) for k,v in caches.items() if NSSpread(beta(k)/1e4).minimum_forward()['value']>=-1e-10]
    chosen=min(feasible,key=lambda v:v[0]) if feasible else (objective(fit.x),fit.x)
    x=chosen[1];sp=NSSpread(beta(x)/1e4)
    fitrecord=dict(issuer=obs.issuer.iloc[0],parameters_bp=beta(x),active_parameters=npar,spread_decay=.3,optimizer_coordinates='long_forward_level,short_forward_level,curvature',
        optimizer_success=bool(fit.success),optimizer_message=str(fit.message),iterations=int(fit.nit),objective_evaluations=len(caches),objective_tolerance_bp_squared=1e-4,finite_difference_step_bp=.1,
        weighted_price_rmse_bp=np.sqrt(chosen[0]),global_minimum_forward_bp=sp.minimum_forward()['value']*1e4,
        initial_parameters_bp=beta(start_point),initial_straight_parameters_bp=beta(initial.x),initial_straight_weighted_rmse_bp=np.sqrt(initial.fun),warm_restart=initial_parameters_bp is not None,
        fit_codes=codes,holdout_codes=data['holdout_codes'],all_objective_trials_reprice_own_options=True,credit_diffusion=0.,credit_Q_level_drift=0.,issuer_delta=0.)
    save(out/'conventional_fit.json',fitrecord);save(out/'fit_progress.json',progress)
    z=0.;greenrecord=None
    if greens:
        def gobj(value):
            rr=prices(x,greens,value);errs=[(rr[c]['model_dirty']-obs.loc[c,'observed_dirty_per100'])/obs.loc[c,'dv01_per100'] for c in greens]
            return float(np.mean(np.square(errs)))
        result=minimize_scalar(gobj,bounds=(-300.,300.),method='bounded',options=dict(xatol=.0001,maxiter=120))
        z=float(result.x);greenrecord=dict(issuer=obs.issuer.iloc[0],z_bp=z,theta_bp=0.,mu=.1,green_diffusion=0.,
            weighted_price_rmse_bp=np.sqrt(result.fun),optimizer_success=bool(result.success),training_codes=greens,
            shape_parameters_estimated=False,all_trials_reprice_own_options=True)
        save(out/'green_fit.json',greenrecord)
    return sp,GreenIntegral(z/1e4),fitrecord,greenrecord


def ase(samples):
    a=np.asarray(samples,float);n=len(a)
    if n%2==0:a=(a[:n//2]+a[n//2:])/2
    return float(a.std(ddof=1)/np.sqrt(len(a)))


def price_one(code,data,p,curve,spread,green,out):
    ob=data['observations'].set_index('code').loc[code];bond=data['bonds'][code];val=data['valuation']
    b=p.price(spread,None,return_samples=True);g=p.price(spread,green,return_samples=True)
    np.savez_compressed(out/f'{code}_paired_samples.npz',brown=b['_option_samples'],green=g['_option_samples'],
        brown_exercise=b['_exercise_indices'],green_exercise=g['_exercise_indices'])
    save(out/f'{code}_raw_prices.json',dict(brown={k:v for k,v in b.items() if not k.startswith('_')},green={k:v for k,v in g.items() if not k.startswith('_')}))
    r=ob.to_dict();r['code']=code;r['green_state_bp']=green.current*1e4;r['credit_parameters_bp']=';'.join(str(v) for v in spread.parameters*1e4)
    r['train_paths']=p.ntrain;r['evaluation_paths']=p.neval;r['fixing_draws']=2**p.settings.qmc_power
    r['notice_step_days']=p.settings.step_days;r['continuation_history_lags']=p.history_dimension
    r['maximum_known_fixing_dates_in_continuation']=p.history_dimension
    r['contract_accrued_valuation_convention']=p.terms.accrued_treatment
    r['literal_full_schedule_plus_accrued_scenario']=p.terms.expansion_metadata.get('literal_accrued_scenario',False)
    r['security_group']=data['contracts'][code].get('security_group')
    r['terminal_interest_per100']=float(p.terms.coupons[-1])
    actual=g if bool(ob.is_green) else b
    for label,result in [('brown',b),('green',g),('actual',actual)]:
        yc=bond.yield_from_dirty(result['model_dirty'],val);ys=bond.yield_from_dirty(result['straight_dirty'],val)
        r.update({f'{label}_straight_dirty_per100':result['straight_dirty'],f'{label}_option_value_per100':result['option_value'],
            f'{label}_callable_dirty_per100':result['model_dirty'],f'{label}_callable_clean_per100':result['model_dirty']-ob.accrued_per100,
            f'{label}_option_mc_se_per100':result['option_standard_error'],f'{label}_option_mc_se_yield_bp':result['option_standard_error']/ob.dv01_per100,
            f'{label}_callable_yield_pct':100*yc,f'{label}_straight_yield_pct':100*ys,f'{label}_option_yield_wedge_bp':1e4*(yc-ys),
            f'{label}_yield_error_bp':1e4*(yc-ob.observed_yield_pct/100),f'{label}_price_error_per100':result['model_dirty']-ob.observed_dirty_per100})
    tsy=float(curve.discount(p.cf_times)@p.cf_amounts);diff=g['option_value']-b['option_value'];premium=g['straight_dirty']-b['straight_dirty'];
    r.update(treasury_straight_dirty_per100=tsy,issuer_discount_cost_per100=tsy-b['straight_dirty'],
        same_contract_straight_green_premium_per100=premium,same_contract_callable_green_premium_per100=g['model_dirty']-b['model_dirty'],
        same_contract_green_minus_brown_option_per100=diff,same_contract_option_difference_paired_mc_se_per100=ase(g['_option_samples']-b['_option_samples']),
        same_contract_straight_greenium_yield_bp=100*(r['brown_straight_yield_pct']-r['green_straight_yield_pct']),
        same_contract_callable_greenium_yield_bp=100*(r['brown_callable_yield_pct']-r['green_callable_yield_pct']),
        same_contract_option_correction_to_greenium_yield_bp=100*(r['brown_callable_yield_pct']-r['green_callable_yield_pct']-r['brown_straight_yield_pct']+r['green_straight_yield_pct']),
        price_decomposition_error_per100=actual['model_dirty']-(tsy-(tsy-b['straight_dirty'])+(premium if ob.is_green else 0.)-actual['option_value']),
        maximum_treasury_horizon_used_years=actual['maximum_treasury_horizon_used_years'])
    # Exact zero-to-coupon bridge on the fitted common schedule.
    tau=ob.final_payment_horizon_years;rb=float(curve.zero(tau)+spread.zero(tau));rg=rb-float(green.zero(tau))
    zg=float(green.zero(tau))*1e4;nominal=2*(np.exp(rb/2)-np.exp(rg/2))*1e4
    straight=r['same_contract_straight_greenium_yield_bp'];call=r['same_contract_callable_greenium_yield_bp']
    r.update(endpoint_zero_greenium_bp=zg,zero_to_nominal_compounding_bp=nominal-zg,
        coupon_schedule_and_curve_effect_bp=straight-nominal,redemption_effect_bp=call-straight,
        exact_yield_bridge_error_bp=call-(zg+(nominal-zg)+(straight-nominal)+(call-straight)))
    return r


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--register',default=str(REG/'normalized_contracts.json'));ap.add_argument('--prices',default=str(REG/'bond_month_values.csv'))
    ap.add_argument('--month',default='2026-08-31');ap.add_argument('--out',default=str(HERE/'results'));ap.add_argument('--issuer',action='append');ap.add_argument('--codes',nargs='*')
    ap.add_argument('--stage',choices=['all','prepare','fit'],default='all');ap.add_argument('--workers',type=int,default=3)
    ap.add_argument('--train',type=int,default=768);ap.add_argument('--evaluation',type=int,default=2304);ap.add_argument('--qmc-power',type=int,default=5)
    ap.add_argument('--seed',type=int,default=20261003);ap.add_argument('--step-days',type=int,default=30);ap.add_argument('--maxiter',type=int,default=45)
    ap.add_argument('--curve-parameters',default=str(ENGINE_ROOT/'treasury/results/curve_parameters.json'))
    ap.add_argument('--afns-config',default=str(ENGINE_ROOT/'previous/pricing/inputs/selected_latest_config.json'))
    ap.add_argument('--h15',default=str(ENGINE_ROOT/'previous/pricing/inputs/treasury_daily_percent.csv'))
    args=ap.parse_args();out=Path(args.out).resolve();out.mkdir(parents=True,exist_ok=True);cache=out/'cache';cache.mkdir(exist_ok=True)
    data=load_inputs(args.register,args.prices,args.month,codes=args.codes,holdout_codes=('92343VGK',))
    if args.issuer:
        keep=data['observations'].issuer.isin(args.issuer);codes=data['observations'].loc[keep,'code'].tolist();data=load_inputs(args.register,args.prices,args.month,codes=codes,holdout_codes=('92343VGK',))
    # Guarantee homogeneous economic credit group before pooling curves.
    for issuer,part in data['observations'].groupby('issuer'):
        groups={(data['contracts'][c].get('security_group'),data['contracts'][c]['currency']) for c in part.code}
        if len(groups)!=1:raise ValueError(f'Multiple security/currency groups for {issuer}: {groups}')
    data['observations'].to_csv(out/'observations.csv',index=False);save(out/'excluded_contracts.json',data['exclusions'])
    config=json.loads(Path(args.afns_config).read_text());config['epsF']=0.
    settings=HWSettings(train_paths=args.train,evaluation_paths=args.evaluation,seed=args.seed,step_days=args.step_days,qmc_power=args.qmc_power)
    signature=hashlib.sha256(json.dumps(dict(settings=settings.__dict__,config=config,curve_hash=sha256(args.curve_parameters),adapter_hash=sha256(HERE/'expanded_pricer.py'),data_adapter_hash=sha256(HERE/'expansion_data.py')),sort_keys=True).encode()).hexdigest()[:16]
    files={c:cache/f'{c}_{signature}.pkl' for c in data['terms']};save(out/'run_configuration.json',dict(arguments=vars(args),settings=settings.__dict__,cache_signature=signature,
        baseline='conditional AFNS++ Treasury; deterministic driftless credit level; deterministic green shape',source_hashes=data['source_hashes'],codes=list(files)))
    if args.stage in ('all','prepare'):
        jobs=[]
        # Shortest first obtains useful completed issuers early without changing samples.
        ordered=data['observations'].sort_values('final_payment_horizon_years').code.tolist()
        for c in ordered:
            if not files[c].exists():jobs.append((c,data['terms'][c],data['valuation'],args.month,args.curve_parameters,config,settings,args.h15,files[c]))
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            futures={pool.submit(prep_job,j):j[0] for j in jobs}
            for f in as_completed(futures):
                code=futures[f]
                try:record=f.result();print(json.dumps(dict(stage='prepared',**record)),flush=True)
                except Exception as exc:save(out/f'preparation_error_{code}.json',dict(code=code,error=repr(exc)));raise
    if args.stage=='prepare':return
    curve=TreasuryCurve(args.month,'gsw_svensson',args.curve_parameters);allrows=[];summaries=[]
    # Small issuer curves first, so final results arrive progressively.
    issuers=data['observations'].groupby('issuer').size().sort_values().index.tolist()
    for issuer in issuers:
        part=data['observations'].loc[data['observations'].issuer.eq(issuer)].copy();codes=part.code.tolist();sub=dict(data,observations=part,
            fitting_codes=part.loc[part.split.eq('conventional_fit'),'code'].tolist(),green_codes=part.loc[part.split.eq('green'),'code'].tolist(),holdout_codes=part.loc[part.split.eq('conventional_holdout'),'code'].tolist())
        dest=out/slug(issuer);dest.mkdir(exist_ok=True)
        if (dest/'summary.json').exists() and (dest/'all_bond_prices.csv').exists():
            allrows.extend(pd.read_csv(dest/'all_bond_prices.csv').to_dict('records'));summaries.append(json.loads((dest/'summary.json').read_text()));continue
        for c in codes:
            if not files[c].exists():raise ValueError(f'Missing preparation cache {c}')
        pp=load_cached_pricers({c:files[c] for c in codes})
        start=time.time();sp,g,fit,gfit=fit_one(sub,curve,pp,dest,args.maxiter);rows=[]
        for c in codes:
            row=price_one(c,sub,pp[c],curve,sp,g,dest);rows.append(row);pd.DataFrame(rows).to_csv(dest/'all_bond_prices.csv',index=False)
            print(json.dumps(dict(stage='priced',issuer=issuer,code=c,actual_yield_error_bp=row['actual_yield_error_bp'],green_state_bp=row['green_state_bp'])),flush=True)
        df=pd.DataFrame(rows);support=part.loc[part.split.eq('conventional_fit'),'final_payment_horizon_years'];df['inside_conventional_maturity_support']=df.final_payment_horizon_years.between(support.min(),support.max());df.to_csv(dest/'all_bond_prices.csv',index=False)
        t=np.r_[1/12,.25,.5,np.arange(1,31),np.linspace(.1,40,400)];t=np.unique(t);r=curve.zero(t);s=sp.zero(t);z=g.zero(t)
        pd.DataFrame(dict(issuer=issuer,tenor_years=t,treasury_zero_pct=100*r,credit_zero_spread_bp=1e4*s,greenium_zero_bp=1e4*z,
            brown_zero_pct=100*(r+s),green_zero_pct=100*(r+s-z),conventional_maturity_support_min=support.min(),conventional_maturity_support_max=support.max())).to_csv(dest/'zero_curves.csv',index=False)
        summary=dict(issuer=issuer,contracts=len(rows),conventional_fit=fit,green_fit=gfit,seconds=time.time()-start,
            overall_yield_rmse_bp=float(np.sqrt(np.mean(df.actual_yield_error_bp**2))),max_decomposition_error=float(df.price_decomposition_error_per100.abs().max()),
            paired_mc_error_only=True,filtered_dynamic_panel_estimated=False)
        save(dest/'summary.json',summary);summaries.append(summary);allrows.extend(df.to_dict('records'));pd.DataFrame(allrows).to_csv(out/'all_bond_prices.csv',index=False);save(out/'summaries.json',summaries)
        for p in pp.values():clear(p)
        del pp;gc.collect()

if __name__=='__main__':main()
