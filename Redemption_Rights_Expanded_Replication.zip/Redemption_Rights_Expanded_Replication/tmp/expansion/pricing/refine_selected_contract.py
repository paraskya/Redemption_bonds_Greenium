"""Targeted path/grid refinement at fixed fitted issuer and green parameters."""
import argparse,json
from pathlib import Path
import numpy as np
import pandas as pd
from run_expanded_batch import load_inputs,TreasuryCurve,HWSettings,NSSpread,GreenIntegral,price_one,save
from expanded_pricer import ExpandedAFNSPricer
from history_pricer import load_h15
p=argparse.ArgumentParser();p.add_argument('--results',required=True);p.add_argument('--issuer-dir',required=True);p.add_argument('--code',required=True);p.add_argument('--out',required=True);a=p.parse_args()
results=Path(a.results);issuer=results/a.issuer_dir;out=Path(a.out);out.mkdir(parents=True,exist_ok=True)
config=json.loads((results/'run_configuration.json').read_text())['arguments']
data=load_inputs(config['register'],config['prices'],config['month'],codes=[a.code]);fit=json.loads((issuer/'conventional_fit.json').read_text());gf=json.loads((issuer/'green_fit.json').read_text())
curve=TreasuryCurve(config['month'],'gsw_svensson',config['curve_parameters']);afns=json.loads(Path(config['afns_config']).read_text());afns['epsF']=0.
settings=HWSettings(train_paths=1536,evaluation_paths=4608,step_days=15,seed=20261100,qmc_power=6)
pricer=ExpandedAFNSPricer(data['terms'][a.code],data['valuation'],curve,afns,settings=settings,h15=load_h15(config['h15']))
spread=NSSpread(np.array(fit['parameters_bp'])/1e4);green=GreenIntegral(gf['z_bp']/1e4)
new=price_one(a.code,data,pricer,curve,spread,green,out);old=pd.read_csv(issuer/'all_bond_prices.csv').set_index('code').loc[a.code].to_dict();old['code']=a.code
rows=[]
for name,row in [('reported_refined_settings',old),('additional_grid_path_refinement',new)]:rows.append(dict(refinement_case=name,**row))
pd.DataFrame(rows).to_csv(out/'refinement_prices.csv',index=False)
checks=dict(code=a.code,parameters_fixed=True,parameter_refit=False,reference=dict(train_paths=int(old['train_paths']),evaluation_paths=int(old['evaluation_paths']),step_days=int(old['notice_step_days']),fixing_draws=int(old['fixing_draws'])),refined=settings.__dict__,
    actual_option_change_per100=new['actual_option_value_per100']-old['actual_option_value_per100'],
    actual_option_yield_wedge_change_bp=new['actual_option_yield_wedge_bp']-old['actual_option_yield_wedge_bp'],
    same_contract_redemption_correction_change_bp=new['same_contract_option_correction_to_greenium_yield_bp']-old['same_contract_option_correction_to_greenium_yield_bp'],
    refined_correction_bp=new['same_contract_option_correction_to_greenium_yield_bp'],reported_correction_bp=old['same_contract_option_correction_to_greenium_yield_bp'],
    refined_paired_option_price_se_per100=new['same_contract_option_difference_paired_mc_se_per100'],preparation_seconds=pricer.preparation_seconds,
    scope='Single largest observed-green correction among completed newissuer results; independent refinement seed, fixed parameters; numerical sensitivity, not a global optimal-stopping error bound.')
save(out/'refinement_summary.json',checks);print(json.dumps(checks),flush=True)
