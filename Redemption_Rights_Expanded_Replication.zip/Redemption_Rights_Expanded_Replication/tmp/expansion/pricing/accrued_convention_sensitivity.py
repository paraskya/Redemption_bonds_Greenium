"""Fixed-parameter same-path comparison of the legacy make-whole accrued clause."""
import argparse,json,copy
from pathlib import Path
import numpy as np
import pandas as pd
from run_expanded_batch import load_inputs,TreasuryCurve,HWSettings,NSSpread,GreenIntegral,price_one,save,ase,clear
from cache_io import load_cached_pricer
from expanded_pricer import ExpandedAFNSPricer
from history_pricer import load_h15
p=argparse.ArgumentParser();p.add_argument('--results',required=True);p.add_argument('--issuer-dir',required=True);p.add_argument('--codes',nargs='+',required=True);p.add_argument('--out',required=True);a=p.parse_args()
results=Path(a.results);issuer=results/a.issuer_dir;out=Path(a.out);out.mkdir(parents=True,exist_ok=True)
run=json.loads((results/'run_configuration.json').read_text());cfg=run['arguments'];sig=run['cache_signature']
data=load_inputs(cfg['register'],cfg['prices'],cfg['month'],codes=a.codes);fit=json.loads((issuer/'conventional_fit.json').read_text());gf=json.loads((issuer/'green_fit.json').read_text())
curve=TreasuryCurve(cfg['month'],'gsw_svensson',cfg['curve_parameters']);afns=json.loads(Path(cfg['afns_config']).read_text());afns['epsF']=0.
settings=HWSettings(**run['settings']);spread=NSSpread(np.array(fit['parameters_bp'])/1e4);green=GreenIntegral(gf['z_bp']/1e4)
rows=[];checks=[]
for code in a.codes:
 base=load_cached_pricer(results/'cache'/f'{code}_{sig}.pkl');original=base.price(spread,None,return_samples=True)
 for scenario in ('literal_full_schedule_plus_accrued','exclude_before_discount','subtract_after_discount'):
  dest=out/code/scenario;dest.mkdir(parents=True,exist_ok=True)
  if scenario=='literal_full_schedule_plus_accrued':pricer=base
  else:
   terms=copy.deepcopy(data['terms'][code]);terms.accrued_treatment=scenario;terms.expansion_metadata['accrued_sensitivity_override']=scenario
   pricer=ExpandedAFNSPricer(terms,data['valuation'],curve,afns,settings=settings,h15=load_h15(cfg['h15']))
  row=price_one(code,data,pricer,curve,spread,green,dest);rows.append(dict(sensitivity_scenario=scenario,**row))
  new=pricer.price(spread,None,return_samples=True)
  checks.append(dict(code=code,scenario=scenario,actual_option_change_per100=new['option_value']-original['option_value'],paired_difference_se_per100=ase(new['_option_samples']-original['_option_samples']),same_treasury_paths=bool(np.array_equal(base.x,pricer.x)),same_notice_grid=bool(base.dates==pricer.dates),parameters_refitted=False))
  if pricer is not base:clear(pricer)
 clear(base)
pd.DataFrame(rows).to_csv(out/'accrued_convention_prices.csv',index=False)
save(out/'accrued_convention_summary.json',dict(checks=checks,conventional_parameters_bp=fit['parameters_bp'],common_green_state_bp=gf['z_bp'],scope='Fixed conventional and green curves, same Treasury paths, separately trained policies; tests contractual accrued interpretation, not its full effect through issuer recalibration. Literal convention remains the maintained scenario.'))
