"""Analytical green inversion conditional on the common-fit own option.

H_G(z*)=observed dirty price + own option valued at common fitted green state.
This is the paper's fixed-option adjustment inversion, not a callable-price
root that recursively changes the option policy at every z trial.
"""
import argparse,json
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.optimize import brentq
from run_expanded_batch import load_inputs,TreasuryCurve,NSSpread,GreenIntegral,ase
p=argparse.ArgumentParser();p.add_argument('--out',required=True);p.add_argument('--register');p.add_argument('--prices');a=p.parse_args()
out=Path(a.out);run=json.loads((out/'run_configuration.json').read_text())['arguments']
data=load_inputs(a.register or run['register'],a.prices or run['prices'],run['month'],holdout_codes=('92343VGK',))
curve=TreasuryCurve(run['month'],'gsw_svensson',run['curve_parameters'])
frames=[]
for f in sorted(out.glob('*/all_bond_prices.csv')):
 frame=pd.read_csv(f)
 for i,row in frame.iterrows():
  c=row['code'];terms=data['terms'][c];bond=data['bonds'][c]
  frame.loc[i,'contract_accrued_valuation_convention']=terms.accrued_treatment
  frame.loc[i,'literal_full_schedule_plus_accrued_scenario']=terms.expansion_metadata.get('literal_accrued_scenario',False)
  frame.loc[i,'explicit_noncallable_contract']=not terms.callable
  frame.loc[i,'security_group']=data['contracts'][c].get('security_group')
  frame.loc[i,'notice_policy_assumption']=terms.expansion_metadata['restricted_notice_action_policy']
  frame.loc[i,'weekly_month_count_basis']=terms.expansion_metadata['weekly_month_count_basis']
  raw_path=f.parent/f'{c}_raw_prices.json'
  if raw_path.exists():
   raw=json.loads(raw_path.read_text())
   for kernel,result in raw.items():
    if isinstance(result,dict):
     result['contract_scope']=terms.expansion_metadata
     result['continuation_history_max_known_fixing_dates']=row.get('continuation_history_lags',0)
   raw_path.write_text(json.dumps(raw,indent=2))
  frame.loc[i,'terminal_interest_per100']=float(terms.coupons[-1])
  frame.loc[i,'maximum_known_fixing_dates_in_continuation']=row.get('continuation_history_lags',0)
  frame.loc[i,'treasury_extrapolation_beyond_30_years']=row['maximum_treasury_horizon_used_years']>30.
  sample_path=f.parent/f'{c}_paired_samples.npz'
  if sample_path.exists():
   samples=np.load(sample_path);eps=1e-4;derivatives={}
   for kernel in ['brown','green']:
    price=float(row[f'{kernel}_callable_dirty_per100'])
    dpdy=(bond.yield_from_dirty(price+eps,data['valuation'])-bond.yield_from_dirty(price-eps,data['valuation']))/(2*eps)
    derivatives[kernel]=dpdy
    frame.loc[i,f'{kernel}_option_mc_se_yield_bp_at_fitted_price']=abs(dpdy)*float(row[f'{kernel}_option_mc_se_per100'])*1e4
   yield_samples=(-derivatives['brown']*samples['brown']+derivatives['green']*samples['green'])*1e4
   frame.loc[i,'same_contract_option_correction_paired_mc_se_yield_bp']=ase(yield_samples)
  sign=np.sign(float(row['green_state_bp']));delta=float(row['same_contract_green_minus_brown_option_per100']);se=float(row['same_contract_option_difference_paired_mc_se_per100'])
  frame.loc[i,'option_ordering_signed_difference_per100']=sign*delta
  frame.loc[i,'option_ordering_violation_conditional_zscore']=min(0.,sign*delta)/se if se>0 else (0. if sign*delta>=-1e-12 else -np.inf)
  if not bool(row['is_green']):continue
  c=row['code'];times,cf=data['bonds'][c].cashflows(data['valuation']);params=np.array([float(v) for v in str(row['credit_parameters_bp']).split(';')])/1e4
  spread=NSSpread(params);base=cf*curve.discount(times)*np.exp(-spread(times));loading=GreenIntegral(1.).__call__(times)
  target=float(row['observed_dirty_per100'])+float(row['actual_option_value_per100'])
  def price(zbp):return float(base@np.exp(loading*zbp/1e4))
  z=brentq(lambda z:price(z)-target,-5000.,5000.,xtol=1e-10)
  frame.loc[i,'fixed_option_implied_green_state_bp']=z
  frame.loc[i,'fixed_option_implied_endpoint_zero_greenium_bp']=float(GreenIntegral(z/1e4).zero(row['final_payment_horizon_years']))*1e4
  frame.loc[i,'fixed_option_implied_minus_common_state_bp']=z-float(row['green_state_bp'])
  frame.loc[i,'fixed_option_inversion_reconstruction_error_per100']=price(z)-target
  frame.loc[i,'fixed_option_inversion_target_straight_dirty_per100']=target
 frame.to_csv(f,index=False);frames.append(frame)
if not frames:raise ValueError('No completed issuer tables found')
allrows=pd.concat(frames,ignore_index=True);allrows.to_csv(out/'all_bond_prices.csv',index=False)
allrows.loc[allrows.is_green].to_csv(out/'green_fixed_option_inversions.csv',index=False)
print(json.dumps(dict(completed_contracts=len(allrows),green_inversions=int(allrows.is_green.sum()),max_abs_reconstruction_error=float(allrows.fixed_option_inversion_reconstruction_error_per100.abs().max()))))
