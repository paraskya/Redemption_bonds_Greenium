# Conditional AFNS++ corporate-bond expansion

This directory extends the completed 26-contract Verizon calculation to every supported issuer in the reviewed legal register. Original source modules under `tmp/paper_pricing/engine` are read-only. Preparation caches contain Treasury paths and contractual redemption commitments, never observed bond prices.

## Baseline

The Treasury state has the saved three-factor AFNS covariance and Q decay. A deterministic initial-curve shift exactly matches the supplied GSW/Svensson discount curve. Issuer and green factors have zero diffusion. The credit level has zero Q drift (`epsF=0`); the deterministic NS slope/curvature decay is 0.3 per year. The separate issuer delta is normalized to zero. Conventional fitting uses one coefficient for one conventional observation, two for two observations and three otherwise. The three-coefficient forward spread is checked for global nonnegativity. Green quotes estimate one signed current state per issuer/date, with green decay 0.1 and long-run mean zero fixed.

Conventional quotes alone fit credit. Each trial reprices each fitted contract's own option. GK (92343VGK) remains excluded from the Verizon fit. Green quotes then fit the common green state, with the green option repriced at every trial. Policy training and evaluation samples are disjoint and antithetic. Reported simulation errors condition on all fitted parameters, fixed contract interpretation and the trained policy.

## Contract adaptation

`expansion_data.py` reads the normalized legal register and dated observations. It checks accrued interest against the previously constructed cash-flow file. It retains each contract's separate make-whole cash-flow endpoint and Treasury comparable-security horizon. Unsupported or genuinely unresolved conventions are logged, never filled from another issuer.

`expanded_pricer.py` inherits exact Gaussian AFNS transitions and the numerical notice/policy machinery. It adds the following contract variants.

* Legacy H.15 weekly, with the existing three-month tenor tolerance and nearest-tenor convention.
* Equinix H.15 preceding-full-week fixings three business days before notice, with always-bracketing interpolation and two-decimal rounding in percentage points.
* Boston Properties H.15 week-ending fixings before notice, with remaining maturity rounded upward to a month before interpolation.
* Daily H.15 fixing after the publication cutoff on the fixing day; nonpublication holidays roll backward. The rate and redemption amount have three-decimal contractual rounding, and accrued interest is subtracted after discounting.
* Dealer/comparable-Treasury and composite-price families represented by a **declared model par-yield proxy** of the contract's remaining Treasury horizon. Actual dealer quotations are not supplied.
* Explicitly noncallable contracts with no exercise actions and an exactly zero own option.
* A separately named `literal_full_schedule_plus_accrued` scenario for older wording that states the full remaining payment PV followed by an accrued addition without an express modern deduction clause. This scenario is never represented as a verified accrued-exclusion rule.

The full legal calendar is approximated by the US federal-holiday calendar with following payments. Contract-specific private, state and trustee closures remain a declared limitation. Where the maximum notice is unverified, the maintained action set requires exactly the verified minimum calendar-day lag. A candidate is skipped if its business-day adjustment cannot preserve that exact lag. This is a restricted policy, not full minimum-notice optimization. A separate DTE trustee-notice requirement is modeled conditional on trustee consent to shorten it. Conditional or revocable notices are represented by funded irrevocable policies; further conditionality rights are not valued.

At each notice node, continuation regressions include the current Treasury factors **and every already observed stochastic fixing date that can affect a current or later available action**. Dates are deterministic by node; path values are retained without future information. This corrects compression of relevant historical fixings into current state/moneyness alone. Regression remains an approximation to the conditional continuation function.

## Commands

From the workspace root:

```bash
python tmp/expansion/pricing/run_expanded_batch.py --workers 3 --out tmp/expansion/pricing/results
python tmp/expansion/pricing/append_exact_inversions.py --out tmp/expansion/pricing/results
```

The defaults are 768 policy-training paths, 2,304 independent evaluation paths, 32 fixing draws, 30-calendar-day regular notice spacing, and legally admissible event-adjacent notice dates. These match the previous refined settings; the richer history basis is identified separately in the output.

The driver supports `--stage prepare`, `--stage fit`, `--issuer`, `--codes`, monthly labels and alternative reviewed input paths. `fit_prepared_issuer.py` allows an issuer's fit to begin while longer contracts prepare. It writes only that issuer's outputs. `run_expanded_batch.py` resumes complete caches and completed issuer results within the same unchanged run configuration.

## Outputs and estimands

Each issuer has conventional/green fit diagnostics, all actual and same-contract counterfactual prices, independent paired option samples, a zero-curve table and a summary. The global tables combine completed issuers.

The price decomposition is Treasury straight value, less issuer spread discount cost, plus green straight-price benefit where applicable, less that actual contract's own option. Same-contract green premiums separately report the straight premium and green-minus-conventional option difference. Exact yield inversion on the common contract supplies the coupon-yield greenium; its difference from the zero greenium is divided into compounding, coupon/schedule-and-curve, and redemption terms.

`append_exact_inversions.py` additionally solves the closed-form straight-price equation at observed dirty price plus the option evaluated at the **common fitted state**. It reports the individual implied green state, endpoint zero-coupon greenium, deviation from the common state and reconstruction error. It does not claim a recursively repriced callable root or statistical identification of the fixed curve shape.

A legal-register expansion and a literal-contract scenario are separate result branches. Do not merge their fitted states or report the original 88-contract branch as though newly added conventional anchors had been included. Cache reuse between branches requires matching old contractual payoff conventions, Treasury inputs and numerical settings; newly added or changed contracts must be prepared separately.


## Completed August 2026 release

The updated conditional branch contains **98 contracts:32 green and66 conventional across8 legal issuers**, including one conventional Verizon holdout. All65 conventional calibration quotes are valued inside their issuer fits. The frozen original-register branch contains88 contracts; the two old MidAmerican literal-clause scenarios and eight newly verified conventional anchors enter only the expanded branch. A separately documented Boston calendar-month correction applies consistently to both branches, with earlier numerical outputs preserved in an archive.

The eight new anchors are NSP BQ/CA/CB, MidAmerican AB/AE/AH and DTE EA/EB. NSP BQ is explicitly noncallable. MidAmerican AH has source-verified February/August coupons followed by the October maturity stub; its final interest is **0.9666666666666667 per100**, checked against the complete source-derived schedule. DTE EA/EB retain their secured-note wrapper and collateral-release qualifications.

The complete expanded command is:

```bash
python tmp/expansion/pricing/run_expanded_scenario.py \
  --base-results tmp/expansion/pricing/results \
  --register tmp/expansion/pricing/scenario_inputs/normalized_contracts_expanded_literal.json \
  --prices tmp/expansion/benchmarks/inputs/bond_month_values_final.csv \
  --out tmp/expansion/pricing/results_expanded
```

The fitting objective is average squared price error divided by observed DV01 squared. Its square root is a local yield-equivalent price RMSE; the all-bond tables additionally report exact nominal yield residuals. SLSQP works in long-forward level, short-forward level and curvature coordinates, with0.1bp finite differences and1e-4bp² objective tolerance. All eight final conventional fits report successful termination. MidAmerican's first run reached its iteration cap; `warm_restart_MidAmerican/` records a successful restart from that incumbent on exactly the same paths. The initial failed-status results remain under `archived_MidAmerican_before_warm_restart/`. Successful termination does not establish a global minimum or parameter identification.

`warm_restart_issuer.py` can reproduce a warm restart without overwriting the incumbent:

```bash
python tmp/expansion/pricing/warm_restart_issuer.py \
  --results tmp/expansion/pricing/results_expanded \
  --issuer 'MidAmerican Energy Company' \
  --out tmp/expansion/pricing/warm_restart_MidAmerican
```

`refine_selected_contract.py` performs the targeted fixed-parameter refinement with1536 training paths,4608 evaluation paths,15-day notice spacing and64 fixing draws. `green_state_sensitivity.py` instead uses the original paths, inverts observed price plus the common-state option analytically, and reprices once at that individual state. `accrued_convention_sensitivity.py` compares literal full-schedule, exclusion-before-discount and subtraction-after-discount cases on identical Treasury paths, holding fitted curves fixed. These diagnostics are separate from the maintained issuer estimate.

```bash
python tmp/expansion/pricing/refine_selected_contract.py --results tmp/expansion/pricing/results_expanded --issuer-dir MidAmerican_Energy_Company --code 595620AT --out tmp/expansion/pricing/refinement_595620AT
python tmp/expansion/pricing/green_state_sensitivity.py --results tmp/expansion/pricing/results_expanded --issuer-dir MidAmerican_Energy_Company --code 595620AT --out tmp/expansion/pricing/refinement_595620AT
python tmp/expansion/pricing/accrued_convention_sensitivity.py --results tmp/expansion/pricing/results_expanded --issuer-dir MidAmerican_Energy_Company --codes 595620AL 595620AN --out tmp/expansion/pricing/accrued_sensitivity_AL_AN
```

Large preparation groups are automatically converted to read-only NumPy memory maps before joint loading when serialized size exceeds2GB. This changes array storage only. Portable replication excludes generated caches and recreates them; internal absolute memory-map paths must not be copied as portable inputs. Three preparation workers are the default. A staged prepare-then-fit run avoids overlapping large issuer fits with preparation workers.

Preparation caches are keyed by Treasury inputs, numerical settings and adapter hashes. The archived base signature is921db4d4f8527232 and the archived expansion signature is72a3ba2d9374c87d. Later additions preserved old payoff formulas; branch reuse and the Boston-only correction are recorded in explicit manifests. A fresh run with the final scripts obtains fresh content-derived signatures. It must not silently treat a changed contract or numerical setting as the same prepared cache.

Neither the monthly pre-option sample nor these98 current callable valuations estimates a dynamic filtered green state. Zero-coupon curve shape remains conditional on fixed decay and long-run mean. Dealer quote proxies, calendar approximations, funded irrevocable notice, legacy accrued wording and security-wrapper assumptions remain contract-level flags. Treasury maturities beyond30 years are explicitly flagged as extrapolation. Conditional Monte Carlo errors exclude policy approximation, grid error, parameter error, quote uncertainty and those contractual assumptions.
