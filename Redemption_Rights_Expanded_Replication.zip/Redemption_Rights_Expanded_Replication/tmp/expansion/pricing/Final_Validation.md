# Final validation of the expanded conditional valuation

The frozen August 2026 release contains **98 contracts across eight legal issuers: 32 green and 66 conventional**. The conventional curve fits use 65 quotes; Verizon GK remains a held-out conventional bond. Every contract has its actual callable price, Treasury straight value, issuer discount component and same-contract green/conventional counterfactuals. All 32 green observations have the separate fixed-option analytical inversion.

## Numerical completion

All eight conventional fits and all eight common-green-state fits report successful termination. MidAmerican required a warm restart from its earlier iteration-capped incumbent. At the maintained objective tolerance of 1e-4 bp², that restart terminates successfully in one iteration and 18 objective evaluations; the conventional weighted price RMSE changes from 2.656243 to 2.656161 bp. The initial failed-status result is preserved. Solver success does not establish a global optimum or statistical parameter identification.

The final price and yield component identities have zero displayed reconstruction error. The largest absolute analytical fixed-option inversion error is 9.5213e-13 per 100. NSP BQ has an exactly zero own option, consistent with explicit noncallability. MidAmerican AH's independently verified final short coupon is 0.9666666666666667 per 100; the supplied source-derived cash-flow schedule matches the engine exactly.

## Material green option: MidAmerican AT

| Diagnostic | Result |
|---|---:|
| Maintained issuer common green state | 60.67057095 bp |
| Maintained AT own option | 0.11815254 per 100 |
| Maintained same-contract redemption correction | -3.53108175 bp |
| AT exact yield residual at common fit | -19.63818574 bp |
| Refined correction: 1,536 training / 4,608 evaluation paths, 15-day notice grid, 64 fixing draws | -3.48398802 bp |
| Refinement change | +0.04709373 bp |
| Individual fixed-option implied green state | 38.92103062 bp |
| Own option after one repricing at that individual state | 0.05998056 per 100 |
| Same-contract correction after that repricing | -1.14003856 bp |
| Yield residual after that repricing | -2.42002541 bp |

The refinement holds fitted parameters fixed and uses an independent random seed. It measures numerical sensitivity, not a global stopping-error bound. The state sensitivity instead holds the conventional curve and original paths fixed. It first solves the analytical straight-price equation at observed dirty price plus the common-state option, then reprices the option exactly once at that implied state. It does not recursively solve a callable-price root and does not estimate a second panel state. The material change across those states shows that the economic magnitude depends much more on the common-state fit than on this path/grid refinement.

## Contract corrections and sensitivities

Boston's upward-to-month Treasury interpolation now uses the smallest integer number of calendar months reaching the reference date, with the schedule's month-end clamp. The earlier ACT/365.25-times-12 approximation incorrectly mapped some exact calendar months upward. All seven Boston contracts were reprepared and refitted, consistently in the 88- and 98-contract branches. Earlier outputs are preserved. The correction changes the largest actual option by 0.0000245298 per 100 and the largest observed-green redemption correction by 0.00101735 bp.

The 11 callable NSP contracts with an unverified legal maximum notice retain a restricted policy requiring exactly the verified minimum 30 calendar days. Candidates whose business-day adjustment cannot preserve that exact lag are skipped. The calculation does not claim full minimum-notice optimization or a complete legal notice action set.

Seven contracts use the explicit literal full-schedule-plus-accrued scenario. For the two previously ambiguous MidAmerican contracts AL and AN, same-path fixed-curve comparisons against exclusion-before-discount and subtraction-after-discount produce exactly zero change in the actual conventional own option. This tests the payoff convention at the fitted curves; it does not claim its recalibrated effect is universally zero.

## Limits retained in the release

Only 15 of 32 current green bonds lie within the fitted conventional maturity envelope. Fifteen priced contracts use Treasury horizons beyond 30 years, with a maximum of 43.7714 years. These are flagged as extrapolation. All MidAmerican green maturities remain outside its conventional envelope, and its common-green fit has approximately 20.33 bp exact-yield RMSE. Those facts prevent the AT correction from being represented as a precisely identified market greenium adjustment.

Separate least-squares policies do not mechanically enforce the deterministic model's signed option ordering. The largest sampled reversal is conventional NSP CQ: green-minus-conventional option -0.009382 per 100 with paired evaluation standard error 0.004172; for observed green NSP CU the corresponding values are -0.004536 and 0.002439. These evaluation errors exclude continuation-policy approximation. The results retain the reversals and do not claim pathwise numerical dominance.

Price inputs remain P_PRICE interpreted as clean, supported by the prior coupon-reset analysis but without complete provider field metadata. Dealer/comparable-Treasury quotations are modeled by the declared continuous par-yield proxy. Federal-holiday calendars, funded irrevocable notice, trustee shortening consent, collateral-wrapper scope and legacy accrued conventions remain explicit conditional assumptions. Credit and green diffusion are zero, and the green decay and long-run mean are fixed. The monthly pre-option panel and current callable cross-section do not constitute a dynamically filtered structural panel estimate.

## Evidence files

- `results_expanded/all_bond_prices.csv`: all 98 final prices and component/diagnostic columns.
- `results_expanded/green_fixed_option_inversions.csv`: all 32 exact conditional inversions.
- `final_validation_summary.json`: numerical completion and scope counts.
- `refinement_595620AT/refinement_summary.json`: independent path/grid refinement.
- `refinement_595620AT/green_state_sensitivity.json`: fixed-curve individual-state sensitivity.
- `accrued_sensitivity_AL_AN/accrued_convention_summary.json`: same-path accrued-convention comparisons.
- `warm_restart_MidAmerican/warm_restart_comparison.json`: convergence and magnitude comparison.
- `results_expanded/Boston_calendar_ceiling_correction.json`: corrected-contract scope and preparation records.
- `README.md`: specification, commands, cache and replication conventions.
