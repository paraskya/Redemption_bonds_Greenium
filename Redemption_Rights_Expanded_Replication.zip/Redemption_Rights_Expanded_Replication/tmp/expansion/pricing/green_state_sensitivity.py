"""One repricing at the individual fixed-option implied green state."""
import argparse,json
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.optimize import brentq
from run_expanded_batch import load_inputs,NSSpread,GreenIntegral,ase,save
from cache_io import load_cached_pricer
p=argparse.ArgumentParser();p.add_argument('--results',required=True);p.add_argument('--issuer-dir',required=True);p.add_argument('--code',required=True);p.add_argument('--out',required=True);a=p.parse_args()
root=Path(a.results);out=Path(a.out);out.mkdir(parents=True,exist_ok=True);run=json.loads((root/'run_configuration.json').read_text());cfg=run['arguments'];folder=root/a.issuer_dir
row=pd.read_csv(folder/'all_bond_prices.csv').set_index('code').loc[a.code];data=load_inputs(cfg['register'],cfg['prices'],cfg['month'],codes=[a.code]);bond=data['bonds'][a.code];valuation=data['valuation']
fit=json.loads((folder/'conventional_fit.json').read_text());sp=NSSpread(np.array(fit['parameters_bp'])/1e4)
pr=load_cached_pricer(root/'cache'/f'{a.code}_{run["cache_signature"]}.pkl');base=pr.cf_amounts*np.exp(pr.model.curve.log_discount(pr.cf_times)-sp(pr.cf_times));loading=GreenIntegral(1.)(pr.cf_times)
target=float(row.observed_dirty_per100)+float(row.actual_option_value_per100)
z=brentq(lambda z:float(base@np.exp(loading*z/1e4))-target,-5000.,5000.,xtol=1e-10)
r=pr.price(sp,GreenIntegral(z/1e4),return_samples=True);old_samples=np.load(folder/f'{a.code}_paired_samples.npz')
ycall=bond.yield_from_dirty(r['model_dirty'],valuation);ystraight=bond.yield_from_dirty(r['straight_dirty'],valuation)
correction=100*(float(row.brown_callable_yield_pct)-100*ycall-float(row.brown_straight_yield_pct)+100*ystraight)
summary=dict(code=a.code,common_green_state_bp=float(row.green_state_bp),individual_fixed_option_implied_state_bp=z,
    original_common_fit_yield_residual_bp=float(row.actual_yield_error_bp),common_green_option_per100=float(row.actual_option_value_per100),
    individual_state_green_option_per100=r['option_value'],green_option_state_sensitivity_per100=r['option_value']-float(row.actual_option_value_per100),
    common_same_contract_redemption_correction_bp=float(row.same_contract_option_correction_to_greenium_yield_bp),
    individual_state_same_contract_redemption_correction_bp=correction,
    changed_option_after_individual_state_yield_residual_bp=1e4*(ycall-float(row.observed_yield_pct)/100),
    fixed_option_straight_inversion_reconstruction_error_per100=float(base@np.exp(loading*z/1e4))-target,
    state_change_option_difference_paired_mc_se_per100=ase(r['_option_samples']-old_samples['green']),
    individual_state_green_minus_brown_option_paired_mc_se_per100=ase(r['_option_samples']-old_samples['brown']),
    conventional_curve_fixed=True,common_fit_option_used_in_analytical_inversion=True,
    green_option_repriced_once_after_inversion=True,recursive_callable_inversion=False,
    common_and_individual_pricing_use_same_paths=True,scope='Green-state sensitivity to common-fit residual on one observed bond; not a new estimated panel state.')
save(out/'green_state_sensitivity.json',summary);pd.DataFrame([summary]).to_csv(out/'green_state_sensitivity.csv',index=False);np.savez_compressed(out/'individual_state_option_samples.npz',individual_green=r['_option_samples']);print(json.dumps(summary),flush=True)
