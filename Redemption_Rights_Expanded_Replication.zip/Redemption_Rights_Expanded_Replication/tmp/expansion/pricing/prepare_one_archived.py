import sys,json
from pathlib import Path
from run_expanded_batch import load_inputs,HWSettings,prep_job
from cache_io import compact_cache
out=Path(sys.argv[1]);code=sys.argv[2];r=json.loads((out/'run_configuration.json').read_text());a=r['arguments']
p=out/'cache'/f'{code}_{r["cache_signature"]}.pkl'
if not p.exists():
 d=load_inputs(a['register'],a['prices'],a['month'],codes=[code]);cfg=json.loads(Path(a['afns_config']).read_text());cfg['epsF']=0.
 print(json.dumps(prep_job((code,d['terms'][code],d['valuation'],a['month'],a['curve_parameters'],cfg,HWSettings(**r['settings']),a['h15'],p))),flush=True)
print(json.dumps(compact_cache(p)),flush=True)
