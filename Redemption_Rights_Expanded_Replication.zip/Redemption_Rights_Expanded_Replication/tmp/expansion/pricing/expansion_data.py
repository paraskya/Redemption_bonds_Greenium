"""Read-only legal-register and observed-price adapter for the expansion."""
from __future__ import annotations
from pathlib import Path
import json, hashlib
import numpy as np
import pandas as pd
from scipy.optimize import brentq
from expanded_pricer import BondTerms, as_date, years


def pick(row,*keys):
    for key in keys:
        value=row.get(key)
        if value is not None and value!='':return value
    return None


def sha256(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def adapt_contract(row,valuation):
    code=row['source_code'];fix=row.get('treasury_fixing') or {};notice=row.get('notice') or {}
    noncallable=row.get('callable') is False
    literal=row.get('valuation_accrued_scenario')=='literal_full_schedule_plus_accrued'
    if row.get('currency')!='USD' or int(pick(row,'frequency','coupon_frequency_per_year') or 0)!=2:
        raise ValueError('Unsupported currency/frequency')
    if not str(row.get('day_count','')).lower().startswith(('30/360','30 / 360','360')):
        raise ValueError('US30/360 coupon basis not established')
    family=pick(row,'benchmark_family') or fix.get('benchmark_family')
    if family in ('FRBNY_composite_Treasury_security_prices',) and not literal:
        raise ValueError('Original FRBNY-composite contract accrued exclusion unresolved; not priced')
    weekly=family in ('US_Treasury_H15_preceding_week_average','US_Treasury_H15_preceding_full_week_average','US_Treasury_H15_week_ending_mean')
    daily=family=='US_Treasury_H15_daily_CMT'
    dealer=family in ('US_Treasury_dealer_comparable_security','US_Treasury_dealer_price_implied_yield','US_Treasury_Reuters_bid_dealer_fallback') or (literal and family in ('FRBNY_composite_Treasury_security_prices','US_Treasury_comparable_security_NYFed_composite_prices_or_dealer'))
    if not (weekly or daily or dealer or noncallable):raise ValueError(f'Unsupported benchmark family {family}')
    lo=pick(row,'notice_min_days')
    if lo is None:lo=notice.get('min_days')
    hi=pick(row,'notice_max_days')
    if hi is None:hi=notice.get('max_days')
    if noncallable:lo=hi=0
    if lo is None:raise ValueError('Minimum holder notice missing')
    unknown_max=hi is None
    if unknown_max:hi=lo # restricted exact-minimum-calendar-day policy; no legal cap inferred
    lag=pick(row,'fixing_business_days_before')
    if lag is None:lag=pick(fix,'fixing_business_days_before','fixing_business_days_before_redemption')
    if noncallable:lag=0
    if lag is None:raise ValueError('Fixing lag missing')
    mw=row.get('mw_cashflow_end_date')
    ref=pick(row,'treasury_comparable_horizon_date') or pick(fix,'comparable_security_horizon_date','comparator_maturity_target','remaining_life_horizon')
    if noncallable:mw=ref=row['maturity_date']
    if not mw or not ref:raise ValueError('Separate MW cashflow and Treasury benchmark horizons required')
    spread=pick(row,'mw_spread_bp')
    if spread is None:
        spread=next((w.get('spread_bp') for w in row.get('call_windows',[]) if w.get('spread_bp') is not None),None)
    if noncallable:spread=0.
    if spread is None:raise ValueError('Make-whole spread missing')
    accrual_text=str(row.get('mw_accrued_interest_treatment') or ' '.join(str(w.get('accrued_interest_treatment','')) for w in row.get('call_windows',[]))).lower()
    accrued='subtract_after_discount' if daily else 'exclude_before_discount'
    if not daily and not noncallable and not literal and not ('exclude' in accrual_text or 'excluded' in accrual_text):
        raise ValueError('Accrued exclusion convention not established')
    interp='legacy_three_month_tolerance'
    if family=='US_Treasury_H15_week_ending_mean':interp='always_bracket_ceiling_month'
    if family=='US_Treasury_H15_preceding_full_week_average':interp='always_bracket_nearest_month'
    rounding=3 if daily else 2 if family=='US_Treasury_H15_preceding_full_week_average' else None
    flags=list(row.get('implementation_flags') or [])
    flags.extend(['US federal-holiday following calendar approximation; contractual local/state/trustee closures not exhaustively resolved.',
                  'Original issued terms; no outstanding notice, partial redemption or subsequent amendment is asserted.'])
    if dealer:flags.append('Dealer/Reuters comparable Treasury yield represented by conditional model par yield over contractual remaining horizon; no dealer quote data supplied.')
    if unknown_max:flags.append('Only exactly the verified minimum calendar-day notice lag is valued; candidates whose business-day adjustment cannot preserve that exact lag are skipped. The legal maximum is unverified; full minimum-notice or full notice-right optimization is not claimed.')
    if notice.get('trustee_advance_notice_days'):
        flags.append('Trustee consent to shorten its separate advance-notice requirement is assumed in the modeled holder-notice policy.')
    if notice.get('conditional_notice'):
        flags.append('Funded irrevocable notice policy is valued; contractual cancellation/conditionality optionality is not included.')
    metadata=dict(code=code,legal_issuer=row.get('legal_issuer_name') or row['issuer'],
        benchmark_family='none_noncallable' if noncallable else family,benchmark_class='none' if noncallable else 'dealer' if dealer else 'daily_h15' if daily else 'weekly_h15',
        fixing_relative_to=fix.get('fixing_relative_to') or 'redemption_date',
        weekly_interpolation=interp,notice_max_unverified=unknown_max,
        legal_notice_max_days=None if unknown_max else int(hi),
        full_notice_action_set_verified=not unknown_max,
        restricted_notice_action_policy='exact_minimum_calendar_days_nonbusiness_infeasible_skipped' if unknown_max else 'reported_finite_lag_grid',
        weekly_month_count_basis='calendar_month_ceiling' if interp=='always_bracket_ceiling_month' else 'existing_contract_family_convention',
        redemption_conditionality_included=False,treasury_dealer_proxy=dealer,
        trustee_shortening_consent_assumed=bool(notice.get('trustee_advance_notice_days')),
        payment_calendar='US federal-holiday following approximation',noncallable=noncallable,literal_accrued_scenario=literal,assumptions=flags)
    first_amount=pick(row,'first_coupon_amount_per100','first_coupon_amount')
    if as_date(valuation)<as_date(row['first_coupon_date']) and first_amount is None and not row.get('regular_first_coupon_supported'):
        raise ValueError('Unverified first stub still outstanding')
    terms=BondTerms(name=f"{metadata['legal_issuer']} {row['coupon_pct']}% {row['maturity_date']}",
        isin=row.get('isin') or code,coupon=float(row['coupon_pct'])/100,maturity=row['maturity_date'],
        interest_start=row.get('interest_accrual_start_date') or row['issue_date'],first_coupon=row['first_coupon_date'],
        par_call_date=row.get('par_call_date') or row['maturity_date'],mw_spread_bp=float(spread),
        notice_min_days=int(lo),notice_max_days=int(hi),fixing_lag_business_days=int(lag),
        callable=not noncallable,accrued_treatment=accrued,security='green' if row.get('green',row.get('verified_is_green',False)) else 'conventional',
        mw_reference_date=mw,benchmark_reference_date=ref,call_start_date=row.get('economic_issue_date') or row['issue_date'],
        benchmark_method='h15_weekly_2017' if weekly else 'h15_daily_2023' if daily else 'dealer_spot_par_proxy',
        h15_publication_lag_business_days=0 if daily else 1,
        treasury_rate_round_decimals=rounding,redemption_price_round_decimals=3 if daily else None,
        first_coupon_amount=None if first_amount is None else float(first_amount),
        sources=tuple(sorted({s['url'] for s in row.get('source_refs',[]) if s.get('url')}|{row['source_url']} if row.get('source_url') else {s['url'] for s in row.get('source_refs',[]) if s.get('url')})),
        assumptions=tuple(flags))
    if literal:
        terms.accrued_treatment='literal_full_schedule_plus_accrued'
        metadata['assumptions'].append('Named literal-contract scenario: full remaining scheduled coupons discounted without accrued deduction, then accrued added after par floor; no modern exclusion convention inferred.')
    verified=row.get('verified_contractual_cashflows')
    if verified:
        vd=[as_date(v.get('contractual_date') or v.get('unadjusted_date')) for v in verified]
        vc=np.array([v.get('cashflow_per100') for v in verified],float)
        if tuple(vd)!=terms.contract_dates or len(vc)!=len(terms.cashflows) or np.max(np.abs(vc-terms.cashflows))>1e-10:
            raise ValueError('Source-verified contractual schedule does not match pricer cashflows')
        metadata['verified_cashflow_max_error_per100']=float(np.max(np.abs(vc-terms.cashflows)))
        metadata['verified_terminal_interest_per100']=float(terms.coupons[-1])
    terms.expansion_metadata=metadata
    return terms


class TermsCashflowBond:
    """Yield conversion from the exact cashflow schedule passed to the pricer."""
    def __init__(self,terms):self.terms=terms;self.frequency=terms.frequency
    def accrued(self,valuation):return self.terms.accrued(valuation)
    def cashflows(self,valuation,adjusted=True):
        val=as_date(valuation);dates=self.terms.payment_dates if adjusted else self.terms.contract_dates
        mask=np.array([d>val for d in dates]);t=np.array([years(val,d) for d in dates if d>val])
        return t,self.terms.cashflows[mask]
    def price_from_yield(self,y,valuation,adjusted=True):
        t,cf=self.cashflows(valuation,adjusted)
        return float(np.sum(cf*(1+y/self.frequency)**(-self.frequency*t)))
    def yield_from_dirty(self,dirty,valuation,adjusted=True):
        return float(brentq(lambda y:self.price_from_yield(y,valuation,adjusted)-dirty,-.5,2.,xtol=1e-13))


def load_inputs(register_path,monthly_path,month,issuer=None,codes=None,holdout_codes=()):
    raw=json.loads(Path(register_path).read_text());rows=raw.get('contracts',raw)
    register={r['source_code']:r for r in rows}
    prices=pd.read_csv(monthly_path);label='month_label' if 'month_label' in prices else 'Date'
    current=prices.loc[prices[label].eq(month)].copy()
    if issuer:current=current.loc[current.Code.map(lambda c:(register.get(c,{}).get('legal_issuer_name') or register.get(c,{}).get('issuer'))==issuer)]
    if codes:current=current.loc[current.Code.isin(codes)]
    if current.Code.duplicated().any():raise ValueError('Duplicate issuer/date price observations')
    valuations=current.valuation_date.unique() if 'valuation_date' in current else [month]
    if len(valuations)!=1:raise ValueError('Exactly one aligned valuation date required')
    valuation=as_date(str(valuations[0]));observations=[];terms={};bonds={};exclusions=[];contracts={}
    for ob in current.to_dict('records'):
        code=ob['Code'];row=register.get(code)
        if row is None:exclusions.append(dict(code=code,reason='Absent legal contract'));continue
        try:
            if not row.get('eligible_as_verified_green',False) and not row.get('eligible_as_verified_conventional',False):raise ValueError('Verified class or same legal issuer eligibility missing')
            if as_date(row['maturity_date'])<=valuation:raise ValueError('Matured by valuation')
            t=adapt_contract(row,valuation);bond=TermsCashflowBond(t)
            clean=float(ob['P_PRICE']);ai=bond.accrued(valuation);dirty=clean+ai
            if not np.isfinite(clean) or clean<=0:raise ValueError('Nonpositive or invalid observed price')
            y=bond.yield_from_dirty(dirty,valuation);dv01=(bond.price_from_yield(y-.0001,valuation)-bond.price_from_yield(y+.0001,valuation))/2
            times,cf=bond.cashflows(valuation);old_ai=ob.get('accrued_per100')
            if old_ai is not None and abs(float(old_ai)-ai)>1e-8:raise ValueError(f'Accrued crosscheck mismatch {ai} vs {old_ai}')
            green=bool(row.get('eligible_as_verified_green'))
            split='green' if green else 'conventional_holdout' if code in holdout_codes else 'conventional_fit'
            observations.append(dict(code=code,issuer=t.expansion_metadata['legal_issuer'],split=split,is_green=green,
                valuation_date=str(valuation),month_label=month,coupon_pct=row['coupon_pct'],maturity_date=row['maturity_date'],
                observed_clean_per100=clean,accrued_per100=ai,observed_dirty_per100=dirty,observed_yield_pct=100*y,
                dv01_per100=dv01,final_payment_horizon_years=float(times[-1]),make_whole_spread_bp=t.mw_spread_bp,
                par_call_date=str(t.par_call_date),notice_min_days=t.notice_min_days,
                notice_max_days=None if t.expansion_metadata['notice_max_unverified'] else t.notice_max_days,
                benchmark_family=t.expansion_metadata['benchmark_family'],fixing_relative_to=t.expansion_metadata['fixing_relative_to'],
                restricted_minimum_notice_policy=t.expansion_metadata['notice_max_unverified'],dealer_par_proxy=t.expansion_metadata['treasury_dealer_proxy'],
                price_basis='P_PRICE assumed clean; coupon-reset support, provider metadata incomplete',
                yield_convention='nominal_semiannual_adjusted_payment_dates_ACT365.25'))
            terms[code]=t;bonds[code]=bond;contracts[code]=row
        except (ValueError,KeyError,TypeError) as exc:exclusions.append(dict(code=code,issuer=row.get('issuer'),reason=str(exc)))
    frame=pd.DataFrame(observations)
    if frame.empty:raise ValueError(f'No supported observations: {exclusions}')
    return dict(observations=frame,terms=terms,bonds=bonds,contracts=contracts,valuation=valuation,
        fitting_codes=frame.loc[frame.split.eq('conventional_fit'),'code'].tolist(),
        green_codes=frame.loc[frame.split.eq('green'),'code'].tolist(),
        holdout_codes=frame.loc[frame.split.eq('conventional_holdout'),'code'].tolist(),exclusions=exclusions,
        source_hashes={str(register_path):sha256(register_path),str(monthly_path):sha256(monthly_path)})
