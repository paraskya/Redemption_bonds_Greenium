"""Resume an archived run with its exact cache identity and bounded memory."""
import json,subprocess,sys
from pathlib import Path
from run_expanded_batch import load_inputs,HWSettings,prep_job,slug
out=Path(sys.argv[1]);record=json.loads((out/'run_configuration.json').read_text());a=record['arguments'];sig=record['cache_signature']
d=load_inputs(a['register'],a['prices'],a['month'],holdout_codes=('92343VGK',));settings=HWSettings(**record['settings']);config=json.loads(Path(a['afns_config']).read_text());config['epsF']=0.
for c in d['observations'].sort_values('final_payment_horizon_years').code:
 cache=out/'cache'/f'{c}_{sig}.pkl'
 if not cache.exists():
  result=prep_job((c,d['terms'][c],d['valuation'],a['month'],a['curve_parameters'],config,settings,a['h15'],cache));print(json.dumps(dict(stage='prepared_after_memory_resume',**result)),flush=True)
for issuer in d['observations'].groupby('issuer').size().sort_values().index:
 if (out/slug(issuer)/'summary.json').exists():continue
 print(json.dumps(dict(stage='start_issuer',issuer=issuer)),flush=True)
 subprocess.run([sys.executable,str(Path(__file__).parent/'fit_prepared_issuer.py'),'--out',str(out),'--issuer',issuer],check=True)
subprocess.run([sys.executable,str(Path(__file__).parent/'append_exact_inversions.py'),'--out',str(out)],check=True)
