# Conventional bonds to extend maturity support

The ranking uses positive prices on 31 August 2026 in the complete saved universe and rewards points that anchor green maturities or divide large conventional maturity gaps. Source flags and matching provider names are candidate clues. Issue-specific legal identity, security rank and redemption terms must be verified before pricing. No parent-company grouping is used and no candidate has been added to the frozen 90-contract sample.

## MidAmerican Energy Company

| Rank | Code | Coupon | Maturity | August price | Purpose |
| --- | --- | --- | --- | --- | --- |
| 1 | 595620AB | 6.75% | 2031-12-30 | 107.925 | Extends short conventional maturity support from September2043 to December2031; reduces but does not eliminate extrapolation for2027/2029 green bonds. Verify same secured mortgage rank; old senior debt may differ. |
| 2 | 595620AE | 5.75% | 2035-11-01 | 102.763 | Adds November2035 point below present conventional range; verify same mortgage collateral/ranking as current green bonds. |
| 3 | 59562EAH | 5.8% | 2036-10-15 | 103.159 | Adds October2036 point below present range; different CUSIP family requires explicit issuer and security-group verification. |

## Northern States Power Company (Minnesota)

| Rank | Code | Coupon | Maturity | August price | Purpose |
| --- | --- | --- | --- | --- | --- |
| 1 | 665772BQ | 6.5% | 2028-03-01 | 102.057 | Extends short maturity support from May2044 to March2028; makes greenCT April2031 an interpolated maturity. Pre2000 issue requires exact current-obligor continuity and mortgage rank. |
| 2 | 665772CA | 5.25% | 2035-07-15 | 98.200 | Adds2035 interior/shorter curve anchor; Minnesota prefix family diagnostic, awaiting issue-specific legal identity and mortgage terms. |
| 3 | 665772CB | 6.25% | 2036-06-01 | 105.486 | Adds2036 short-side anchor and above-par high-coupon contract; verify own redemption terms. |
| 4 | 665772CC | 6.2% | 2037-07-01 | 105.396 | Adds2037 short-side anchor and above-par high-coupon contract; verify own redemption terms. |
| 5 | 665772CE | 5.35% | 2039-11-01 | 97.273 | Adds2039 point below original2044–2047 conventional range. |

## DTE Electric Company

| Rank | Code | Coupon | Maturity | August price | Purpose |
| --- | --- | --- | --- | --- | --- |
| 1 | 250847EA | 5.7% | 2037-10-01 | 100.398 | October2037 most nearly divides existing2032–2043 maturity gap; verify Detroit Edison predecessor legal continuity and mortgage collateral. |
| 2 | 250847EB | 6.625% | 2036-06-01 | 108.338 | June2036 point helps curvature and adds high-coupon above-par option case; verify predecessor and mortgage terms. |
| 3 | 250847DY | 5.45% | 2035-02-15 | 97.271 | February2035 intermediate point; shares coupon,maturity and raw latest price with DZ and saved economic-alias signature. Prefer original issue until fungibility resolved. |
| 4 | 250847DU | 6.35% | 2032-10-15 | 106.132 | October2032 point modestly extends dense shorter cluster; high coupon supplies a distinct redemption exposure. |
| 5 | 250847EH | 4.5% | 2041-09-01 | 83.500 | September2041 fills part of intermediate maturity gap; verify own make-whole terms. |

## Public Service Company of Colorado

| Rank | Code | Coupon | Maturity | August price | Purpose |
| --- | --- | --- | --- | --- | --- |
| 1 | 744448BZ | 6.25% | 2037-09-01 | 104.108 | September2037 approximately halves existing2032–2043 maturity gap; does not extend short/long envelope. |
| 2 | 744448CA | 6.5% | 2038-08-01 | 106.321 | August2038 intermediate anchor and above-par high-coupon contract. |
| 3 | 744448CE | 4.75% | 2041-08-15 | 88.847 | August2041 point improves intermediate spread-curve shape. |
| 4 | 744448CG | 3.6% | 2042-09-15 | 75.796 | September2042 lies close to existingMarch2043 point, lower incremental maturity value. |

## Boston Properties Limited Partnership

No additional August-positive conventional code exists in the frozen universe. Boston’s current three conventional bonds exhaust this saved scope; more maturity coverage requires acquiring additional issue identifiers and prices.

## Limits of these additions

MidAmerican has no saved unreviewed conventional maturity before 2031 or after 2036. Its short 2027/2029 and long 2047–2052 green bonds therefore remain outside the conventional maturity envelope even after all three candidate additions. AB substantially reduces the short extrapolation distance. The candidate debts may predate the mortgage series used by the green bonds, so their ranking and collateral need explicit confirmation.

For Northern States Power Minnesota, BQ can bracket the 2031 green bond together with the existing long conventional bonds, while four 2050–2052 green maturities remain beyond the latest conventional maturity 2047. The apparently attractive 2051 conventional code 665789BB belongs to the separately excluded Wisconsin-family map. Adding it would manufacture support by combining different issuers.

DTE’s and PSC Colorado’s candidates fill large intermediate maturity gaps but do not extend their maturity envelopes. DY and DZ share the same saved economic-alias signature, coupon, maturity and latest price and cannot be treated as independent information until their relationship is established.

No issue-specific source URL or full CUSIP was found in the inspected cached sources for these candidates. The CSV includes existing later-issue prospectus links solely as same-issuer research leads. Those links do not verify the candidate’s contract.

## Subsequent verification completed

After this ranked queue was prepared, all three MidAmerican candidates AB, AE and AH received primary-source review. Their verified normalized terms, complete dated cashflows and source evidence are in `../contracts/midamerican_new/`. The issuer's 2025 report confirms that these older senior notes became equally secured with first mortgage bonds in September 2013, which covers the entire saved monthly history. The earlier security-ranking question is therefore resolved for the 2016–2026 pricing window. AH has an expressly calculable final short coupon and must use the supplied schedule. The original queue files retain their before-verification snapshot; `followup_contract_verification_ledger.csv` records this extension.
