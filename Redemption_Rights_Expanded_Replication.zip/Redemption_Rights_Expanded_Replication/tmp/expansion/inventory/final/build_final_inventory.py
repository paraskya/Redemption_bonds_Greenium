from pathlib import Path
import json,hashlib
import numpy as np,pandas as pd
ROOT=Path(__file__).resolve().parents[4];P=ROOT/'tmp/expansion/inventory';OUT=P/'final'
paths={
 'frozen_inventory':P/'all_20106_source_codes_inventory.csv',
 'frozen_registry':ROOT/'restored/Zero_Coupon_Greenium_Data_and_Code/inventory/inputs/comparison/results/normalized_contracts.json',
 'frozen_summary':P/'expansion_inventory_summary.json',
 'final_registry':ROOT/'tmp/expansion/benchmarks/inputs/normalized_contracts_final.json',
 'final_bond_months':ROOT/'tmp/expansion/benchmarks/inputs/bond_month_values_final.csv'}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
hashes_before={k:sha(v) for k,v in paths.items()}
a=pd.read_csv(paths['frozen_inventory'],low_memory=False,dtype={'Code':str})
base=json.loads(paths['frozen_registry'].read_text())['contracts'];cs=json.loads(paths['final_registry'].read_text())['contracts'];v=pd.read_csv(paths['final_bond_months'],dtype={'Code':str})
code=lambda c:c.get('Code') or c.get('source_code') or c.get('issue_code')
basecodes={code(c) for c in base};current={code(c):c for c in cs};extra=sorted(set(current)-basecodes)
expected_extra={'595620AB','595620AE','59562EAH','665772BQ','665772CA','665772CB','250847EA','250847EB'}
assert set(extra)==expected_extra
assert len(current)==len(cs)==119 and len(a)==a.Code.nunique()==20106
assert set(current)<=set(a.Code)
latest=v.month_label.max();lv=v[v.month_label.eq(latest)].copy();assert len(lv)==lv.Code.nunique()==98
supported=set(v.Code);latestcodes=set(lv.Code)
assert len(supported)==114
initial_mechanical=set(a.loc[a.expansion_status.str.startswith('unreviewed_mechanical'),'Code']);initial_latest=set(a.loc[a.expansion_status.eq('unreviewed_mechanical_latest_candidate'),'Code'])
removed_history=initial_mechanical&set(extra);removed_latest=initial_latest&set(extra)
remaining_history=initial_mechanical-set(extra);remaining_latest=initial_latest-set(extra)
a['baseline_expansion_status']=a.expansion_status
a['new_contract_verification_this_extension']=a.Code.isin(extra)
a['registered_contract_version']='final119'
a['registered_contract_present']=a.Code.isin(current)
a['full_contract_and_quote_verification_complete']=False
for i,r in a.iterrows():
 if r.Code not in current:continue
 c=current[r.Code];g=bool(c.get('eligible_as_verified_green'));b=bool(c.get('eligible_as_verified_conventional'));conf=bool(c.get('classification_conflict'))
 a.at[i,'issuer']=c.get('legal_issuer_name') or c.get('issuer');a.at[i,'legal_issuer_key']=c.get('legal_issuer_key')
 a.at[i,'comparison_class']='verified_green' if g else ('verified_conventional' if b else ('classification_conflict' if conf else 'unclassified_incomplete'))
 a.at[i,'source_url']=c.get('source_url');a.at[i,'original_contract_reviewed']=True
 a.at[i,'eligible']=r.Code in supported;a.at[i,'conditional_cashflow_eligible']=r.Code in supported;a.at[i,'supported_at_latest']=r.Code in latestcodes
 if r.Code in latestcodes:a.at[i,'expansion_status']='supported_latest_conditional'
 elif r.Code in supported:a.at[i,'expansion_status']='supported_historical_only'
 elif conf:a.at[i,'expansion_status']='exclude_classification_conflict'
 else:a.at[i,'expansion_status']='reviewed_incomplete_or_unsupported'
a['still_unreviewed_mechanical_positive_history']=a.Code.isin(remaining_history)
a['still_unreviewed_mechanical_positive_latest']=a.Code.isin(remaining_latest)
a.to_csv(OUT/'all_20106_source_codes_inventory_final.csv',index=False)
a[a.Code.isin(remaining_history)].to_csv(OUT/'remaining_unreviewed_mechanical_candidates_final.csv',index=False)
a[a.Code.isin(remaining_latest)].to_csv(OUT/'remaining_unreviewed_mechanical_latest_candidates_final.csv',index=False)
# Final register ledger, preserving qualified original verification statuses.
vp=v.groupby('Code').agg(supported_months=('month_label','nunique'),first_supported_month=('month_label','min'),last_supported_month=('month_label','max'))
ledger=[]
for k,c in current.items():
 ir=v[v.Code.eq(k)];lr=lv[lv.Code.eq(k)]
 ledger.append(dict(code=k,legal_issuer=c.get('legal_issuer_name') or c.get('issuer'),legal_issuer_key=c.get('legal_issuer_key'),security_group=c.get('security_group'),currency=c.get('currency'),
  verified_green=bool(c.get('eligible_as_verified_green')),verified_conventional=bool(c.get('eligible_as_verified_conventional')),classification_conflict=bool(c.get('classification_conflict')),
  added_this_extension=k in extra,was_in_previous_mechanical_history_queue=k in initial_mechanical,was_in_previous_mechanical_latest_queue=k in initial_latest,
  conditional_cashflow_supported=k in supported,supported_months=ir.month_label.nunique(),first_supported_month=ir.month_label.min(),last_supported_month=ir.month_label.max(),
  supported_at_latest=k in latestcodes,latest_price_per100=float(lr.P_PRICE.iloc[0]) if len(lr) else np.nan,latest_valuation_date=lr.valuation_date.iloc[0] if len(lr) else None,
  coupon_pct=c.get('coupon_pct'),maturity_date=c.get('maturity_date'),source_url=c.get('source_url'),source_section=c.get('source_section'),verification_status=c.get('verification_status'),
  missing_fields_json=json.dumps(c.get('missing_fields',[])),implementation_flags_json=json.dumps(c.get('implementation_flags',[])),full_contract_and_quote_verification_complete=False))
l=pd.DataFrame(ledger).sort_values(['legal_issuer','verified_green','maturity_date']);l.to_csv(OUT/'contract_verification_ledger_119.csv',index=False)
l[l.added_this_extension].to_csv(OUT/'newly_verified_eight_conventional_contracts.csv',index=False)
l[l.supported_at_latest].to_csv(OUT/'latest_98_contracts_inventory.csv',index=False)
irs=[]
for (issuer,key,sec),g in l[l.conditional_cashflow_supported].groupby(['legal_issuer','legal_issuer_key','security_group'],dropna=False):
 lat=g[g.supported_at_latest];irs.append({'issuer':issuer,'legal_issuer_key':key,'security_group':sec,'registered_green':int(g.verified_green.sum()),'registered_conventional':int(g.verified_conventional.sum()),'latest_green':int(lat.verified_green.sum()),'latest_conventional':int(lat.verified_conventional.sum()),'latest_total':len(lat),'newly_verified_conventional':int(g.added_this_extension.sum()),'historical_green_bond_months':int(g.loc[g.verified_green,'supported_months'].sum()),'historical_conventional_bond_months':int(g.loc[g.verified_conventional,'supported_months'].sum())})
issuers=pd.DataFrame(irs).sort_values('latest_total',ascending=False);issuers.to_csv(OUT/'final_issuer_coverage.csv',index=False)
expected={'Verizon Communications Inc.':28,'DTE Electric Company':16,'MidAmerican Energy Company':13,'Northern States Power Company (Minnesota)':12,'Public Service Company of Colorado':12,'Boston Properties Limited Partnership':7,'Equinix, Inc.':7,'Apple Inc.':3}
assert dict(zip(issuers.issuer,issuers.latest_total))==expected
summary={
 'source_universe_codes':len(a),'source_green_flags_unchanged':int(a.is_green.sum()),'selected_working_scope_codes':int(a.in_selected_2963_scope.sum()),'latest_month':latest,
 'frozen_initial_registered_contracts':len(base),'final_registered_contracts':len(cs),'newly_verified_conventional_contracts':len(extra),'newly_verified_codes':extra,
 'final_registry_currency_counts':l.currency.value_counts().to_dict(),'verified_green_contracts':int(l.verified_green.sum()),'verified_conventional_contracts':int(l.verified_conventional.sum()),'classification_conflicts':int(l.classification_conflict.sum()),'unclassified_incomplete_records':int((~l.verified_green&~l.verified_conventional&~l.classification_conflict).sum()),
 'final_eligible_USD_cashflow_records':len(supported),'final_supported_bond_months':len(v),'additional_supported_bond_months':len(v)-9374,
 'latest_supported_contracts':len(latestcodes),'latest_supported_green':int(l.loc[l.supported_at_latest,'verified_green'].sum()),'latest_supported_conventional':int(l.loc[l.supported_at_latest,'verified_conventional'].sum()),'latest_legal_issuers':int(l.loc[l.supported_at_latest,'legal_issuer_key'].nunique()),'latest_issuer_breakdown':expected,
 'previous_unreviewed_mechanical_positive_history_queue':len(initial_mechanical),'removed_verified_codes_from_history_queue':sorted(removed_history),'remaining_unreviewed_mechanical_positive_history_queue':len(remaining_history),
 'previous_unreviewed_mechanical_latest_queue':len(initial_latest),'removed_verified_codes_from_latest_queue':sorted(removed_latest),'remaining_unreviewed_mechanical_latest_queue':len(remaining_latest),
 'remaining_mechanical_latest_source_green_flags':int(a.loc[a.Code.isin(remaining_latest),'is_green'].sum()),'remaining_mechanical_latest_source_conventional_flags':int((~a.loc[a.Code.isin(remaining_latest),'is_green']).sum()),
 'all_eight_were_in_previous_mechanical_latest_queue':set(extra)<=initial_latest,
 'queue_count_method':'Exact code-set difference against previous preserved queue; membership explicitly listed for each new record. No arithmetic assumption used.',
 'final_expansion_status_counts':a.expansion_status.value_counts().to_dict(),
 'registry_reconciliation':'119 records comprise 117 USD and 2 EUR: 34 verified green + 80 verified conventional + 2 classification conflicts + 1 incomplete USD Oracle + 2 incomplete EUR Apple. A total of 114 USD records have supported conditional cashflows.',
 'scope':'Original legal terms and stated conventions; full lifecycle, quote basis/side/timestamp and all contractual interpretations remain qualified. Data-support counts do not claim validated production pricing.',
 'original_baseline_files_unchanged':all(sha(paths[k])==hashes_before[k] for k in ['frozen_inventory','frozen_registry','frozen_summary']),
 'source_files':{k:{'path':str(p),'bytes':p.stat().st_size,'sha256':hashes_before[k]} for k,p in paths.items()}}
assert summary['original_baseline_files_unchanged']
(OUT/'final_inventory_summary.json').write_text(json.dumps(summary,indent=2))
lines=['# Final full-universe inventory','',
 f'The final merged register contains **{len(cs)} records**, with **114 supported USD contracts and {len(v):,} bond-months**. At {latest}, the conditional application has **98 contracts: 32 green and 66 conventional bonds across eight legal issuers**. This directory supersedes the initial111-record inventory for current coverage, while preserving all original files.','',
 '| Issuer | Latest green | Latest conventional | Total | New conventional |','| --- | --- | --- | --- | --- |']
for _,z in issuers.iterrows():lines.append(f'| {z.issuer} | {z.latest_green} | {z.latest_conventional} | {z.latest_total} | {z.newly_verified_conventional} |')
lines += ['', 'The eight new records are MidAmerican AB, AE and AH; NSP Minnesota BQ, CA and CB; and DTE EA and EB. Their source codes are explicitly reconciled to the original 20,106-code master. The green flags and original source universe are unchanged.', '',
 f'The remaining mechanical review queue contains **{len(remaining_history):,} codes with positive price history**, including **{len(remaining_latest):,} codes with a positive August2026 quote**. All eight newly verified codes were present in both former queues; the counts follow actual membership, recorded in the ledger. The remaining latest queue has **{summary["remaining_mechanical_latest_source_green_flags"]} source-green flags and {summary["remaining_mechanical_latest_source_conventional_flags"]:,} source-conventional flags**. These remain unverified candidates.', '',
 'The119 records contain117USD and2EUR. Of the USD records,34 are verified green,80 verified conventional,2 classification conflicts and1 incomplete Oracle record. The two EUR Apple records are outside the USD pricing scope. The two source-green conflicts remain excluded.', '',
 '## Files','', '- `all_20106_source_codes_inventory_final.csv` covers the full unchanged source universe with updated contract-review status.', '- `contract_verification_ledger_119.csv` records every registered contract and its qualifications.', '- `newly_verified_eight_conventional_contracts.csv` records exact former-queue membership and source links for the additions.', '- `latest_98_contracts_inventory.csv` gives the dated pricing-data scope.', '- `final_issuer_coverage.csv` reconciles issuer counts.', '- `remaining_unreviewed_mechanical_candidates_final.csv` and `remaining_unreviewed_mechanical_latest_candidates_final.csv` provide the remaining queues.', '- `final_inventory_summary.json` records all counts, the reconciliation, source hashes and the baseline-preservation check.', '', summary['scope']]
text='\n'.join(lines).replace('initial111','initial 111').replace('August2026','August 2026').replace('The119','The 119').replace('contain117USD and2EUR','contain 117 USD and 2 EUR').replace('records,34','records, 34').replace(',80',', 80').replace(',2 classification',', 2 classification').replace('and1 incomplete','and 1 incomplete')
(OUT/'README_Final_Inventory.md').write_text(text)
print(json.dumps({k:v for k,v in summary.items() if k!='source_files'},indent=2))
