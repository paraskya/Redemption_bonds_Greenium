# Final full-universe inventory

The final merged register contains **119 records**, with **114 supported USD contracts and 10,398 bond-months**. At 2026-08-31, the conditional application has **98 contracts: 32 green and 66 conventional bonds across eight legal issuers**. This directory supersedes the initial 111-record inventory for current coverage, while preserving all original files.

| Issuer | Latest green | Latest conventional | Total | New conventional |
| --- | --- | --- | --- | --- |
| Verizon Communications Inc. | 4 | 24 | 28 | 0 |
| DTE Electric Company | 5 | 11 | 16 | 2 |
| MidAmerican Energy Company | 7 | 6 | 13 | 3 |
| Northern States Power Company (Minnesota) | 5 | 7 | 12 | 3 |
| Public Service Company of Colorado | 4 | 8 | 12 | 0 |
| Boston Properties Limited Partnership | 4 | 3 | 7 | 0 |
| Equinix, Inc. | 2 | 5 | 7 | 0 |
| Apple Inc. | 1 | 2 | 3 | 0 |

The eight new records are MidAmerican AB, AE and AH; NSP Minnesota BQ, CA and CB; and DTE EA and EB. Their source codes are explicitly reconciled to the original 20,106-code master. The green flags and original source universe are unchanged.

The remaining mechanical review queue contains **2,043 codes with positive price history**, including **1,477 codes with a positive August 2026 quote**. All eight newly verified codes were present in both former queues; the counts follow actual membership, recorded in the ledger. The remaining latest queue has **110 source-green flags and 1,367 source-conventional flags**. These remain unverified candidates.

The 119 records contain 117 USD and 2 EUR. Of the USD records, 34 are verified green, 80 verified conventional, 2 classification conflicts and 1 incomplete Oracle record. The two EUR Apple records are outside the USD pricing scope. The two source-green conflicts remain excluded.

## Files

- `all_20106_source_codes_inventory_final.csv` covers the full unchanged source universe with updated contract-review status.
- `contract_verification_ledger_119.csv` records every registered contract and its qualifications.
- `newly_verified_eight_conventional_contracts.csv` records exact former-queue membership and source links for the additions.
- `latest_98_contracts_inventory.csv` gives the dated pricing-data scope.
- `final_issuer_coverage.csv` reconciles issuer counts.
- `remaining_unreviewed_mechanical_candidates_final.csv` and `remaining_unreviewed_mechanical_latest_candidates_final.csv` provide the remaining queues.
- `final_inventory_summary.json` records all counts, the reconciliation, source hashes and the baseline-preservation check.

Original legal terms and stated conventions; full lifecycle, quote basis/side/timestamp and all contractual interpretations remain qualified. Data-support counts do not claim validated production pricing.