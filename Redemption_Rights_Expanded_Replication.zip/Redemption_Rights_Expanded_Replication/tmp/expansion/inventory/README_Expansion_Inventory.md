# Expanded bond inventory

The saved universe contains **20,106 source codes**. The legally reviewed cashflow subset supports **90 contracts at 2026-08-31: 32 green and 58 conventional bonds across 8 legal issuers**. This is the immediate conditional expansion universe.

| issuer | latest_green | latest_conventional | historical_green_bond_months | historical_conventional_bond_months | issuer_months_both_classes | latest_green_outside_conventional_maturity_range |
| --- | --- | --- | --- | --- | --- | --- |
| MidAmerican Energy Company | 7 | 3 | 662 | 581 | 115 | 7 |
| DTE Electric Company | 5 | 9 | 378 | 1115 | 100 | 3 |
| Northern States Power Company (Minnesota) | 5 | 4 | 343 | 563 | 84 | 5 |
| Verizon Communications Inc. | 4 | 24 | 277 | 2659 | 91 | 0 |
| Public Service Company of Colorado | 4 | 8 | 332 | 913 | 93 | 1 |
| Boston Properties Limited Partnership | 4 | 3 | 286 | 265 | 87 | 2 |
| Equinix, Inc. | 2 | 5 | 178 | 425 | 66 | 0 |
| Apple Inc. | 1 | 2 | 189 | 208 | 106 | 0 |

## Exact scope

The 106 cashflow-eligible records supply 9,374 supported bond-months and 742 issuer-months with both verified classes. Of these, 623 issuer-months have at least three distinct conventional maturities. This is a data-support count, not an identification proof or fitted result. The fixed nearest-comparator design remains a narrower sample; a full issuer-curve design can use the wider set.

111 total records comprise 109 USD and 2 EUR. The 108 USD classified/contested subset comprises 34 green, 72 conventional and 2 conflicts; remaining USD record is incomplete Oracle 68389XBV.

## Contract distinctions for the option driver

The source register must be interpreted bond by bond. Equinix and Boston Properties fix the Treasury reference before notice. Utility contracts mix dealer-based comparable-Treasury yields and daily H.15 by vintage. A dealer benchmark requires a clearly reported curve proxy when historical dealer observations are unavailable. DTE AA discounts make-whole cashflows through actual maturity even though it has an earlier par-call date. The make-whole cashflow horizon and Treasury comparison horizon must each be taken from their own clause. Northern States Power Minnesota has an unresolved maximum-notice qualification. PSC Colorado has principal business-day and first-stub qualifications; the existing monthly cashflow screen excludes unsupported first-stub observations.

At the latest date 33 contracts use dealer-based primary benchmarks and 13 explicitly fix before notice. The missing-term table preserves every original open item. No missing term has been filled with an invented zero, par-call date or issuer-wide rule.

## Larger source-universe expansion

The source flags identify 238 green codes, of which 199 have a positive saved history and 145 have a latest positive raw quote. The selected working scope has 2,963 codes. 2,051 unreviewed codes satisfy the preserved mechanical review screen and have a positive history; 1,485 have a latest positive quote. These are contract-review candidates. Their currency, legal issuer, seniority, green classification and redemption rights require validation before joining the pricing sample.

The source issuer strings are not verified legal-entity groups. The two preserved source-green conflicts, Equinix BM and PSC Colorado CT, remain excluded. Northern States Power Minnesota and Wisconsin remain separate. Economic-alias flags are retained so parallel codes do not silently become independent instruments.

## Files

- `latest_conditional_pricing_universe.csv` and `latest_conditional_contracts.json` supply the immediate 90-contract expansion.
- `reviewed_contracts_and_missing_terms.csv` and `missing_terms_long.csv` retain source clauses, flags and missing items.
- `reviewed_issuer_month_coverage.csv` gives all supported historical legal-issuer month intersections.
- `all_20106_source_codes_inventory.csv` covers the complete saved universe without changing any source flag.
- `all_unreviewed_mechanical_candidates.csv` and `source_green_issuer_candidate_coverage.csv` give the remaining research queue.
- `expansion_inventory_summary.json` records counts, source hashes and the scope of the audit.

Supported conditional cashflows and original optionality terms do not certify lifecycle, quote basis/side/timestamp, executable price, statistical calibration or every notice/fixing contingency. All full_pricing_ready flags remain false.

No pricing, refitting, provider request or modification of original data was performed by this inventory script.