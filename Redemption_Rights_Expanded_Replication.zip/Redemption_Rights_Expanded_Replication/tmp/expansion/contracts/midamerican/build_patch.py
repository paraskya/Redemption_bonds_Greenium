"""Propose verified AL/AN metadata updates without mutating the recovered register."""
from pathlib import Path
import json

ROOT = Path(__file__).resolve().parent
SOURCE = Path('/workspace/scratch/65719a5a359e/restored/Zero_Coupon_Greenium_Data_and_Code/inventory/inputs/comparison/results/normalized_contracts.json')
contracts = {r['source_code']: r for r in json.loads(SOURCE.read_text())['contracts']}
sources = {
    '595620AL': {
        'cusip': '595620AL9',
        'url': 'https://www.sec.gov/Archives/edgar/data/928576/000119312513371825/d600959dex44.htm',
        'reprint_url': 'https://contracts.justia.com/companies/midamerican-funding-llc-2077/contract/540188/',
        'document': 'Exhibit 4.4, 4.80% First Mortgage Bond due 2043, certificate and Annex 1',
    },
    '595620AN': {
        'cusip': '595620AN5',
        'url': None,
        'reprint_url': 'https://contracts.justia.com/companies/midamerican-funding-llc-2077/contract/401616/',
        'document': 'Exhibit 4.5, d703266dex45.htm, 4.40% First Mortgage Bond due 2044, certificate and Annex 1',
    },
}
patches=[]
for code, source in sources.items():
    r = contracts[code]
    updates = {
        'cusip': source['cusip'],
        'identifier_status': 'Full CUSIP corroborated by original certificate text',
        'maturity_date_primary_corroborated': True,
        'business_day_calendar': 'New York City banking days, excluding statutory or executive-order bank closures',
        'payment_adjustment_scope': 'coupon, redemption and principal; following without additional interest',
        'calendar_status': 'Legal NYC definition verified; engine holiday-calendar equivalence unverified',
        'mw_accrued_interest_treatment': 'Certificate Annex 1: max(par, PV of remaining scheduled principal and interest) plus accrued outside. No explicit accrued exclusion inside PV; before/after-discount exclusion remains unresolved.',
        'mw_accrued_exclusion_status': 'not_stated_in_original_certificate',
        'mw_accrued_exclusion_order': None,
        'mw_rounding_decimals': None,
        'calculation_rounding': {'percentage_point_decimals': 5, 'cash_amount_cents': True, 'cash_unit': 'actual dollar amount; not automatically per 100'},
        'notice': {**r['notice'], 'conditional_notice': True, 'condition': 'When unfunded at notice, effectiveness may depend on trustee receipt of redemption money by redemption date.', 'irrevocability': 'Funding condition verified; general irrevocability not stated in reviewed certificate'},
        'sinking_fund': {'status': 'expressly_absent_in_certificate'},
        'additional_sources': r.get('additional_sources', []) + [source],
        'missing_fields': [x for x in r['missing_fields'] if x not in ['full_CUSIP_primary_corroboration','payment_business_day_calendar_definition','exact_maturity_day_primary_corroboration']] + ['mw_accrued_exclusion_order'],
        'implementation_flags': [
            'Price basis and historical lifecycle remain unverified.',
            'Keep original actual-maturity MW cashflow and comparable-Treasury horizons.',
            'No deduction convention is inferred from silence in the certificate.',
            'A binding-notice engine is a conditional scenario for this funding-conditional contract.',
            'Actual FRBNY or dealer fixing and full NYC closure history remain unavailable.',
        ],
        'pricing_ready': False,
        'option_terms_complete': False,
    }
    patches.append({'match': {'source_code': code}, 'set': updates})

out = {
    'patch_type': 'proposed keyed field replacement; not applied',
    'source_register': str(SOURCE),
    'review_date': '2026-09-25',
    'disposition': 'Retain AL/AN exclusion from verified callable main sample. Certificate review closes identity/calendar/notice details but not the requested accrued deduction order.',
    'patches': patches,
    'optional_scenario_not_verified_contract': {
        'name': 'literal_full_schedule_plus_accrued',
        'formula': 'max(100, sum(full remaining cashflows * MW_discount)) + accrued',
        'instruction': 'Use only if separately labelled as a literal-reading sensitivity; do not map it to exclude_before_discount or subtract_after_discount.',
        'comparison_scenarios': ['exclude_before_discount', 'subtract_after_discount'],
    },
}
(ROOT/'proposed_AL_AN_patch.json').write_text(json.dumps(out, indent=2)+'\n')
print(ROOT/'proposed_AL_AN_patch.json')
