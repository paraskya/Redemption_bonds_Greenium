# MidAmerican certificate review — 25 September 2026

## Result

The original AL and AN certificates do **not** settle a before-discount versus after-discount accrued deduction. Both use the greater of par and discounted remaining scheduled payments, then add accrued outside. Neither says to subtract accrued inside that calculation. Assigning either existing engine mode would therefore introduce an unverified interpretation. A separately named literal-full-schedule sensitivity is possible; the two bonds should remain outside a contract-verified callable main sample.

## Sources and short evidence

| Code | Original certificate | Directly confirmed identity |
|---|---|---|
| 595620AL | [SEC Exhibit 4.4](https://www.sec.gov/Archives/edgar/data/928576/000119312513371825/d600959dex44.htm), [complete certificate reprint](https://contracts.justia.com/companies/midamerican-funding-llc-2077/contract/540188/) | CUSIP 595620AL9; 4.80%; issued 2013-09-19; maturity 2043-09-15 |
| 595620AN | [Exhibit 4.5 certificate reprint, d703266dex45.htm](https://contracts.justia.com/companies/midamerican-funding-llc-2077/contract/401616/) | CUSIP 595620AN5; 4.40%; issued 2014-04-03; maturity 2044-10-15 |

Only the underlying filed exhibit text was used, not the reprint site's generated synopsis. The original AN SEC accession was not independently resolved, so no SEC URL is invented for it.

AL Annex 1 refers to payments **“from the redemption date to the maturity date”** and adds **“plus (b) accrued interest on the principal amount thereof to the redemption date.”** The AN Annex 1 has the same operative structure. These excerpts establish the horizon and exterior accrual, not an interior deduction.

The retained normalized-record terms are supported: Treasury plus 15 bp; semiannual discounting on 30/360; actual maturity for both cashflows and comparable-Treasury selection; par calls from 2043-03-15 and 2044-04-15 respectively. The benchmark uses the third prior NYC business day's FRBNY 15:30 composite bid/ask price, with the specified single dealer's 17:00 quotation as fallback. Treasury-rate conversion is semiannual-equivalent or day-count-interpolated yield.

Additional verified fields are encoded in the proposed patch. The certificates specify NYC banking days, following payments without additional accrual, 30–60-day notice, conditional effectiveness if redemption funding reaches the trustee, and no sinking fund. Rounding applies to percentage points and actual dollar amounts; cents must not automatically become two decimals per 100 principal.

## Why the two familiar accrued modes cannot be silently substituted

For redemption between coupon dates, let `PVfull` be the discounted full future coupon schedule, `AI` the accrued interest, and `Dnext` the make-whole discount factor to the next coupon. The alternatives are:

- Literal full-schedule interpretation: `max(100, PVfull) + AI`.
- Before-discount exclusion: `max(100, PVfull - AI * Dnext) + AI`.
- After-discount exclusion: `max(100, PVfull - AI) + AI`.

These are numerically different when the floor does not bind. The legal text reviewed supports the exterior `+ AI`; it does not explicitly select an interior deduction. This conclusion is an implementation assessment, not an assertion that one interpretation reflects actual trustee settlement practice. Historical redemption calculations or written trustee confirmation would resolve that remaining point.

## Additional conventional support: AB, AE and AH

Do not reject the three older senior-note candidates solely because they were originally unsecured. The issuer's [2025 annual report](https://www.brkenergy.com/assets/upload/financial-filing/20251231_99_bhec_annual_Form10-K.pdf), printed p. 285 (PDF p. 295), states that after the 2013 first-mortgage issuance **“its then outstanding senior unsecured debt was equally and ratably secured with such first mortgage bonds.”** Note 8, printed pp. 307–308 (PDF pp. 317–318), repeats the security relationship and lists outstanding 6.75% due 2031, 5.75% due 2035 and 5.80% due 2036 notes. This supports a collateral match during the proposed post-2013 panel, subject to bond identity and lifecycle verification.

The [AB first supplemental indenture dated 8 February 2002](https://contracts.justia.com/companies/midamerican-funding-llc-2077/contract/1230936/) confirms the issuer, 6.75% due 2031 series, $400 million original amount, and equal-security covenant. Its redemption section incorporates Annex 1 of the note; the annex is absent from that reprint. AB's exact make-whole, payment and notice terms therefore still need the actual note/prospectus. Security eligibility alone is insufficient to include it in callable pricing.

## Files and application

`proposed_AL_AN_patch.json` is a keyed proposal, not a mutation of the recovered register. Run `build_patch.py` to reproduce it. It intentionally retains `pricing_ready=false` and `option_terms_complete=false`, preserves unresolved lifecycle and dealer-fixing fields, and identifies the optional sensitivity independently of the verified metadata.
