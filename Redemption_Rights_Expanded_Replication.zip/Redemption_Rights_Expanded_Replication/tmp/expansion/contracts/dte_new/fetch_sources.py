from pathlib import Path
import urllib.request,json,concurrent.futures,html
from html.parser import HTMLParser
ROOT=Path(__file__).resolve().parent
SOURCES={
'EA_prospectus':'https://www.sec.gov/Archives/edgar/data/28385/000095012405005614/k98763bae424b5.htm',
'EA_8k':'https://www.sec.gov/Archives/edgar/data/28385/000095012405005637/k98891e8vk.htm',
'EB_prospectus':'https://www.sec.gov/Archives/edgar/data/28385/000095012406002912/k05404b2e424b2.htm',
'EB_8k':'https://www.sec.gov/Archives/edgar/data/28385/000095012406002962/k05597e8vk.htm'}
class Extract(HTMLParser):
 def __init__(self):super().__init__();self.parts=[]
 def handle_data(self,d):self.parts.append(d)
def get(k,u):
 try:
  r=urllib.request.urlopen(urllib.request.Request(u,headers={'User-Agent':'AcademicResearch'}),timeout=40);b=r.read()
  (ROOT/(k+'.html')).write_bytes(b)
  x=Extract();x.feed(b.decode('utf8',errors='replace'))
  (ROOT/(k+'.txt')).write_text('\n'.join(x.parts))
  return {'key':k,'url':u,'status':r.status,'bytes':len(b)}
 except Exception as e:return {'key':k,'url':u,'error':str(e)}
if __name__=='__main__':
 with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
  rs=list(pool.map(lambda a:get(*a),SOURCES.items()))
 (ROOT/'source_fetch_log.json').write_text(json.dumps(rs,indent=2));print(json.dumps(rs,indent=2))
