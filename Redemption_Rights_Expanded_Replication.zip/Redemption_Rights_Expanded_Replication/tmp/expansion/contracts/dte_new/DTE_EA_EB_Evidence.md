# DTE EA and EB — additional conventional anchors

## Result

The original SEC note and mortgage forms verify two additional conventional contracts. Their payment and ordinary redemption terms are fully specified for the declared conditional pricer. They are senior notes backed by pledged general and refunding mortgage bonds, rather than directly issued mortgage bonds. Their underlying first-lien priority can be associated with the existing DTE mortgage cohort under the unreleased original collateral structure, with the wrapper and collateral release provisions retained explicitly.

| Field | 250847EA | 250847EB |
|---|---|---|
| Original issuer | The Detroit Edison Company | The Detroit Edison Company |
| Current issuer and CIK | DTE Electric Company, 28385 | DTE Electric Company, 28385 |
| Coupon | 5.70% | 6.625% |
| Original issue | 6 October 2005 | 24 May 2006 |
| Contractual maturity | 1 October 2037 | 1 June 2036 |
| Coupon days | 1 April / 1 October | 1 June / 1 December |
| First coupon | 1 April 2006 | 1 December 2006 |
| Day count | 30/360 | 30/360 |
| Make-whole spread | 30 bp | 30 bp |
| Make-whole cash-flow endpoint | Actual maturity | Actual maturity |
| Treasury comparison endpoint | Actual maturity | Actual maturity |
| Terminal par-call window | None | None |
| Holder notice | 30–60 calendar days | 30–60 calendar days |
| Separate trustee notice | 60 days before holder notice; trustee may shorten | Same |
| Treasury fixing | Dealer bid/ask mean, 17:00 New York, third business day before redemption | Same |
| Accrued interest | Excluded from scheduled coupon before discount; added once after floor | Same |
| Payment adjustment | Following, with no additional interest | Same |
| Contractual calendar | New York or Michigan bank closures | Same |
| Holder put / sinking fund | Expressly absent | Expressly absent |

The normalized files use maturity as the `par_call_date` sentinel so the existing engine has no terminal par-call branch. `has_terminal_par_call = false` records the actual term. The first coupon amounts are derived from the specified dates and 30/360 rule, not guessed from the regular coupon: 2.7708333333 per 100 for EA and 3.4413194444 for EB. All current monthly observations are well after those first coupons.

## Primary contract evidence

EA's [Nineteenth Supplemental Indenture and Annex A note form](https://www.sec.gov/Archives/edgar/data/28385/000095012405006247/k99336exv4w247.txt) gives the original issue date, payments, business-day rule, note-specific redemption, notice and collateral-release provisions. Its [matching 2005 Series E mortgage indenture](https://www.sec.gov/Archives/edgar/data/28385/000095012405006247/k99336exv4w248.txt) identifies the pledged mortgage series and its equal and ratable security under the 1 October 1924 mortgage. The [original final prospectus](https://www.sec.gov/Archives/edgar/data/28385/000095012405005614/k98763bae424b5.htm) confirms the offering, terms and general-corporate/refinancing use of proceeds.

EB's [Twentieth Supplemental Indenture and Annex A note form](https://www.sec.gov/Archives/edgar/data/28385/000095012406004365/k07405exv4w249.txt) supplies the corresponding 2006 Series A terms. The [matching mortgage indenture](https://www.sec.gov/Archives/edgar/data/28385/000095012406004365/k07405exv4w250.txt) states the mortgage bonds' equal and ratable security. Its [original final prospectus](https://www.sec.gov/Archives/edgar/data/28385/000095012406002912/k05404b2e424b2.htm) verifies use of proceeds. The [SEC underwriting agreement's final term sheet](https://www.sec.gov/Archives/edgar/data/28385/000095012406002962/k05597exv1w1.htm) explicitly prints CUSIP 250847EB2.

EA's full CUSIP and both ISINs are corroborated by [Fitch's own issuer-security listing](https://www.fitchratings.com/entity/dte-electric-company-80089019). This identifier corroboration is supplementary; the collateral conclusion uses the primary mortgage documents. EA's full-CUSIP print has not yet been found in its SEC forms, so that specific evidence gap is retained.

The [SEC company submissions record](https://data.sec.gov/submissions/CIK0000028385.json) records the current DTE Electric name and former Detroit Edison name under CIK 28385. The [2025 Form 10-K](https://www.sec.gov/Archives/edgar/data/936340/000093634026000054/dte-20251231.htm) continues to incorporate both exact note indentures and their corresponding mortgage series, providing the original document links used above.

## Underlying collateral comparison

The original note indentures' section 4.01 pledges a matching series of general and refunding mortgage bonds under the 1 October 1924 mortgage to secure principal, premium and interest on the senior notes. The related mortgage bonds' payment dates, rates and redemption provisions correspond to the notes. The mortgage forms state equal and ratable security with the other bonds under that mortgage, subject to the mortgage's stated exceptions.

The [February 2026 SEC prospectus](https://www.sec.gov/Archives/edgar/data/28385/000119312526058873/d43542d424b2.htm) provides current primary corroboration. The accompanying base prospectus's “Security; Pledge of Mortgage Bonds” section, pages 20–22, states that the pledged bonds have a first mortgage lien and rank on parity with all other DTE general and refunding mortgage bonds. It reports approximately $1.0 billion of debt secured by pledged mortgage bonds and $10.3 billion of non-release mortgage bonds at 31 December 2024. The latter exceeded the contractual release threshold substantially. The February 2026 offering uses the same 1924 mortgage, and the [June 2026 Form 10-Q](https://www.sec.gov/Archives/edgar/data/936340/000093634026000146/dte-20260630.htm), Note 9, confirms $1.6 billion of new mortgage issuance and $100 million of mortgage redemptions through June.

These disclosures support continuing original collateral priority. This conclusion is an inference from the specific old pledge, current description of the pledge structure, and ongoing issuance under the same mortgage. It is not inferred solely from the general term “senior secured.”

## Rights and limits retained

The original note forms allow the mortgage collateral to be released once the defined stock of non-pledged mortgage debt has been retired below its threshold, with no continuing default. Under those original forms, the notes could then become unsecured or be secured by substitute mortgage bonds whose lien priority and covered property may differ. The same provisions forbid additional issuance under the old mortgage after release. The evidence above supports the unreleased original structure, but the registry retains the possibility of future release/substitution and the remaining lifecycle scope after June 2026. The pricer does not separately value that collateral transition. A sensitivity excluding these note wrappers remains a useful way to assess the common-credit-curve assumption.

Both notes make redemption conditional on receipt of sufficient funds by the paying agent or trustee. The pricer retains its funded irrevocable commitment policy and assumes trustee consent to shorten the separate administrative lead time. Those restrictions are recorded in the new contracts.

The dealer aggregation language in both original forms excludes the highest and lowest quotation, but says to average all quotes if there are fewer than two. This leaves the exactly-two-quote case awkward under the literal text. It has not been repaired to a generic three-quote threshold. The declared model par-yield proxy does not reconstruct actual dealer quotation aggregation; that legal interpretation remains an explicit open field.

## Files and handoff

`DTE_EA_EB_normalized_contracts.json` contains both records, while `DTE_250847EA_normalized.json` and `DTE_250847EB_normalized.json` allow individual ingestion. Original source bytes, text extracts, SHA-256 values and fetch logs are saved beside this note. The records preserve `pricing_ready = false` for the full lifecycle/dealer quotation scope, while marking the ordinary cash-flow and redemption formulas as reviewed. They can enter the conditional original-mortgage-priority application without disguising the senior-note wrapper.

DY and DZ remain quarantined as a possible original/exchange-note pair pending separate identifier and historical-series resolution; neither has been added by this handoff.
