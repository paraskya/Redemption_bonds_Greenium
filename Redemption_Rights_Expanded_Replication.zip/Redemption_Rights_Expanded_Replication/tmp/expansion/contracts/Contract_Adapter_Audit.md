# Contract adapter audit for the expanded AFNS++ application

## Scope and conclusion

This is an implementation audit of the 111 source-normalized contracts in `restored/Zero_Coupon_Greenium_Data_and_Code/inventory/inputs/comparison/results/normalized_contracts.json`. It compares their recorded contractual fields with `dated_bond_pricer.py`, `history_pricer.py`, `hull_white_contract_pricer.py`, `afns_shifted_contract_pricer.py`, and the developing multi-issuer adapter. It does not promote any source-review status or independently verify a new legal source.

The latest aligned observation date, 31 August 2026, has 90 contracts in the existing cash-flow inventory. Those 90 require five distinct benchmark treatments. Eighty-eight can enter an expanded **conditional** callable calculation after the targeted implementation changes below. The two remaining MidAmerican contracts, AL and AN, have unresolved accrued-interest treatment in the old FRBNY-composite convention and should remain excluded until their original bond forms settle it. A separate primary-document review is now addressing those two. Every normalized source record has `pricing_ready = false`; the resulting calculation must preserve the stated price-basis, lifecycle, payment-calendar, and dealer-proxy assumptions.

| Latest benchmark treatment | Contracts | Implementation disposition |
|---|---:|---|
| H.15 preceding-week average with the legacy three-month comparable-tenor rule | 37 | Existing history-aware schedule supports the numerical convention; retain comparable-issue proxy and notice restrictions where applicable. |
| Equinix/Boston H.15 observations fixed before notice | 13 | Extend observation dates to depend on notice and redemption, retain observed history, and use issuer-specific tenor rounding/interpolation. |
| Daily H.15 CMT | 5 | Use same fixing-day observation after 16:15, with publication-closure rollback; apply three-decimal Treasury and redemption rounding and subtract accrued after discount. |
| Dealer-comparable Treasury / Reuters | 33 | Use an explicitly labelled continuous-maturity model par-yield proxy at the contractual fixing date. Dealer selection, bid/ask and security-specific basis are not observed. |
| Old FRBNY composite prices with unresolved accrued convention | 2 | Exclude AL and AN pending primary-document resolution. |

The full registry has 46 legacy-weekly, 17 pre-notice-weekly, five daily-H.15, 37 dealer/Reuters, four old-FRBNY, and two EUR/German-reference contracts. The EUR instruments require a different curve, day count and benchmark interpretation. Existing class/security exclusions also remain in force.

## Corrections necessary before the expanded run

1. **Read both normalized layouts.** Utilities retain notice and fixing fields inside `notice` and `treasury_fixing`; their top-level aliases are absent. The 53 absent top-level benchmark labels are not 53 absent legal definitions.

2. **Use the correct fixing anchor.** Equinix and the six later Boston contracts fix three business days before the notice date. Apple, Verizon, utilities and the older Boston Reuters tranche fix relative to redemption. Observations at or before a decision date must be supplied from historical H.15 data or the simulated past. They must neither be simulated anew conditional on the decision nor dropped from the action set.

3. **Keep interpolation families distinct.** Legacy weekly contracts use a comparable-maturity rule, with a nearest-published-tenor proxy inside three months and two-nearest interpolation/extrapolation otherwise. Equinix interpolates bracketing tenors whenever maturity is not exact and rounds remaining life to the nearest month. Boston rounds remaining life upward to a month and interpolates/extrapolates the enclosing published tenors. The default Verizon three-month tolerance must not carry into either family.

4. **Correct daily H.15 publication timing.** The five latest daily-H.15 contracts, PSC CW/CX, DTE AQ/AR and NSP CV, specify the most recent published day at a cutoff after 16:15 on the third business day before redemption. Their ordinary publication lag is zero. A fixing day on which H.15 is not published must roll backward to the most recent publication day; Good Friday is an example handled separately by the existing H.15 calendar. A systematic one-day lag misdates every ordinary fixing.

5. **Keep accrued-interest order explicit.** The five daily-H.15 contracts subtract accrued from the discounted remaining payments, apply the par floor, and add accrued once. The other supported USD contracts exclude accrued from the first scheduled interest cash flow before discounting, apply the floor, and add it once. These two operations differ and are already distinct modes of the core engine. AL/AN currently lack a resolved exclusion convention and cannot be assigned either mode by default.

6. **Retain rounding units.** Equinix rounds the H.15 mean to two decimal places expressed in percentage points. Daily-H.15 contracts round the Treasury yield to three decimal percentage points and the clean redemption price to three decimals. The core implementation applies the latter rounding after the floor and adds accrued afterward; this ordering should remain visible in the adapter metadata.

7. **Separate the two maturity references.** Make-whole cash-flow truncation and Treasury comparison horizon are independent fields. In the latest sample Verizon FL, FE and FD have different endpoints. DTE AA retains actual contractual maturity as both make-whole and Treasury endpoint despite an earlier par-call date. Do not default either reference to the par-call date unless its own source field says so.

8. **Implement a dealer proxy honestly.** For dealer/Reuters contracts, the inherited AFNS++ path must receive a continuous tenor equal to the remaining redemption-to-reference horizon, evaluated at the fixing date. The existing shared `_conditional_redemption` calls H.15 tenor selection even for its dealer branch, so merely selecting `dealer_spot_par_proxy` is insufficient. No integer-month cast should appear in the dealer branch. The current expanded adapter's float tenor reaches the inherited `_cmt_coeff` unchanged. This is a model par-yield proxy, not reconstruction of the quotation-defined Treasury yield.

## Notice rights and information at the decision date

The saved core prices a funded, irrevocable commitment once the issuer gives notice. Nineteen of the latest 90 contracts explicitly permit conditional notice: seven active Equinix contracts and twelve PSC contracts. Those rights are outside the core stopping problem. The expansion may value the funded irrevocable policy as a specified restriction, but must not describe it as an exhaustive valuation of contractual cancellation or condition-setting rights.

Nine active NSP contracts have a verified minimum notice of 30 days and no verified maximum. Under the model's funded irrevocable commitment, the maximum need not affect the continuous-time optimum: when the redemption amount and fixing depend only on the redemption date, the issuer can defer an earlier notice to the latest admissible notice for the same redemption date. The delayed notice preserves the same committed cash flows and adds the right to reconsider. Thus a minimum-notice policy spans the optimum provided those delayed notice dates are admissible and included. This argument applies to the green holding-service objective because its effective discount kernel is positive and satisfies the conditional tower property; it does not require a nonnegative green state or deterministic credit.

For completeness, write the value of committing at decision time d to a fixed admissible redemption date r as C(d,r), and let d' = r minus the minimum notice. The later optimally callable liability satisfies V(d') <= C(d',r). Discounting this inequality back with the positive effective kernel and adding coupons paid between d and d' shows that waiting to d' has value no greater than C(d,r). Hence earlier commitment cannot improve the issuer's minimization. This requires notice itself not to change cash flows, the green service, the discount kernel or funding constraints, and the fixing and strike must not depend on notice. It therefore does not apply to the Equinix/Boston notice-relative fixing family.

The actual finite notice grid has not yet been closed under the map (d,r) to (r minus minimum notice,r). Its business-day adjustment can also omit a delayed notice when r minus 30 days is not an admissible grid day. The remaining issue is consequently a grid/admissibility approximation. The manuscript should not attribute a structural maximum-notice identification problem to this model, nor assert the implemented finite grid proves the continuous-time dominance result numerically.

DTE has a separate trustee advance-notice requirement of 60 days before holder notice, which the trustee may shorten. The holder-notice exercise policy therefore assumes trustee consent to the shorter administrative lead time. It must be labelled as such. PSC CP/CQ have a separate reducible trustee advance notice of 25 days before redemption.

**Past fixings now enter continuation estimation.** Storing observed fixing states correctly in the immediate redemption payoff is necessary, but the current Treasury factor vector alone does not carry all information relevant to future commitments. The original regression basis compressed historical fixing information into the current maximum exercise gain. The expanded adapter now retains, at each notice node, every fixing date already observed after valuation that appears in a current or future action on the finite grid. The simulation includes those dates; the continuation basis appends their three-factor states, expressed as normalized differences from the current state. Current factors are already present, so the differences preserve the retained information. Observations before valuation remain fixed inputs, and no future state enters this history basis. The regressions are still numerical approximations to conditional continuation, with independent training and evaluation paths.

Independent schedule checks found 30 of the 88 presently admitted contracts have at least one action involving an already observed fixing. Thirteen are the explicit Equinix/Boston pre-notice families; the other 17 are legacy weekly contracts with sufficiently short holder notice. The history extension therefore applies to every family where such observations occur. The daily-H.15 Good Friday rollback check and the Equinix pre-notice observation-week check passed. These checks validate the identified calendar/information changes; they do not assert a bound on Monte Carlo or policy error.

## Cash-flow calendars and first coupons

All USD contracts use a recorded 30/360 family and semiannual regular coupons, which the core handles. The `regular_first_coupon_supported = false` flag is not a blanket exclusion of an instrument. An explicit verified first-coupon amount can be supplied, and any ambiguous first stub ceases to enter future cash flows after its first payment. Existing monthly screens already remove unsupported pre-first-coupon observations. DTE's verified first amounts and the utility source qualifications should remain intact.

The engine actually uses pandas `USFederalHolidayCalendar`, plus optional explicit extra holidays. This is a **US federal-holiday approximation**, not an exact Federal Reserve banking calendar. Saturday-holiday observance is one reason those labels are not interchangeable. New York, Michigan, Chicago and trustee-office closure provisions are recorded but not completely implemented. Principal following is also not independently established for every utility record. The calculation may proceed under the declared following convention, but captions must not claim every payment-calendar detail was verified.

The engine separates contractual coupon dates, which drive accrual, from following-adjusted payment dates, which drive discounting. Redemption comparisons include coupons actually paid between notice and redemption. This is the appropriate structure for the stated convention, and the expanded adapter reuses it.

## Files

- `Contract_Engine_Support_Matrix.csv` has one row for each of the 111 normalized contracts, with benchmark family, current support, expansion disposition, notice/fixing fields, accrued order, separate maturity references, required changes, remaining scope and source URL.
- `Contract_Engine_Support_Matrix.json` retains the same machine-readable rows and audit scope.

The matrix states implementation support under declared assumptions. It is not a legal readiness certificate and does not overwrite the source registry.

## Observed implementation status

The developing adapter is isolated in `tmp/expansion/pricing/expanded_pricer.py` and `expansion_data.py`; the original saved engine is unchanged. The audit inspected the corrected before-notice anchor, family-specific interpolation, zero-lag daily publication with closure rollback, float dealer horizon, separate make-whole/Treasury endpoints, known-history continuation features, and explicit assumption metadata. Numerical smoke pricing is owned by the engine task. `Schedule_Convention_Checks.json` records the independent non-pricing checks and all contract-level past-fixing diagnostics. The brief 15-day history-coverage diagnostic in that file concerns a tested sufficient buffer; the final adapter uses the exact finite-grid set of needed observations instead of an arbitrary lag window.


## Final narrow calendar and notice audit

### Boston month ceiling

The final audit identified a concrete tenor-selection defect: `ceil(12 * ACT/365.25 years)` can turn an exact six-calendar-month interval, such as 1 April to 1 October, into seven months. Boston’s Reinvestment Rate definition prescribes remaining life rounded upward to a month, measured from redemption to the deemed maturity at the par-call date. It does not prescribe converting actual days to a 365.25-day year before this rounding. The recommended correction is the smallest nonnegative integer `m` for which `add_months(redemption_date, m) >= reference_date`, using the existing date library’s standard month-end clamping. This preserves exact calendar-month anniversaries. The engine agent is rerunning only the affected Boston issuer calibration.

Source: [Boston 3.4% 2029 supplemental indenture, Reinvestment Rate definition, p7](https://www.sec.gov/Archives/edgar/data/1043121/000119312519178827/d651208dex41.htm).

### NSP exact-30-day policy

The current numerical implementation for contracts whose maximum holder notice is unverified uses an internal minimum and maximum both equal to 30 calendar days. A proposed redemption date whose business-day payment adjustment breaks that exact interval is skipped. The results therefore value an **exactly 30 calendar-day restricted notice policy**, with infeasible adjusted-payment actions omitted. They do not cover every redemption date reachable under an at-least-30-day policy.

This restricted action set can be retained and labelled accurately without inventing a legal notice maximum or changing completed valuations. The earlier minimum-notice dominance argument is a statement about an appropriately closed decision grid; that closure has not been established for this numerical action set. A numerical lower-bound claim also requires care because continuation and policy values remain regression estimates. No new nonbinding maximum sentinel was recommended in the final audit.
