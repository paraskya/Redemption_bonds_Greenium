# Three additional MidAmerican conventional anchors

Original SEC prospectuses, specific pricing supplements and redemption annexes were retrieved for all three bonds. The records preserve the distinction between the original unsecured issuance and the subsequent mortgage security. No original contract or frozen pricing input was overwritten.

| Code | Original issue | Coupon dates | Maturity | Make-whole spread | Notice |
| --- | --- | --- | --- | --- | --- |
| 595620AB | 8 February 2002 | 30 June / 30 December | 30 December 2031 | 25 bp | 30–60 calendar days |
| 595620AE | 1 November 2005 | 1 May / 1 November | 1 November 2035 | 20 bp | 30–60 calendar days |
| 59562EAH | 6 October 2006 | 15 February / 15 August | 15 October 2036 | 20 bp | 30–60 calendar days |

All three have a par floor, whole-life make-whole redemption and no separate terminal par-call window. The annexes specify a comparable Treasury security selected by an investment banker, the historical NYFed composite Treasury price release and dealer-quotation fallback. The fixing is three business days before redemption. A comparable-security curve proxy remains an explicit valuation approximation; these provisions are not H.15 constant-maturity rules.

## Source provenance

- [AB original February 2002 SEC filing](https://www.sec.gov/Archives/edgar/data/928576/000095013602000310/0000950136-02-000310.txt), specific Pricing Supplement No. 1, Fixed Rate Notes and Annex 1.
- [AE October 2005 SEC prospectus](https://www.sec.gov/Archives/edgar/data/928576/000095013605006688/file001.htm), attached Pricing Supplement No. 1 and Annex 1.
- [AH October 2006 SEC prospectus](https://www.sec.gov/Archives/edgar/data/928576/000095013606008350/file1.htm), attached Pricing Supplement No. 1, Fixed Rate Notes p. S-7 and Annex 1.
- [AH issuer final FWP](https://www.sec.gov/Archives/edgar/data/928576/000095013606008336/file1.htm), independently confirms payment dates, maturity, CUSIP 59562EAH8 and ISIN US59562EAH80.
- [BHE 2025 Form 10-K](https://www.brkenergy.com/assets/upload/financial-filing/20251231_99_bhec_annual_Form10-K.pdf), MidAmerican printed p. 285 and Note 8, printed pp. 307–308.

The BHE report establishes that the previously outstanding senior unsecured debt became equally and ratably secured when first-mortgage bonds were issued in September 2013. The notes table lists these three series with principal outstanding of $400 million, $300 million and $350 million at December 2025. The entire saved monthly sample begins after this security attachment. The exact day within September 2013 is not inferred.

AB's full CUSIP 595620AB1 is corroborated in the [Unity Financial Life 2011 statutory holdings report](https://legacy.insurance.ohio.gov/FRAnnuals/2011/annual/IS/63819A2011IS.pdf), with coupon and maturity. AE's eight-character code, coupon and maturity appear in the [New Jersey Treasury June 2010 transactions report](https://www.nj.gov/treasury/doinvest/monthly_files/10_june_domestic_report.html); its full CUSIP 595620AE5 is corroborated in [Genworth's SEC Exhibit 10.24](https://www.sec.gov/Archives/edgar/data/1276520/000119312510041949/dex1024.htm). These are identifier corroborations; the issuer's own prospectuses supply the contract terms. No AB/AE ISIN has been inferred.

## AH final coupon is a verified calculation

Both the issuer FWP and specific pricing supplement state the February/August coupon dates and October 2036 maturity. The accompanying fixed-rate-note provision expressly accrues interest from the previous coupon to, but excluding, maturity on a 360-day year of twelve 30-day months. Thus the final accrual is 60/360 and the final interest is **0.9666666666666667 per 100**. Principal plus final interest is **100.96666666666667**. A full 2.9 coupon at maturity would be incorrect.

The record distinguishes `final_stub_calculation_verified=true` from `final_amount_explicitly_printed=false`. The amount follows from the stated rule and dates; the dollar amount is not printed in the prospectus. The full schedule contains 61 payment dates, with the first short coupon of 2.078333333333333, subsequent regular coupons of 2.9 and the final short coupon. AB's first coupon is 2.6625 followed by regular 3.375 coupons. AE pays regular coupons of 2.875.

## Accrued interest convention remains visible

The older annexes add accrued interest after the par-versus-present-value comparison without an express instruction to subtract accrued from the first discounted scheduled coupon. The normalized records therefore identify the literal scheduled-cashflow-plus-accrued branch and preserve the alternative subtraction treatment as a sensitivity. They do not reword the source as an explicit exclusion clause. The parent task selected this literal branch for the conditional expansion.

The pricing-ready flags remain qualified by this interpretation, the comparable-security proxy, original-contract lifecycle coverage and unverified quote metadata. Exact extraction of the dates and spreads does not verify every historical amendment or redemption event.

## Files

- `midamerican_additional_contracts.json` contains all three normalized records.
- The individual code-named JSONs contain identical standalone records.
- `verified_contractual_cashflows.csv` and the code-named cashflow CSVs supply all dated coupon and principal amounts before the declared following-business-day adjustment.
- `new_anchor_monthly_raw_prices.csv` retains all 128 source month labels for AB, AE, AH and NSP BQ, including original request and response-row provenance.
- `new_anchor_latest_raw_prices.csv` retains the four August 2026 observations. These are saved FactSet quotes, not web quotations.
- `source_manifest_verified.json` records the source URLs, local filenames, sizes and SHA256 hashes.
