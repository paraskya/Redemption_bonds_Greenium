from pathlib import Path
import json,hashlib,datetime as dt,pandas as pd
P=Path('/workspace/scratch/65719a5a359e/tmp/expansion/contracts/midamerican_new');S=P/'sources'
sec='https://www.sec.gov/Archives/edgar/data/928576/'
BHE='https://www.brkenergy.com/assets/upload/financial-filing/20251231_99_bhec_annual_Form10-K.pdf'
source={
 'AB':{'file':'AB_complete.txt','url':sec+'000095013602000310/0000950136-02-000310.txt','section':'Pricing Supplement No.1 dated February4 2002; Annex1; accompanying Fixed Rate Notes pp.S-5–S-6'},
 'AE':{'file':'AE_2005_prospectus.htm','url':sec+'000095013605006688/file001.htm','section':'Pricing Supplement No.1 dated October24 2005; Annex1; accompanying Fixed Rate Notes and General'},
 'AH':{'file':'AH_2006_prospectus.htm','url':sec+'000095013606008350/file1.htm','section':'Pricing Supplement No.1 dated October3 2006; Annex1; Fixed Rate Notes p.S-7'},
 'AHFWP':{'file':'AH_fwp.htm','url':sec+'000095013606008336/file1.htm','section':'Final pricing terms dated October3 2006'},
 'BHE25':{'file':'BHE_2025_10K.pdf','url':BHE,'section':'MidAmerican Energy printedp285 and Note8 printedpp307–308'},
}
master=pd.read_csv('/workspace/scratch/65719a5a359e/output/csv_bond_contracts/bonds_master.csv',dtype=str).set_index('Code')
specs=[
 dict(suffix='AB',code='595620AB',cusip='595620AB1',isin=None,coupon=6.75,issue='2002-02-08',maturity='2031-12-30',coupons=['06-30','12-30'],records=['06-15','12-15'],first='2002-06-30',amount=400000000,mw=25,issue_price=98.857),
 dict(suffix='AE',code='595620AE',cusip='595620AE5',isin=None,coupon=5.75,issue='2005-11-01',maturity='2035-11-01',coupons=['05-01','11-01'],records=['04-15','10-15'],first='2006-05-01',amount=300000000,mw=20,issue_price=None),
 dict(suffix='AH',code='59562EAH',cusip='59562EAH8',isin='US59562EAH80',coupon=5.8,issue='2006-10-06',maturity='2036-10-15',coupons=['02-15','08-15'],records=['02-01','08-01'],first='2007-02-15',amount=350000000,mw=20,issue_price=None)]
def date(s):return dt.date.fromisoformat(s)
def d30360(a,b):
 a=date(a) if isinstance(a,str) else a;b=date(b) if isinstance(b,str) else b
 return (b.year-a.year)*360+(b.month-a.month)*30+(min(b.day,30)-min(a.day,30))
rows=[];contracts=[]
for s in specs:
 code=s['code'];src=source[s['suffix']];mat=date(s['maturity']);first=date(s['first']);iss=date(s['issue'])
 dates=sorted([dt.date(y,*map(int,mmdd.split('-'))) for y in range(first.year,mat.year+1) for mmdd in s['coupons'] if first<=dt.date(y,*map(int,mmdd.split('-')))<=mat])
 if mat not in dates:dates.append(mat)
 sched=[];prev=iss
 for n,cf in enumerate(dates):
  days=d30360(prev,cf);interest=s['coupon']*days/360;principal=100.0 if cf==mat else 0.
  item={'code':code,'contractual_date':str(cf),'unadjusted_date':str(cf),'accrual_start_date':str(prev),'day_count_days_30_360':days,'interest_per100':interest,'coupon_amount_per100':interest,'principal_per100':principal,'cashflow_per100':interest+principal,'payment_adjustment':'following','additional_interest_for_delay':False,'amount_origin':'calculated directly from prospectus fixed-rate accrual rule and specific payment dates'}
  sched.append(item);rows.append(item);prev=cf
 finalstub=s['maturity'][5:] not in s['coupons']
 notes=['Original issue terms and later equal-security status verified; historical lifecycle and current quote metadata remain qualified.',
 'Whole-life make-whole with par floor; no terminal par-call window is specified.',
 'Primary comparable-Treasury benchmark uses NYFed Composite3:30 quotations; dealer-average fallback is stated. The option engine uses a declared comparable-Treasury curve proxy, not H15 CMT as a contractual substitute.',
 'Annex adds accrued interest after max(par,PV). Unlike later explicit clauses, it does not expressly subtract accrued from discounted scheduled interest. Literal scheduled-coupon-plus-accrued branch is used with the alternative excluded-accrual sensitivity; interpretation is not silently resolved.',
 'Security group is senior secured for the entire saved2016–2026 monthly window, reflecting September2013 equal-security attachment; original issue classification was senior unsecured.']
 if finalstub:notes.append('Off-cycle maturity: contractual coupons February15/August15, maturity October15 2036. Final interest is5.8*60/360=0.9666666667 per100. Do not pay a full2.9 final coupon or generate dates backward from maturity.')
 ident={'AB':('CUSIP corroborated in insurer primary statutory holding statement, with coupon6.75 and maturity2031-12-30; original issuer prospectus establishes the same issue terms.','https://legacy.insurance.ohio.gov/FRAnnuals/2011/annual/IS/63819A2011IS.pdf'),
 'AE':('Eight-character code,coupon and maturity corroborated in NewJersey Treasury June2010 transactions; fullCUSIP corroborated in Genworth SEC Exhibit10.24.','https://www.sec.gov/Archives/edgar/data/1276520/000119312510041949/dex1024.htm'),
 'AH':('FullCUSIP and ISIN explicitly printed in the issuer October3 2006 FWP.',source['AHFWP']['url'])}[s['suffix']]
 c=dict(source_code=code,issue_code=code,Code=code,cusip=s['cusip'],isin=s['isin'],identifier_status=ident[0],cusip_verification=ident[0],
 issuer='MidAmerican Energy Company',legal_issuer_name='MidAmerican Energy Company',legal_issuer_key='CIK0000928576',cik='928576',
 currency='USD',currency_evidence='Accompanying General terms denominate medium-term notes and all payments in United States dollars.',
 coupon_pct=s['coupon'],issue_date=s['issue'],economic_issue_date=s['issue'],interest_accrual_start_date=s['issue'],maturity_date=s['maturity'],frequency=2,coupon_frequency_per_year=2,
 coupon_dates_mmdd=s['coupons'],record_dates_mmdd=s['records'],first_coupon_date=s['first'],first_coupon_date_origin='Specific pricing supplement; AE first record date and general first-payment rule imply first May2006 payment.',
 first_coupon_type='regular' if sched[0]['day_count_days_30_360']==180 else 'short_stub',regular_first_coupon_supported=sched[0]['day_count_days_30_360']==180,
 first_stub_calculation_verified=True,first_stub_calculation_method='Original issue date to first specific coupon date under explicit twelve30-day-month rule.',first_coupon_amount_per100=sched[0]['interest_per100'],
 final_stub=finalstub,final_stub_calculation_verified=True,final_coupon_amount_per100=sched[-1]['interest_per100'],final_amount_explicitly_printed=False,
 final_stub_calculation_method='Most recent contractual coupon date to stated maturity, excluding maturity, under explicit30/360 fixed-note clause.',
 final_stub_accrual_start_date=sched[-1]['accrual_start_date'],final_stub_day_count_days_30_360=sched[-1]['day_count_days_30_360'],
 day_count='30/360',day_count_verification='Explicit360-day year of twelve30-day months in fixed-rate-note terms.',
 payment_adjustment='following',coupon_payment_adjustment='following',principal_payment_adjustment='following',payment_adjustment_scope='Fixed-rate-note clause expressly applies next-business-day payment to both interest dates and maturity.',extra_interest_on_postponed_payment=False,
 business_day_calendar='New York City banking days excluding weekends and legal/regulatory/executive-order bank closures',calendar_status='Contract NewYork banking calendar; engine common FederalReserve banking proxy with local closures qualification.',
 seniority='senior',security='secured_equally_and_ratably_since_2013_09',security_group='senior_secured_first_mortgage',security_at_original_issue='senior_unsecured',security_attachment_month='2013-09',security_attachment_day_verified=False,
 security_history=[{'period':'before September2013','security':'senior unsecured'},{'period':'September2013 onward','security':'equally and ratably secured with first mortgage bonds','source_url':BHE,'source_section':'printedp285; Note8 printedpp307–308'}],
 callable=True,is_callable=True,noncallable=False,par_call_date=None,mw_spread_bp=s['mw'],mw_cashflow_end_date=s['maturity'],mw_cashflow_end_basis='actual_contractual_maturity',
 mw_accrued_interest_treatment='literal_scheduled_cashflows_plus_accrued_after_floor',mw_accrued_interest_exclusion_explicit=False,mw_accrued_interpretation_status='Literal branch selected; subtract-accrued alternative retained as sensitivity.',
 notice={'min_days':30,'max_days':60,'day_type':'calendar days','conditional_notice':True,'condition':'If redemption funds are not held when notice is given, redemption may be conditioned on trustee receipt by redemption date.','irrevocability':None},
 notice_min_days=30,notice_max_days=60,notice_day_type='calendar days',benchmark_family='US_Treasury_comparable_security_NYFed_composite_prices_or_dealer',fixing_business_days_before=3,
 treasury_comparable_horizon_date=s['maturity'],treasury_comparable_horizon_verified=True,
 treasury_fixing={'benchmark_family':'US_Treasury_comparable_security_NYFed_composite_prices_or_dealer','fixing_business_days_before':3,'fixing_relative_to':'redemption_date','comparable_security_horizon_date':s['maturity'],'remaining_life_horizon':s['maturity'],'comparator_maturity_target':s['maturity'],'horizon_basis':'actual_maturity',
 'publication_rule':'NYFed Composite3:30p.m. Quotations for USGovernment Securities, bid/ask mean of selected comparable issue on third business day before redemption.','rate_conversion':'Semiannual-equivalent yield to maturity of selected Treasury at comparable price.','selection_agent':'Reference Treasury Dealer appointed by trustee after consultation with issuer.',
 'fallback':'Average ReferenceTreasuryDealer quotations actually obtained when release unavailable or selected prices absent.','dealer_quotation_time':'17:00','timezone':'America/New_York','dealer_quotation_business_days_before':3,'dealer_price_side':'bid/ask mean','dealer_aggregation':'Average all obtained dealer quotations; no trimming rule specified.','observed_dealer_quotes_available':False},
 call_windows=[{'start_date':s['issue'],'end_date':s['maturity'],'end_inclusive':False,'exercise_style':'whole at any time or part from time to time subject to notice','strike_type':'make_whole','floor_pct':100,'spread_bp':s['mw'],'remaining_cashflows_end_date':s['maturity'],'discount_frequency':2,'discount_day_count':'30/360','accrued_interest_treatment':'Add accrued after max(par,PV remaining scheduled payments); no express exclusion from PV stated.','source_url':src['url'],'source_section':'Annex1 Redemption Provisions'}],
 partial_redemption={'allowed':True,'minimum_denomination':1000,'increment':1000},holder_put={'present':False,'source':'Checked pricing-supplement repayment election'},sinking_fund=False,conversion={'status':'No conversion provision specified in fixed-note pricing terms'},change_of_control={'status':'No issue-specific holder put specified in reviewed pricing terms'},
 is_green_source=False,verified_is_green=False,green=False,eligible_as_verified_green=False,eligible_as_verified_conventional=True,classification_conflict=False,green_use_of_proceeds_status='ordinary_capital_expenditure_or_refinancing_proceeds_without_green_earmark',
 cashflow_terms_reviewed=True,original_redemption_terms_reviewed=True,option_terms_complete=True,option_rights_ready=True,option_rights_ready_scope='Original stated mechanics with explicit accrued-convention sensitivity and benchmark proxy; historical event completion not claimed.',
 cashflow_ready_after_first_coupon=True,cashflow_ready_from_issue=True,required_cashflows_ready=True,maturity_date_primary_corroborated=True,economic_issue_date_fallback=False,accrual_start_fallback=False,lifecycle_verified=False,pricing_ready=False,
 issue_amount_nominal=s['amount'],outstanding_amount_primary=s['amount'],outstanding_amount_date='2025-12-31',original_issue_price_per100=s['issue_price'],source_row_original=master.loc[code].fillna('').to_dict(),
 source_url=src['url'],source_section=src['section'],source_document_key='MidAmerican_'+s['suffix'],source_sha256=hashlib.sha256((S/src['file']).read_bytes()).hexdigest(),
 verification_status='original_cashflows_and_redemption_terms_verified; accrued_branch_and_benchmark_proxy_explicit',
 missing_fields=['exhaustive_historical_call_and_amendment_history','current_quote_basis_side_timestamp','historical_dealer_fixings','mw_accrued_exclusion_interpretation'],implementation_flags=notes,
 verified_contractual_cashflows=sched,contractual_schedule_rows=len(sched),
 source_refs=[{'id':'MID'+s['suffix'],'url':src['url'],'title':'Original issue prospectus with pricing supplement and redemption Annex1','section':src['section']},{'id':'BHE25','url':BHE,'title':'BHE2025Form10K with MidAmerican financial statements','section':source['BHE25']['section']},{'id':s['suffix']+'ID','url':ident[1],'title':'Identifier corroboration'}],
 field_provenance=[{'fields':['coupon_pct','issue_date','maturity_date','coupon_dates_mmdd','record_dates_mmdd','frequency','holder_put','sinking_fund'],'source_url':src['url'],'section':'Specific pricing supplement','paraphrase':'Issue-specific terms and marked fixed-note elections.'},
 {'fields':['day_count','payment_adjustment','principal_payment_adjustment','first_coupon_amount_per100','final_coupon_amount_per100','verified_contractual_cashflows'],'source_url':src['url'],'section':'Fixed Rate Notes plus specific payment dates','paraphrase':'Accrual runs from issue or previous coupon to excluding payment/maturity on30/360. Delayed business-day payment does not earn extra interest. Amounts calculated from these rules.'},
 {'fields':['call_windows','mw_spread_bp','notice','treasury_fixing'],'source_url':src['url'],'section':'Annex1','paraphrase':'Whole-life par-floor make-whole, comparableTreasury price benchmark, third-business-day fixing,30–60days notice and conditional funding rule.'},
 {'fields':['security_group','security_history','outstanding_amount_primary'],'source_url':BHE,'section':source['BHE25']['section'],'paraphrase':'Previously senior unsecured debt shares first-mortgage security from September2013; debt table lists these three series outstanding in2025.'}])
 if s['suffix']=='AH':c['source_refs'].append({'id':'AHFWP','url':source['AHFWP']['url'],'title':'Issuer final FWP with explicit coupon dates,CUSIP,ISIN','section':source['AHFWP']['section']})
 (P/(code+'.json')).write_text(json.dumps(c,indent=2));contracts.append(c)
(P/'midamerican_additional_contracts.json').write_text(json.dumps({'contracts':contracts},indent=2))
pd.DataFrame(rows).to_csv(P/'verified_contractual_cashflows.csv',index=False)
for c in contracts:pd.DataFrame(c['verified_contractual_cashflows']).to_csv(P/(c['Code']+'_cashflows.csv'),index=False)
(P/'source_manifest_verified.json').write_text(json.dumps({k:{**v,'bytes':(S/v['file']).stat().st_size,'sha256':hashlib.sha256((S/v['file']).read_bytes()).hexdigest()} for k,v in source.items()},indent=2))
print(json.dumps([{'code':c['Code'],'coupon_dates':c['coupon_dates_mmdd'],'first_interest':c['first_coupon_amount_per100'],'final_interest':c['final_coupon_amount_per100'],'cashflows':c['contractual_schedule_rows'],'spread':c['mw_spread_bp']} for c in contracts],indent=2))
