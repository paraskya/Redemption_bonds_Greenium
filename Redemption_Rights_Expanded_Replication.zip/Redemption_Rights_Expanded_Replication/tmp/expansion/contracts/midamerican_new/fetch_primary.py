import urllib.request,json,pathlib,hashlib,concurrent.futures,time
from html.parser import HTMLParser
P=pathlib.Path('tmp/expansion/contracts/midamerican_new/sources')
targets={
 'AB_2002_prospectus':'https://www.sec.gov/Archives/edgar/data/928576/000095013602000310/file001.txt',
 'AB_2002_8k':'https://www.sec.gov/Archives/edgar/data/928576/000092857602000001/mec020802-8k.txt',
 'AE_2005_prospectus':'https://www.sec.gov/Archives/edgar/data/928576/000095013605006688/file001.htm',
 'AE_2005_8k':'https://www.sec.gov/Archives/edgar/data/928576/000108131605000124/mec-llc8k112005.htm',
 'AH_2006_prospectus':'https://www.sec.gov/Archives/edgar/data/928576/000095013606008350/file1.htm',
 'AH_2006_8k':'https://www.sec.gov/Archives/edgar/data/928576/000108131606000028/mecllc8k100601.htm'}
class Text(HTMLParser):
 def __init__(self):super().__init__();self.parts=[]
 def handle_data(self,data):self.parts.append(data)
 def handle_starttag(self,tag,attrs):
  if tag in ['p','div','br','tr','td']:self.parts.append('\n')
def fetch(item):
 name,url=item
 try:
  b=urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'Academic research research@example.com'}),timeout=45).read()
  ext=url.rsplit('.',1)[1];(P/(name+'.'+ext)).write_bytes(b)
  s=b.decode('utf-8','replace');h=Text();h.feed(s);(P/(name+'.plain.txt')).write_text('\n'.join(x.strip() for x in ''.join(h.parts).splitlines() if x.strip()))
  return {'name':name,'url':url,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'status':'downloaded'}
 except Exception as e:return {'name':name,'url':url,'status':'error','error':str(e)}
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:r=list(pool.map(fetch,targets.items()))
(P/'source_manifest.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2))
