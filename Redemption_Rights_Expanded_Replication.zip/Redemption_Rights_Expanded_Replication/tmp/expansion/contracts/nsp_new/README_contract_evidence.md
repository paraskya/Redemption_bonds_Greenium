# Three additional NSP-Minnesota conventional bonds

The normalized register is `new_normalized_contracts.json`; individual records are also supplied. Original register files were not changed.

| Source code | Coupon | Maturity | Redemption rights |
|---|---:|---|---|
| 665772BQ | 6.50% | 1 March 2028 | Explicitly nonredeemable before maturity for any reason; no sinking fund. |
| 665772CA | 5.25% | 15 July 2035 | Make-whole at Treasury +15 bp to actual maturity; no terminal par-call window. |
| 665772CB | 6.25% | 1 June 2036 | Make-whole at Treasury +15 bp to actual maturity; no terminal par-call window. |

## Identity and security

All three are first-mortgage bonds of the Minnesota entity, current CIK 1123852. The March 1998 instrument was issued by the predecessor now named Xcel Energy, CIK 72903. The July 2005 supplemental indenture recites the August 2000 assumption of mortgage liabilities by the current Minnesota subsidiary, and the Minnesota 2025 10-K lists all three bonds outstanding. The Wisconsin company, CIK 72909 and CUSIP family 665789, must not enter the same issuer curve.

The saved source universe dates BQ to 17 March 1998. Its original dated interest-accrual start is 1 March 1998, and coupons are paid each March/September. No 2008 issue date is supported. CA begins accruing on 21 July 2005 and first pays 15 January 2006; CB begins accruing on 25 May 2006 and first pays 1 December 2006. Both explicitly use twelve 30-day months.

## Contractual differences requiring engine support

BQ must bypass all redemption calculations and receive an exactly zero own option. It supplies a shorter conventional observation on the other side of the April 2031 green maturity.

CA and CB require the remaining principal and scheduled interest to actual maturity in the make-whole present value. Their original text then adds accrued interest after the par floor without expressly excluding accrued interest from the remaining-coupon present value. The register preserves this literal older formula as `mw_accrued_interest_mode=include_full_remaining_interest_then_add_accrued`. Applying a modern accrued-interest exclusion silently would change the contract. A conventional exclusion calculation, if wanted, is a separate sensitivity.

Both permit redemption at any time on at least 30 calendar days notice. The original supplements and restated indenture section 10.02 state no upper notice bound. Section 10.03 requires funding after completed notice. The primary Treasury fixing uses the most recently published H15 preceding-week average, calculated three business days before redemption. A comparable-security dealer-price fallback applies if that weekly information is missing. The remaining-term horizon is actual maturity. The dealer fallback uses 5 p.m. bid/ask quotes on the third business day, excluding the highest and lowest when at least four quotes are received.

## Conditional conventions still exposed

The reviewed older original instruments do not expressly state a coupon/principal holiday postponement rule. The register therefore declares following/no-extra-interest as a conditional pricing convention, together with a Federal Reserve calendar proxy for Chicago trustee bank closures. BQ's 30/360 day count remains a market-convention assumption pending a conclusive original provision. The original BQ prospectus is now recovered and confirms original accrual, first coupon, scheduled settlement and general corporate proceeds. It still supplies no explicit day-count or holiday-postponement clause. CB full CUSIP and ISIN are explicitly verified in its original underwriting term sheet. BQ and CA full CUSIPs remain corroborated by independent holder/rating disclosures rather than printed original issue certificates. BQ record-date wording differs between the prospectus summary (August 31) and original indenture (August 21); the register preserves the controlling indenture and records the discrepancy. Current price clean/dirty basis is not established by these contract documents. Reported outstanding amounts are as of 31 December 2025, not a continuous lifecycle audit.

## Main primary sources

- [BQ original March 1998 supplemental indenture, particularly sections 2.01 and 2.03](https://www.sec.gov/Archives/edgar/data/72903/000007290318000009/xcelex412sti03011998.htm).
- [CA original July 2005 supplemental indenture, including liability-assumption recitals and sections 2.01–2.02](https://www.sec.gov/Archives/edgar/data/1123852/000110465905032759/a05-12260_1ex4d01.htm).
- [CA original issue prospectus](https://www.sec.gov/Archives/edgar/data/1123852/000104746905019540/a2160959z424b2.htm).
- [CB original May 2006 supplemental indenture, sections 2.01–2.02](https://www.sec.gov/Archives/edgar/data/1123852/000110465906036653/a06-12391_1ex4d01.htm).
- [CB original issue prospectus](https://www.sec.gov/Archives/edgar/data/1123852/000104746906007473/a2170632z424b2.htm).
- [Restated mortgage indenture, sections 10.02–10.03](https://www.sec.gov/Archives/edgar/data/72903/000119312518121135/d570355dex4b3.htm).
- [Current Minnesota 2025 Form 10-K, debt note and exhibits 4.02–4.05](https://www.sec.gov/Archives/edgar/data/1123852/000112385226000003/nspm-20251231.htm).

Public-source bytes are retained beside the register. JSON provenance identifies which source supports each field; a match on company group name is never used to merge legal issuers.

- [BQ original March 1998 prospectus](https://www.sec.gov/Archives/edgar/data/72903/0001047469-98-009672.txt).
- [CB original underwriting agreement, Schedule III identifier term sheet](https://www.sec.gov/Archives/edgar/data/1123852/000110465906036653/a06-12391_1ex1d01.htm).
