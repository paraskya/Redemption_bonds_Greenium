"""Independent non-pricing checks for concrete multi-issuer convention risks."""
from pathlib import Path
import json,sys,collections
from datetime import date,timedelta
ROOT=Path(__file__).resolve().parents[3]
sys.path.insert(0,str(ROOT/'tmp/expansion/pricing'))
from expansion_data import adapt_contract
from expanded_pricer import ExpandedSchedule,BondPricer,NumericalSettings

raw=json.load(open(ROOT/'tmp/expansion/inventory/latest_conditional_contracts.json'))
cs=raw.get('contracts',raw)
valuation=date(2026,8,31)
results=[]
for c in cs:
 try:t=adapt_contract(c,valuation)
 except ValueError:continue
 schedule=object.__new__(ExpandedSchedule)
 BondPricer.__init__(schedule,t,None,valuation,valuation,NumericalSettings(train_paths=2,evaluation_paths=2,step_days=30))
 future_last={};direct_past=0
 for j,n in enumerate(schedule.dates):
  if not j:continue
  for r in schedule.redemption_candidates(n):
   if r>=t.par_call_date:continue
   obs=schedule.fixing_dates(n,r)
   direct_past+=any(s<=n for s in obs)
   for s in obs:
    if s>valuation:future_last[s]=max(future_last.get(s,-1),j)
 uncovered=[];maximum_relevant=0
 if t.expansion_metadata['fixing_relative_to']=='notice_date':
  for j,n in enumerate(schedule.dates):
   s=n;buffer=set()
   for _ in range(15):
    s-=timedelta(days=1)
    while not schedule.h15_business(s):s-=timedelta(days=1)
    buffer.add(s)
   relevant={s for s,last in future_last.items() if s<=n and last>=j}
   maximum_relevant=max(maximum_relevant,len(relevant))
   missing=relevant-buffer-{n}
   if missing:uncovered.append({'notice':str(n),'missing':sorted(map(str,missing))})
 results.append({'code':c['source_code'],'family':t.expansion_metadata['benchmark_family'],'fixing_relative_to':t.expansion_metadata['fixing_relative_to'],'direct_actions_with_past_fixings':direct_past,'maximum_relevant_past_dates':maximum_relevant,'history_15_lag_uncovered_nodes':len(uncovered),'examples':uncovered[:3]})
# After-16:15 daily-H15 at the Friday Good-Friday bank fixing rolls to Thursday.
c=next(c for c in cs if c['source_code']=='23338VAQ');t=adapt_contract(c,valuation)
s=object.__new__(ExpandedSchedule);BondPricer.__init__(s,t,None,valuation,valuation,NumericalSettings(train_paths=2,evaluation_paths=2,step_days=30))
obs=s.fixing_dates(date(2027,2,26),date(2027,3,31))
assert obs==(date(2027,3,25),),obs
# Before-notice weekly observation uses the week before the fixing week.
c=next(c for c in cs if c['source_code']=='29444UBL');t=adapt_contract(c,valuation)
s=object.__new__(ExpandedSchedule);BondPricer.__init__(s,t,None,valuation,valuation,NumericalSettings(train_paths=2,evaluation_paths=2,step_days=30))
obs2=s.fixing_dates(valuation,date(2026,9,15))
assert obs2==tuple(date(2026,8,17)+timedelta(days=k) for k in range(5)),obs2
out={'status':'passed' if not any(r['history_15_lag_uncovered_nodes'] for r in results) else 'history_coverage_failed','latest_contracts_checked':len(results),'past_fixing_contracts':sum(r['direct_actions_with_past_fixings']>0 for r in results),'pre_notice_history_coverage_contracts':sum(r['fixing_relative_to']=='notice_date' for r in results),'good_friday_daily_h15_observation':str(obs[0]),'equinix_before_notice_weekly_observations':list(map(str,obs2)),'rows':results}
(ROOT/'tmp/expansion/contracts/Schedule_Convention_Checks.json').write_text(json.dumps(out,indent=2))
print(json.dumps({k:v for k,v in out.items() if k!='rows'},indent=2))
print('Legacy weekly contracts with past fixings:',[r['code'] for r in results if r['direct_actions_with_past_fixings'] and r['fixing_relative_to']!='notice_date'])
