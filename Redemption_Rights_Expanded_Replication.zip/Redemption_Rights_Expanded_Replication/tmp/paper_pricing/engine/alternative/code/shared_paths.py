"""Common latent Gaussian paths for contracts and pricing kernels.

The shared process is (Y_7, I_B, I_Z).  All contracts see exactly the same
latent state at common calendar dates, including already-observed fixing
history.  Conventional and green discount integrals are I_B and I_B-I_Z.
This couples option differences; it does not remove policy/grid/model error.
"""
from functools import lru_cache
import numpy as np
from numpy.polynomial.legendre import leggauss
from scipy.linalg import expm
from dated_bond_pricer import years


def covariance_root(cov):
    cov=(np.asarray(cov)+np.asarray(cov).T)/2
    val,vec=np.linalg.eigh(cov)
    scale=max(float(np.max(abs(val))),1e-30)
    if val[0] < -1e-10*scale:
        raise ValueError('Shared covariance is not positive semidefinite')
    return (vec*np.sqrt(np.maximum(val,0)))@vec.T


class SharedPathGroup:
    def __init__(self,pricers):
        self.pricers=list(pricers)
        if not self.pricers: raise ValueError('No pricers supplied')
        self.model=self.pricers[0].model
        self.settings=self.pricers[0].settings
        self.valuation=self.pricers[0].valuation
        if self.model.nstate!=7: raise ValueError('Shared path group expects seven states')
        for p in self.pricers:
            for key in ('K','theta','omega','y0'):
                if not np.array_equal(getattr(p.model,key),getattr(self.model,key)):
                    raise ValueError(f'Contract models disagree on {key}')
            if p.settings!=self.settings or p.valuation!=self.valuation:
                raise ValueError('Shared simulations require identical numerics and valuation')
            p.shared_path_group=self
        self.simulation_dates=sorted(set(d for p in self.pricers for d in p.simulation_dates))
        self.completed=set()

    @lru_cache(None)
    def transition(self,t):
        m=self.model; n=7; d=9
        drift=np.zeros((d,d)); drift[:n,:n]=-m.K
        drift[7,:n]=[1,1,0,1,1,0,0]; drift[8,6]=1
        offset=np.r_[m.K@m.theta,0.,0.]
        ma=np.zeros((10,10)); ma[:d,:d]=drift; ma[:d,d]=offset
        e=expm(ma*t); phi=e[:d,:d]; gamma=e[:d,d]
        q=np.zeros((d,d)); q[:n,:n]=m.omega
        if np.linalg.norm(drift,ord=2)*t<25:
            vl=np.zeros((18,18)); vl[:d,:d]=drift; vl[:d,d:]=q; vl[d:,d:]=-drift.T
            raw=expm(vl*t); cov=raw[:d,d:]@phi.T
        else:
            nodes,weights=leggauss(64); cov=np.zeros((d,d))
            panels=max(1,int(np.ceil(np.linalg.norm(drift,ord=2)*t/15)))
            for panel in range(panels):
                for s,w in zip(t*(panel+(nodes+1)/2)/panels,weights):
                    es=expm(drift*s); cov+=w*t/(2*panels)*(es@q@es.T)
        return phi,gamma,covariance_root((cov+cov.T)/2)

    def simulate(self,training):
        if training in self.completed: return
        if training is True:
            count=self.settings.train_paths;offset=0
        elif training is False:
            count=self.settings.evaluation_paths;offset=1
        elif training=='validation':
            count=self.settings.validation_paths;offset=2
        else:raise ValueError('Unknown shared path set')
        rng=np.random.default_rng(self.settings.seed+offset)
        state=np.zeros((count,9)); state[:,:7]=self.model.y0
        maps=[]
        for p in self.pricers:
            p._base_paths[training]=np.empty((count,len(p.dates),8))
            p._base_history[training]=np.empty((count,len(p.history_dates),3))
            ni={}
            for j,d in enumerate(p.dates): ni.setdefault(d,[]).append(j)
            maps.append((p,ni,p.history_index))
        previous=self.valuation
        for s in self.simulation_dates:
            if s>previous:
                phi,gamma,root=self.transition(years(previous,s))
                state=state@phi.T+gamma+rng.standard_normal((count,9))@root.T
            for p,ni,hi in maps:
                for j in ni.get(s,()):
                    p._base_paths[training][:,j,:7]=state[:,:7]
                    p._base_paths[training][:,j,7]=state[:,7]-(state[:,8] if p.model.security=='green' else 0.)
                if s in hi: p._base_history[training][:,hi[s]]=state[:,:3]
            previous=s
        self.completed.add(training)

    def audit(self):
        """Check path identity at common dates, without creating new simulations."""
        p0=self.pricers[0]; maximum=0.; comparisons=0
        for training in self.completed:
            idx0={d:j for j,d in enumerate(p0.dates)}
            for p in self.pricers[1:]:
                for j,d in enumerate(p.dates):
                    if d in idx0:
                        maximum=max(maximum,float(np.max(abs(p._base_paths[training][:,j,:7]
                            -p0._base_paths[training][:,idx0[d],:7]))))
                        comparisons+=1
        return {'shared_latent_state_max_error':maximum,'common_date_comparisons':comparisons,
                'union_simulation_nodes':len(self.simulation_dates),
                'scope':'Exact Gaussian transition draws shared across contracts; finite exercise policy remains approximate.'}
