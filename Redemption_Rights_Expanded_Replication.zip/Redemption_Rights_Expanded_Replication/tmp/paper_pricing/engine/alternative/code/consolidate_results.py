"""Consolidate new pairs and reused GL results without rerunning pricing."""
from pathlib import Path
import csv,json,shutil
import numpy as np
from revised_pilot import read_contracts
from benchmark import CashflowBond,as_date
from joint_afns_model import JointAFNSModel
ROOT=Path(__file__).resolve().parent.parent

def write_csv(path,rows):
    if not rows:return
    with path.open('w',newline='') as f:
        fields=list(dict.fromkeys(k for row in rows for k in row))
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)

def direct_row(r,contracts):
    out={k:v for k,v in r.items() if k not in ['config','numerics','result','shared_path_audit','covariance_factor_audit']}
    out['candidate_green_state_fit_uses_this_green_quote']=r['candidate_type']=='common_state'
    out['candidate_green_state_fit_excludes_this_green_quote']=r['candidate_type']=='leave_one_green_out'
    out['observed_price_scoring_flag_scope']='Within this direct pricing/policy evaluation only. The all-four common-state fit uses all four green quotes; the leave-one-green-out fit excludes the quote being scored.'
    bond=CashflowBond.from_contract(contracts[r['green_code']]);date=as_date(r['valuation_date'])
    price=r['model_callable_dirty_per100'];h=1e-4
    derivative=(bond.yield_from_dirty(price+h,date)-bond.yield_from_dirty(price-h,date))/(2*h)
    out['model_callable_yield_conditional_MC_SE_bp']=abs(derivative)*r['option_MC_SE_per100']*1e4
    out['yield_MC_SE_scope']='Option Monte Carlo error propagated through the contractual YTM-price derivative, conditional on the externally fitted state and selected model/policy; candidate-state, quote, parameter, policy-selection and grid uncertainty excluded.'
    return out

def main():
    rs=read_contracts(ROOT/'inputs/verizon_reviewed_contracts.json')
    own=[];components=[];common=[];heldout=[];missing=[];checks=[]
    # GL was completed in the preceding driftless experiment. Frozen copies
    # are placed in reference_results by the packaging step for portability.
    for suffix,control in [('ES','GH'),('FL','FR'),('GL','GK'),('GP','GB')]:
      for resolution in ['primary','replication']:
        if suffix=='GL':p=ROOT/'reference_results'/f'GL_{resolution}_result.json'
        else:p=ROOT/'results'/f'{suffix}_{resolution}'/'result.json'
        if not p.exists():missing.append(str(p.relative_to(ROOT)));continue
        r=json.loads(p.read_text());g='92343V'+suffix;c='92343V'+control
        rb=r['bond_results'][g];rc=r['bond_results'][c]
        date=as_date(r['valuation_date']);bond=CashflowBond.from_contract(rs[g]);ts,cs=bond.cashflows(date)
        tau=float(ts[-1]);m=JointAFNSModel(r['config'],'green');b=-m.B(np.array([tau]))[0,6]/tau
        z=r['green_inversion']['z'];obs=next(x for x in r['price_components'] if x['code']==g)
        clean=obs.get('observed_clean_per100',obs.get('observed_P_PRICE'));dirty=obs.get('observed_dirty_per100',obs.get('observed_dirty'))
        near=r.get('near_control_decomposition',r.get('near_twin_decomposition'))
        own.append(dict(code=g,control_code=c,resolution=resolution,source_result=str(p.relative_to(ROOT)),
            month_label=r['month_label'],valuation_date=r['valuation_date'],maturity_date=rs[g]['maturity_date'],
            coupon_pct=rs[g]['coupon_pct'],observed_clean_per100=clean,observed_dirty_per100=dirty,
            final_payment_horizon_years=tau,conditional_green_state_bp=z*1e4,
            endpoint_conditional_zero_greenium_bp=z*b*1e4,
            own_green_option_per100=rb['option_value'],own_green_option_MC_SE_per100=rb['option_standard_error'],
            own_control_option_per100=rc['option_value'],own_control_option_MC_SE_per100=rc['option_standard_error'],
            option_equivalent_straight_dirty_target_per100=dirty+rb['option_value'],
            option_equivalent_straight_clean_target_per100=clean+rb['option_value'],
            negative_instantaneous_issuer_option_share=rb['share_option_value_from_negative_issuer_spread_at_notice'],
            negative_remaining_zero_spread_option_share=rb['share_option_value_from_negative_remaining_maturity_zero_spread_at_notice'],
            root_converged=r['green_inversion']['converged'],root_price_converged=r['green_inversion']['price_converged'],
            root_state_bracket_converged=r['green_inversion']['state_bracket_converged'],
            root_final_price_error_per100=rb['model_dirty']-dirty,
            raw_matched_yield_gap_bp=near.get('raw_matched_yield_gap_bp',near.get('raw_GL_against_GK_yield_difference_bp')),
            own_option_net_addback_bp=near.get('own_option_net_addback_bp',near.get('GK_own_option_net_addback_bp')),
            combined_coupon_maturity_standardization_bp=near['combined_coupon_maturity_standardization_bp'],
            control_anchored_standardized_straight_yield_gap_bp=near.get('control_anchored_standardized_straight_yield_gap_bp',near.get('GK_anchored_standardized_straight_yield_difference_bp')),
            selected_policy=rb['selected_policy'],seed=r['numerics']['seed'],
            training_paths=r['numerics']['train_paths'],validation_paths=r['numerics']['validation_paths'],evaluation_paths=r['numerics']['evaluation_paths'],
            zero_greenium_curve_shape_identified=False,production_option_estimate=False))
        for v in r['price_components']:
            code=v['code'];rr=r['bond_results'][code]
            clean_v=v.get('observed_clean_per100',v.get('observed_P_PRICE'))
            dirty_v=v.get('observed_dirty_per100',v.get('observed_dirty'))
            conv_v=v.get('conventional_straight_dirty_per100',v.get('conventional_straight_dirty'))
            components.append(dict(month_label=r['month_label'],valuation_date=r['valuation_date'],code=code,
                is_green=bool(rs[code]['is_green_source']),maturity_date=rs[code]['maturity_date'],coupon_pct=rs[code]['coupon_pct'],
                observed_clean_per100=clean_v,accrued_per100=dirty_v-clean_v,observed_dirty_per100=dirty_v,
                option_value_per100=rr['option_value'],option_MC_SE_per100=rr['option_standard_error'],
                option_equivalent_straight_observed_dirty_per100=dirty_v+rr['option_value'],
                option_equivalent_straight_observed_clean_per100=clean_v+rr['option_value'],
                conventional_straight_dirty_per100=conv_v,model_straight_dirty_per100=rr['straight_dirty'],
                model_callable_dirty_per100=rr['model_dirty'],model_price_residual_per100=rr['model_dirty']-dirty_v,
                negative_instantaneous_issuer_option_share=rr['share_option_value_from_negative_issuer_spread_at_notice'],
                negative_remaining_zero_spread_option_share=rr['share_option_value_from_negative_remaining_maturity_zero_spread_at_notice'],
                Q_notice_grid_issuer_negative_probability=rr['Q_notice_grid_probability_issuer_spread_ever_negative'],
                resolution=resolution,source_pair=suffix))
        checks.append(dict(code=g,resolution=resolution,root_converged=r['green_inversion']['converged'],
            abs_root_price_error_per100=abs(rb['model_dirty']-dirty),
            shared_latent_state_max_error=r['shared_path_audit']['shared_latent_state_max_error'],
            epsF=r['config']['epsF'],muZ=r['config']['muZ'],thetaZ=r['config']['thetaZ']))
      p=ROOT/'results'/f'{suffix}_common_state'/'common_state_result.json'
      if p.exists():
        r=json.loads(p.read_text());common.append(direct_row(r,rs))
      p=ROOT/'results'/f'{suffix}_common_state'/'leave_one_green_out_result.json'
      if p.exists():
        r=json.loads(p.read_text());heldout.append(direct_row(r,rs))
    write_csv(ROOT/'own_option_green_results.csv',own)
    write_csv(ROOT/'all_price_components.csv',components)
    write_csv(ROOT/'common_state_callable_prices.csv',common)
    write_csv(ROOT/'leave_one_green_out_callable_prices.csv',heldout)
    write_csv(ROOT/'numerical_validation.csv',checks)
    reps=[]
    for suffix in ['ES','FL','GL','GP']:
        a=next((r for r in own if r['code']=='92343V'+suffix and r['resolution']=='primary'),None)
        b=next((r for r in own if r['code']=='92343V'+suffix and r['resolution']=='replication'),None)
        if a and b:
            reps.append(dict(code=a['code'],primary_option_per100=a['own_green_option_per100'],
                replication_option_per100=b['own_green_option_per100'],
                option_replication_change_per100=b['own_green_option_per100']-a['own_green_option_per100'],
                primary_green_state_bp=a['conditional_green_state_bp'],replication_green_state_bp=b['conditional_green_state_bp'],
                primary_endpoint_zero_greenium_bp=a['endpoint_conditional_zero_greenium_bp'],
                replication_endpoint_zero_greenium_bp=b['endpoint_conditional_zero_greenium_bp'],
                endpoint_replication_change_bp=b['endpoint_conditional_zero_greenium_bp']-a['endpoint_conditional_zero_greenium_bp']))
    write_csv(ROOT/'independent_replication.csv',reps)
    summary=dict(primary_green_count=sum(r['resolution']=='primary' for r in own),
        replication_green_count=sum(r['resolution']=='replication' for r in own),
        common_state_green_count=len(common),leave_one_green_out_count=len(heldout),missing_case_files=missing,
        all_saved_roots_converged=all(r['root_converged'] for r in checks),
        max_abs_root_price_error_per100=max((r['abs_root_price_error_per100'] for r in checks),default=None),
        all_saved_epsF_exact_zero=all(r['epsF']==0 for r in checks),
        all_saved_green_reference_unchanged=all(r['muZ']==.1 and r['thetaZ']==0 for r in checks),
        scope='Latest-date conditional numerical experiment; conventional kernel not yet own-option outer-refitted; green process shape assumed; complete actual exercise terms in frozen input inventory.')
    summary.update(required_primary_and_direct_complete=summary['primary_green_count']==4 and len(common)==4 and len(heldout)==4,
        required_missing_primary_files=[p for p in missing if '_primary/' in p],
        optional_missing_replication_files=[p for p in missing if '_replication/' in p],
        completed_independent_seed_replication_codes=[r['code'] for r in reps],
        independent_seed_scope='Same path counts and numerical grid; GL reused from preceding experiment. Completed additional short-root replications are listed by code. No independent GP root or direct common/heldout seed replication is claimed.',
        all_direct_prices_use_supplied_state_without_quote_inversion=all(r.get('observed_green_price_used_in_pricing_or_policy') is False for r in common+heldout),
        common_state_callable_yield_RMSE_bp=float(np.sqrt(np.mean([r['model_callable_yield_residual_bp']**2 for r in common]))) if common else None,
        leave_one_green_out_callable_yield_RMSE_bp=float(np.sqrt(np.mean([r['model_callable_yield_residual_bp']**2 for r in heldout]))) if heldout else None,
        full_monthly_callable_panel_completed=False,conventional_own_option_outer_iteration_completed=False,
        production_option_calibration_accepted=False)
    (ROOT/'summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary))
if __name__=='__main__':main()
