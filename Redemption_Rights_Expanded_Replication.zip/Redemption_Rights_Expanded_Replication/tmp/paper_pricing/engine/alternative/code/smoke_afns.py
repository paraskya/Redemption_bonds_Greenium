from pathlib import Path
import sys,json,time
sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'treasury/code'))
from hull_white_contract_pricer import *
from afns_shifted_contract_pricer import AFNSContractPricer
from revised_pilot import read_contracts,contract_terms
from history_pricer import load_h15
from treasury_curves import TreasuryCurve
import argparse
ap=argparse.ArgumentParser();ap.add_argument('--bond',default='92343VGP');ap.add_argument('--train',type=int,default=192);ap.add_argument('--evaluation',type=int,default=576)
ap.add_argument('--source-root',default=str(Path(__file__).resolve().parents[2]/'previous'))
a=ap.parse_args();base=Path(a.source_root)/'pricing/inputs'
terms=contract_terms(read_contracts(base/'verizon_reviewed_contracts.json')[a.bond]);curve=TreasuryCurve('2026-08-31');cfg=json.loads((base/'selected_latest_config.json').read_text())
s=HWSettings(train_paths=a.train,evaluation_paths=a.evaluation)
p=AFNSContractPricer(terms,'2026-08-31',curve,cfg,s,load_h15(base/'treasury_daily_percent.csv'),progress=lambda a:print(json.dumps(a),flush=True))
print(json.dumps({'prepared':a.bond,'seconds':p.preparation_seconds,'bytes':p.cache_bytes(),'nodes':len(p.dates)}),flush=True)
S=lambda t:.01317*t-.01317*(-np.expm1(-.3*t))/.3
for z in [-.001,0.,.001]:
 print(json.dumps(p.price(S,lambda t:z*(-np.expm1(-.1*t))/.1)),flush=True)
