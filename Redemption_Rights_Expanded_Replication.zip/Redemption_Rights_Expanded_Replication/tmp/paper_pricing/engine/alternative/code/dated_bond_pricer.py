"""Dated corporate-bond valuation under the paper's joint AFNS kernels.

Analytic Gaussian transitions, moments and fixing tilts are combined with a
finite notice/exercise grid, Gauss-Hermite/Sobol integration and regression policies.
Those latter numerical approximations are not an exact American price.
The dealer/H.15 Treasury benchmark is explicitly proxied by a model par curve.
"""
from __future__ import annotations
import os
for _name in ('OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS'):
    os.environ[_name]='1'
from dataclasses import dataclass, field
from datetime import date, timedelta
from pathlib import Path
from functools import lru_cache
import calendar
import copy
import sys
import numpy as np
from numpy.polynomial.hermite import hermgauss
from pandas.tseries.holiday import USFederalHolidayCalendar, GoodFriday
from scipy.optimize import brentq, minimize_scalar
from scipy.stats import qmc, norm
from joint_afns_model import JointAFNSModel


def as_date(x): return x if isinstance(x,date) else date.fromisoformat(x)
def years(a,b): return (b-a).days/365.25

def thirty360(a,b):
    def lastfeb(d): return d.month==2 and (d+timedelta(days=1)).month!=2
    d1=30 if a.day==31 or lastfeb(a) else a.day
    d2=b.day
    if (d2==31 and d1>=30) or (lastfeb(b) and lastfeb(a)): d2=30
    return ((b.year-a.year)*360+(b.month-a.month)*30+d2-d1)/360

def add_months(d,n,end_of_month=False):
    m=d.year*12+d.month-1+n; y,mm=divmod(m,12); mm+=1
    day=calendar.monthrange(y,mm)[1] if end_of_month else min(d.day,calendar.monthrange(y,mm)[1])
    return date(y,mm,day)


class BusinessCalendar:
    """Explicit approximation to a US banking-business-day calendar."""
    def __init__(self,start,end,extra_holidays=()):
        self.holidays=set(USFederalHolidayCalendar().holidays(
            date(start.year-1,1,1),date(end.year+1,12,31)).date)
        self.holidays.update(as_date(x) for x in extra_holidays)
    def business(self,d): return d.weekday()<5 and d not in self.holidays
    def following(self,d):
        while not self.business(d): d+=timedelta(days=1)
        return d
    def preceding(self,d):
        while not self.business(d): d-=timedelta(days=1)
        return d
    def shift(self,d,n):
        step=1 if n>0 else -1
        for _ in range(abs(n)):
            d+=timedelta(days=step)
            while not self.business(d): d+=timedelta(days=step)
        return d


@dataclass
class BondTerms:
    name: str
    isin: str
    coupon: float
    maturity: date
    interest_start: date
    first_coupon: date
    par_call_date: date
    mw_spread_bp: float
    notice_min_days: int
    notice_max_days: int
    fixing_lag_business_days: int
    accrued_treatment: str
    security: str='conventional'
    frequency: int=2
    notional: float=100.
    currency: str='USD'
    day_count: str='30/360'
    call_start_date: date|None=None
    mw_reference_date: date|None=None
    benchmark_reference_date: date|None=None
    callable: bool=True
    fixing_rule: str='dealer Treasury quotations; model-par proxy used'
    benchmark_method: str='dealer_spot_par_proxy'
    h15_publication_lag_business_days: int=1
    treasury_rate_round_decimals: int|None=None
    redemption_price_round_decimals: int|None=None
    end_of_month: bool=False
    coupon_dates: tuple=()
    coupon_amounts: tuple=()
    first_coupon_amount: float|None=None
    extra_holidays: tuple=()
    sources: tuple=()
    assumptions: tuple=()

    def __post_init__(self):
        for key in ('maturity','interest_start','first_coupon','par_call_date'):
            setattr(self,key,as_date(getattr(self,key)))
        self.call_start_date=as_date(self.call_start_date) if self.call_start_date else self.interest_start
        self.mw_reference_date=as_date(self.mw_reference_date) if self.mw_reference_date else self.par_call_date
        self.benchmark_reference_date=(as_date(self.benchmark_reference_date)
            if self.benchmark_reference_date else self.mw_reference_date)
        if self.currency!='USD' or self.day_count!='30/360' or self.frequency not in (1,2,4):
            raise ValueError('This adapter supports USD, US30/360 and frequency1/2/4 only.')
        if self.accrued_treatment not in ('exclude_before_discount','subtract_after_discount'):
            raise ValueError('Specify the contractual accrued-interest treatment explicitly.')
        if not 0<=self.notice_min_days<=self.notice_max_days or self.fixing_lag_business_days<0:
            raise ValueError('Invalid notice/fixing terms')
        if self.benchmark_method not in ('dealer_spot_par_proxy','h15_weekly_2017','h15_daily_2023'):
            raise ValueError('Unknown Treasury benchmark method')
        if not self.interest_start<self.first_coupon<=self.maturity:
            raise ValueError('Invalid interest-start/first-coupon/maturity dates')
        if not self.interest_start<=self.par_call_date<=self.maturity:
            raise ValueError('Invalid par-call date')
        self.calendar=BusinessCalendar(self.interest_start,self.maturity,self.extra_holidays)
        if self.coupon_dates:
            dates=[as_date(x) for x in self.coupon_dates]
        else:
            months=12//self.frequency; dates=[]; k=0
            while True:
                d=add_months(self.first_coupon,k*months,self.end_of_month)
                if d>self.maturity: break
                dates.append(d);k+=1
            if dates[-1]!=self.maturity: dates.append(self.maturity)
        if dates!=sorted(set(dates)) or dates[0]!=self.first_coupon or dates[-1]!=self.maturity:
            raise ValueError('Coupon schedule must be ordered, start at first_coupon and end at maturity.')
        if self.coupon_amounts:
            coupons=np.asarray(self.coupon_amounts,float)
            if len(coupons)!=len(dates): raise ValueError('coupon_amounts length mismatch')
        else:
            coupons=np.full(len(dates),self.notional*self.coupon/self.frequency)
            coupons[0]=(self.first_coupon_amount if self.first_coupon_amount is not None else
                        self.notional*self.coupon*thirty360(self.interest_start,dates[0]))
            if len(dates)>1 and add_months(dates[-2],12//self.frequency,self.end_of_month)!=dates[-1]:
                coupons[-1]=self.notional*self.coupon*thirty360(dates[-2],dates[-1])
        self.contract_dates=tuple(dates)
        self.payment_dates=tuple(self.calendar.following(d) for d in dates)
        self.coupons=coupons
        self.principal=np.zeros(len(dates));self.principal[-1]=self.notional
        self.cashflows=self.coupons+self.principal
        ref=self.mw_reference_date
        before=[(d,float(c)) for d,c in zip(dates,coupons) if d<ref]
        if ref in dates:
            terminal_coupon=float(coupons[dates.index(ref)])
        else:
            previous=max([self.interest_start]+[d for d in dates if d<ref])
            terminal_coupon=self.notional*self.coupon*thirty360(previous,ref)
        self.mw_dates=tuple([d for d,_ in before]+[ref])
        self.mw_amounts=np.array([c for _,c in before]+[self.notional+terminal_coupon])

    @classmethod
    def from_dict(cls,config):
        return cls(**config)

    def accrued(self,d):
        d=as_date(d)
        previous=max([self.interest_start]+[x for x in self.contract_dates if x<=d])
        return self.notional*self.coupon*thirty360(previous,d)

    def dirty(self,quote,settlement,convention='clean'):
        if convention not in ('clean','dirty'): raise ValueError('Unknown quote convention')
        return float(quote)+(self.accrued(settlement) if convention=='clean' else 0.)

    def ytm(self,dirty,settlement):
        """Own-schedule nominal annual yield; not a provider-YTM assertion."""
        settlement=as_date(settlement)
        mask=np.array([p>settlement for p in self.payment_dates])
        exponent=np.array([self.frequency*thirty360(settlement,d)
                           for d,keep in zip(self.contract_dates,mask) if keep])
        flows=self.cashflows[mask]
        return float(brentq(lambda y:np.sum(flows*(1+y/self.frequency)**(-exponent))-dirty,
                            -.5,1.,xtol=1e-13))


@dataclass(frozen=True)
class NumericalSettings:
    train_paths: int=2000
    evaluation_paths: int=6000
    validation_paths: int=2400
    step_days: int=7
    notice_lags: tuple|None=None
    gh_order: int=3
    seed: int=20260924
    exercise_rule: str='frictionless'
    hbar: float=4.
    sigma_m: float=.01
    par_only: bool=False
    qmc_power: int=6
    paired_driver: bool=False
    sparse_policy: str='constant'


def features(y,gain):
    x=np.asarray(y)*100
    cross=[x[:,i]*x[:,j] for i in range(x.shape[1]) for j in range(i+1,x.shape[1])]
    return np.column_stack([x,x*x,*cross,gain,gain*gain])


def exercise_probability(m,rule,dt,hbar,sigma_m):
    if rule=='frictionless': return (m>0).astype(float)
    if rule!='bounded_intensity': raise ValueError('Unknown exercise rule')
    positive=np.maximum(m,0.);rate=hbar*positive**2/(sigma_m**2+positive**2)
    return -np.expm1(-rate*dt)


class BondPricer:
    """Fixed dynamics, reusable innovations, arbitrary current-state profiles."""
    def __init__(self,terms,model,valuation_date,settlement_date,settings=None):
        self.terms=terms;self.model=model;self.valuation=as_date(valuation_date)
        self.settlement=as_date(settlement_date);self.settings=settings or NumericalSettings()
        self.calendar=terms.calendar
        self.h15_extra_closed=set(GoodFriday.dates(
            date(self.valuation.year-1,1,1),date(terms.maturity.year+1,12,31)).date)
        if self.settlement<self.valuation or self.settlement>=terms.maturity:
            raise ValueError('Invalid settlement for this contract')
        if self.settings.step_days<1 or min(self.settings.train_paths,self.settings.evaluation_paths)<2:
            raise ValueError('Invalid numerical settings')
        if self.settings.gh_order<1 or self.settings.sigma_m<=0 or self.settings.hbar<0:
            raise ValueError('Invalid quadrature/intensity settings')
        self.lags=self.settings.notice_lags or tuple(sorted(set((terms.notice_min_days,
            (terms.notice_min_days+terms.notice_max_days)//2,terms.notice_max_days))))
        if any(x<terms.notice_min_days or x>terms.notice_max_days for x in self.lags):
            raise ValueError('A numerical notice candidate violates contractual notice bounds')
        self.notice_end=terms.maturity-timedelta(days=min(self.lags))
        self.dates=self.notice_grid()
        self.times=np.array([years(self.valuation,d) for d in self.dates])
        q,w=hermgauss(self.settings.gh_order)
        self.nodes=np.stack(np.meshgrid(q,q,q,indexing='ij'),axis=-1).reshape(-1,3)*np.sqrt(2)
        self.weights=np.einsum('i,j,k->ijk',w,w,w).ravel()/np.pi**1.5
        self._base_paths={};self._price_cache={};self._excluded_actions=set()

    def initial_state(self,initial_state=None,z=None):
        y=self.model.y0.copy() if initial_state is None else np.asarray(initial_state,float).copy()
        if y.shape!=(self.model.nstate,): raise ValueError('initial_state shape mismatch')
        if z is not None:
            if self.model.nstate!=7: raise ValueError('Green-state profiling requires seven states')
            y[6]=z
        return y

    def notice_grid(self):
        if not self.terms.callable: return [self.valuation]+([] if self.settlement==self.valuation else [self.settlement])
        days=set();d=self.settlement
        while d<self.notice_end:
            n=self.calendar.following(d)
            if n<self.notice_end: days.add(n)
            d+=timedelta(days=self.settings.step_days)
        for event in list(self.terms.payment_dates)+[self.calendar.following(self.terms.par_call_date)]:
            for lag in self.lags:
                n=event-timedelta(days=lag)
                for v in (self.calendar.preceding(n),self.calendar.following(n)):
                    if self.settlement<=v<self.notice_end: days.add(v)
        # A duplicate time-zero node permits notice at same-day settlement.
        return [self.valuation]+sorted(days)

    def redemption_candidates(self,n):
        ans=[];terms=self.terms
        for lag in self.lags:
            r=self.calendar.following(n+timedelta(days=lag))
            if (r-n).days>terms.notice_max_days:
                r=self.calendar.preceding(n+timedelta(days=terms.notice_max_days))
            if terms.notice_min_days<=(r-n).days<=terms.notice_max_days and r<terms.maturity and r>=terms.call_start_date:
                if not self.settings.par_only or r>=terms.par_call_date:
                    if r<terms.par_call_date and min(self.benchmark_observation_dates(r))<n:
                        self._excluded_actions.add((n,r))
                    else: ans.append(r)
        return sorted(set(ans))

    @lru_cache(None)
    def benchmark_observation_dates(self,r):
        f=self.calendar.shift(r,-self.terms.fixing_lag_business_days)
        if self.terms.benchmark_method=='h15_weekly_2017':
            monday=f-timedelta(days=f.weekday()+7)
            return tuple(monday+timedelta(days=i) for i in range(5)
                         if self.h15_business(monday+timedelta(days=i)))
        if self.terms.benchmark_method=='h15_daily_2023':
            obs=f
            for _ in range(self.terms.h15_publication_lag_business_days):
                obs-=timedelta(days=1)
                while not self.h15_business(obs): obs-=timedelta(days=1)
            return (obs,)
        return (f,)

    def h15_business(self,d):
        return self.calendar.business(d) and d not in self.h15_extra_closed

    def _simulate(self,n,seed):
        m=self.model;d=m.nstate;x=np.zeros((n,len(self.dates),d+1));x[:,0,:d]=m.y0
        rng=np.random.default_rng(seed)
        if d==7 and self.settings.paired_driver:
            raise ValueError('Joint pairing is implemented through HistoryBondPricer and SharedPathGroup in this package.')
        for j in range(1,len(self.dates)):
            phi,gamma,cov=m.transition(years(self.dates[j-1],self.dates[j]))
            val,vec=np.linalg.eigh(cov)
            if val.min()<-1e-13: raise ValueError('Non-PSD transition covariance')
            root=vec@np.diag(np.sqrt(np.maximum(val,0)))
            x[:,j]=x[:,j-1]@phi.T+gamma+rng.standard_normal((n,d+1))@root.T
        return x

    def paths(self,training,initial_state=None,z=None):
        if training not in self._base_paths:
            n=self.settings.train_paths if training else self.settings.evaluation_paths
            seed=self.settings.seed if training else self.settings.seed+1
            self._base_paths[training]=self._simulate(n,seed)
        base=self._base_paths[training]
        shift=self.initial_state(initial_state,z)-self.model.y0
        if not np.any(shift): return base
        effect=np.array([self.model.transition(float(t))[0][:,:self.model.nstate]@shift for t in self.times])
        return base+effect[None,:,:]

    def straight_at(self,n,state,delta=0.):
        mask=np.array([p>n for p in self.terms.payment_dates])
        tau=[years(n,p) for p,k in zip(self.terms.payment_dates,mask) if k]
        return self.model.discounts(state,tau,spread=delta)@self.terms.cashflows[mask]

    def breakdown(self,delta=0.,initial_state=None,z=None):
        y=self.initial_state(initial_state,z);mask=np.array([p>self.settlement for p in self.terms.payment_dates])
        tau=np.array([years(self.valuation,p) for p,k in zip(self.terms.payment_dates,mask) if k])
        settle_df=self.model.discounts(y,years(self.valuation,self.settlement),treasury=True)
        pt=self.model.discounts(y,tau,treasury=True)/settle_df
        pb=self.model.discounts(y,tau,spread=delta)/settle_df
        cf=self.terms.cashflows[mask];cp=self.terms.coupons[mask];principal=self.terms.principal[mask]
        return {'treasury_straight_dirty':float(cf@pt),'straight_dirty':float(cf@pb),
                'treasury_coupon_pv':float(cp@pt),'treasury_principal_pv':float(principal@pt),
                'selected_coupon_pv':float(cp@pb),'selected_principal_pv':float(principal@pb),
                'treasury_to_selected_adjustment':float(cf@(pt-pb)),
                'settlement_financing_factor':float(settle_df)}

    def straight(self,delta=0.,initial_state=None,z=None):
        return self.breakdown(delta,initial_state,z)['straight_dirty']

    @lru_cache(None)
    def fixing_setup(self,n,r):
        terms=self.terms;m=self.model;d=m.nstate
        f=self.calendar.shift(r,-terms.fixing_lag_business_days)
        if f<n: raise ValueError('Fixing precedes notice: extra observed-fixing state required')
        phi,gamma,cov=m.transition(years(n,f))
        cross=cov[:d,d]+cov[:d,:d]@m.B(years(f,r))
        val,vec=np.linalg.eigh(cov[:3,:3]);root=vec@np.diag(np.sqrt(np.maximum(val,0)))
        shifts=self.nodes@root.T+gamma[None,:3]-cross[None,:3]
        ref=terms.mw_reference_date;ref_dates=[];k=0
        while True:
            v=add_months(ref,-6*k,terms.end_of_month)
            if v<=f: break
            ref_dates.append(v);k+=1
        ref_dates=sorted(ref_dates)
        if not ref_dates: raise ValueError('No future make-whole benchmark horizon')
        horizons=tuple(years(f,x) for x in ref_dates)
        accr=np.array([thirty360(a,b) for a,b in zip([f]+ref_dates[:-1],ref_dates)])
        a,b=m.coeff(horizons,treasury=True)
        if np.max(abs(b[:,3:]),initial=0)>1e-12: raise ValueError('Treasury marginal is not autonomous')
        mask=np.array([x>r for x in terms.mw_dates]);amounts=terms.mw_amounts[mask].copy()
        if terms.accrued_treatment=='exclude_before_discount': amounts[0]-=terms.accrued(r)
        if amounts[0]<-1e-9: raise ValueError('Negative make-whole coupon after accrued exclusion')
        tau=np.array([thirty360(r,x) for x,k in zip(terms.mw_dates,mask) if k])
        return phi[:3,:d],shifts,a,b[:,:3],accr,amounts,tau

    @lru_cache(None)
    def h15_tenor_selection(self,r):
        """Published H.15 tenors, with explicit nearest-issue proxy for 2017."""
        months=np.array([1,3,6,12,24,36,60,84,120,240,360])
        ref=self.terms.benchmark_reference_date
        if self.terms.benchmark_method=='h15_daily_2023':
            days=np.array([(add_months(r,int(k))-r).days for k in months])
            remaining=(ref-r).days
            if remaining<=days[0]: return (int(months[0]),),(1.,)
            if remaining>=days[-1]: return (int(months[-1]),),(1.,)
            equal=np.flatnonzero(days==remaining)
            if len(equal): return (int(months[equal[0]]),),(1.,)
            hi=np.searchsorted(days,remaining);lo=hi-1
            w=(remaining-days[lo])/(days[hi]-days[lo])
            return (int(months[lo]),int(months[hi])),(1-w,w)
        remaining=years(r,ref)*12
        closest=int(np.argmin(abs(months-remaining)))
        if abs(months[closest]-remaining)<=3:
            return (int(months[closest]),),(1.,)
        remaining=np.floor(remaining+.5)
        ii=np.sort(np.argsort(abs(months-remaining),kind='stable')[:2])
        lo,hi=months[ii];w=(remaining-lo)/(hi-lo)
        return (int(lo),int(hi)),(1-w,w)

    @lru_cache(None)
    def cmt_coefficients(self,months):
        tau=months/12
        horizons=np.arange(.5,tau+.0000001,.5)
        if not len(horizons) or abs(horizons[-1]-tau)>1e-10:
            horizons=np.r_[horizons,tau]
        accr=np.diff(np.r_[0.,horizons])
        a,b=self.model.coeff(tuple(horizons),treasury=True)
        if np.max(abs(b[:,3:]),initial=0)>1e-12:
            raise ValueError('Treasury marginal is not autonomous')
        return a,b[:,:3],accr

    @lru_cache(None)
    def h15_fixing_setup(self,n,r):
        """Joint observation states under the selected redemption-forward tilt.

        Cov(Y_s,integral_n^r rho'Ydu)=Cov(Y_s,I_n^s)+Q_s B(r-s).
        Full-model covariance enters the tilt before projection to Treasury3.
        """
        m=self.model;d=m.nstate;dates=self.benchmark_observation_dates(r)
        if min(dates)<n: raise ValueError('Observed-history action must be excluded before pricing')
        transitions=[m.transition(years(n,s)) for s in dates]
        phis=np.stack([v[0][:3,:d] for v in transitions])
        means=np.array([g[:3]-c[:3,d]-c[:3,:d]@m.B(years(s,r))
                        for s,(_,g,c) in zip(dates,transitions)])
        joint=np.zeros((3*len(dates),3*len(dates)))
        for i,s in enumerate(dates):
            for j in range(i,len(dates)):
                p=m.transition(years(s,dates[j]))[0][:d,:d]
                block=(transitions[i][2][:d,:d]@p.T)[:3,:3]
                joint[3*i:3*i+3,3*j:3*j+3]=block
                joint[3*j:3*j+3,3*i:3*i+3]=block.T
        ev,vec=np.linalg.eigh((joint+joint.T)/2)
        if ev.min()<-1e-12: raise ValueError('Non-PSD joint weekly fixing covariance')
        root=(vec*np.sqrt(np.maximum(ev,0)))@vec.T
        if len(dates)==1:
            normals=self.nodes;weights=self.weights
        else:
            u=qmc.Sobol(d=3*len(dates),scramble=True,seed=self.settings.seed+731).random_base2(self.settings.qmc_power)
            normals=norm.ppf(np.clip(u,1e-12,1-1e-12));weights=np.full(len(u),1/len(u))
        shifts=(normals@root.T).reshape(-1,len(dates),3)+means[None,:,:]
        tenor_months,tenor_weights=self.h15_tenor_selection(r)
        coeffs=[self.cmt_coefficients(months) for months in tenor_months]
        mask=np.array([x>r for x in self.terms.mw_dates]);amounts=self.terms.mw_amounts[mask].copy()
        if self.terms.accrued_treatment=='exclude_before_discount': amounts[0]-=self.terms.accrued(r)
        tau=np.array([thirty360(r,x) for x,k in zip(self.terms.mw_dates,mask) if k])
        return phis,shifts,coeffs,np.array(tenor_weights),weights,amounts,tau

    def h15_commitment_expectation(self,n,r,state):
        phis,shifts,coeffs,tenor_weights,weights,amounts,tau=self.h15_fixing_setup(n,r)
        xf=np.einsum('nd,kid->nki',state,phis)[:,None,:,:]+shifts[None,:,:,:]
        rate=np.zeros(xf.shape[:2])
        for w,(a,b,accr) in zip(tenor_weights,coeffs):
            dfs=np.exp(a-xf@b.T)
            daily=(1-dfs[:,:,:,-1])/(dfs@accr)
            rate+=w*daily.mean(axis=2)
        terms=self.terms
        if terms.treasury_rate_round_decimals is not None:
            scale=10**terms.treasury_rate_round_decimals
            rate=np.floor(rate*100*scale+.5)/scale/100
        rate+=terms.mw_spread_bp/1e4
        if np.any(rate<=-2): raise ValueError('Make-whole nominal-discount domain reached')
        pv=np.exp(-2*tau[None,None,:]*np.log1p(rate[:,:,None]/2))@amounts
        if terms.accrued_treatment=='subtract_after_discount': pv-=terms.accrued(r)
        redemption=np.maximum(terms.notional,pv)
        if terms.redemption_price_round_decimals is not None:
            scale=10**terms.redemption_price_round_decimals
            redemption=np.floor(redemption/terms.notional*100*scale+.5)/scale*terms.notional/100
        return (redemption+terms.accrued(r))@weights

    def commitment(self,n,r,state,delta,H):
        terms=self.terms;m=self.model
        mask=np.array([n<p<=r for p in terms.payment_dates])
        tau=[years(n,p) for p,k in zip(terms.payment_dates,mask) if k]
        coupons=m.discounts(state,tau,spread=delta)@terms.cashflows[mask] if tau else np.zeros(len(state))
        p=m.discounts(state,[years(n,r)],spread=delta)[:,0]
        lower=coupons+p*(terms.notional+terms.accrued(r))
        if r>=terms.par_call_date: return lower
        possible=H>lower;cost=lower.copy()
        if not np.any(possible): return cost
        selected=np.flatnonzero(possible)
        if terms.benchmark_method!='dealer_spot_par_proxy':
            for start in range(0,len(selected),300):
                idx=selected[start:start+300]
                cost[idx]=coupons[idx]+p[idx]*self.h15_commitment_expectation(n,r,state[idx])
            return cost
        phi,shifts,a,b,accr,amounts,tau=self.fixing_setup(n,r)
        for start in range(0,len(selected),800):
            idx=selected[start:start+800];xf=(state[idx]@phi.T)[:,None,:]+shifts[None,:,:]
            dfs=np.exp(a[None,None,:]-xf@b.T)
            rate=(1-dfs[:,:,-1])/(dfs@accr)+terms.mw_spread_bp/1e4
            if np.any(rate<=-2): raise ValueError('Make-whole nominal-discount domain reached')
            pv=np.exp(-2*tau[None,None,:]*np.log1p(rate[:,:,None]/2))@amounts
            if terms.accrued_treatment=='subtract_after_discount': pv-=terms.accrued(r)
            redemption=np.maximum(terms.notional,pv)+terms.accrued(r)
            cost[idx]=coupons[idx]+p[idx]*(redemption@self.weights)
        return cost

    def exercise_gains(self,paths,delta):
        gains=np.zeros(paths.shape[:2]);actions=np.zeros(paths.shape[:2],dtype=np.int16)
        if not self.terms.callable: return gains,actions
        for j,n in enumerate(self.dates[1:],1):
            state=paths[:,j,:self.model.nstate];H=self.straight_at(n,state,delta)
            for r in self.redemption_candidates(n):
                gain=H-self.commitment(n,r,state,delta,H);better=gain>gains[:,j]
                gains[better,j]=gain[better];actions[better,j]=(r-n).days
        return gains,actions

    def _interval(self,j):
        return max(0.,years(self.dates[j],self.dates[j+1] if j+1<len(self.dates) else self.notice_end))

    @lru_cache(None)
    def regression_predictor_indices(self):
        """Drop deterministic coordinates before setting sparse-fit thresholds.

        A deterministic Z is constant across paths at any notice date. Counting
        it as a seventh random predictor changes the sparse-policy rule even at
        Z=0, when conventional and green kernels are identical. One-year state
        transition variance also retains factors driven indirectly by K.
        """
        dimension=6 if self.model.nstate==7 and self.model.security=='conventional' else self.model.nstate
        variance=np.diag(self.model.transition(1.)[2])[:dimension]
        tolerance=max(1e-24,float(np.max(variance,initial=0.))*1e-12)
        return tuple(int(i) for i in np.flatnonzero(variance>tolerance))

    def train(self,paths,gains,delta):
        d=self.model.nstate;D=np.exp(-paths[:,:,d]-delta*self.times[None,:])
        future=np.zeros(len(paths));fits=[None]*len(self.dates);settings=self.settings
        predictors=self.regression_predictor_indices();n_predictors=len(predictors)
        basis=1+2*n_predictors+n_predictors*(n_predictors-1)//2+2
        for j in range(len(self.dates)-1,0,-1):
            if j<len(self.dates)-1: future*=D[:,j+1]/D[:,j]
            itm=gains[:,j]>0
            if itm.sum()<max(25,2*basis):
                if settings.sparse_policy=='legacy_skip': continue
                if settings.sparse_policy!='constant': raise ValueError('Unknown sparse policy')
                # This fitted constant is available even when training has no ITM
                # paths; an independent evaluation can still exercise. In
                # particular terminal continuation is identically zero.
                cont=float(future[itm].mean() if np.any(itm) else future.mean())
                fits[j]=max(0.,cont)
                prob=exercise_probability((gains[itm,j]-cont)/self.terms.notional,
                    settings.exercise_rule,self._interval(j),settings.hbar,settings.sigma_m)
                idx=np.flatnonzero(itm);future[idx]=prob*gains[idx,j]+(1-prob)*future[idx]
                continue
            f=features(paths[itm,j][:,predictors],gains[itm,j]);center=f.mean(0);scale=f.std(0);scale[scale<1e-10]=1
            x=np.column_stack([np.ones(len(f)),(f-center)/scale])
            coef=np.linalg.lstsq(x,future[itm],rcond=1e-9)[0]
            cont=np.maximum(0.,x@coef)
            prob=exercise_probability((gains[itm,j]-cont)/self.terms.notional,
                settings.exercise_rule,self._interval(j),settings.hbar,settings.sigma_m)
            idx=np.flatnonzero(itm);future[idx]=prob*gains[idx,j]+(1-prob)*future[idx]
            fits[j]=(center,scale,coef)
        return fits

    def evaluate(self,paths,gains,actions,delta,fits,initial_state=None,z=None):
        d=self.model.nstate;D=np.exp(-paths[:,:,d]-delta*self.times[None,:]);settings=self.settings
        predictors=self.regression_predictor_indices()
        survival=np.ones(len(paths));values=np.zeros(len(paths));mass=[]
        for j in range(1,len(self.dates)):
            if fits[j] is None: continue
            mask=(survival>0)&(gains[:,j]>0)
            if not np.any(mask): continue
            if np.isscalar(fits[j]): cont=fits[j]
            else:
                center,scale,coef=fits[j];f=features(paths[mask,j][:,predictors],gains[mask,j])
                cont=np.maximum(0.,coef[0]+((f-center)/scale)@coef[1:])
            prob=exercise_probability((gains[mask,j]-cont)/self.terms.notional,
                settings.exercise_rule,self._interval(j),settings.hbar,settings.sigma_m)
            idx=np.flatnonzero(mask);weight=survival[idx]*prob
            if not np.any(weight): continue
            values[idx]+=weight*D[idx,j]*gains[idx,j];survival[idx]*=1-prob
            mass.append({'notice_date':str(self.dates[j]),'fraction':float(weight.mean()*len(weight)/len(paths)),
                         'mean_notice_days':float(weight@actions[idx,j]/weight.sum())})
        y=self.initial_state(initial_state,z)
        values/=self.model.discounts(y,years(self.valuation,self.settlement),treasury=True)
        return {'option_value':float(values.mean()),'option_standard_error':float(values.std(ddof=1)/np.sqrt(len(values))),
                'exercise_fraction':float(1-survival.mean()),'exercise_distribution':mass,'_option_samples':values}

    def price(self,delta=0.,initial_state=None,z=None,return_samples=False):
        y=self.initial_state(initial_state,z);key=(float(delta),tuple(y))
        if key not in self._price_cache:
            training=self.paths(True,y);evaluation=self.paths(False,y)
            gt,_=self.exercise_gains(training,delta);ge,ae=self.exercise_gains(evaluation,delta)
            fits=self.train(training,gt,delta)
            option=self.evaluate(evaluation,ge,ae,delta,fits,y)
            myopic=self.evaluate(evaluation,ge,ae,delta,[0.]*len(self.dates),y)
            # Perfect foresight over the implemented feasible exercise grid.
            # This bounds adapted policies for the same numerically integrated
            # gains, not the continuous contract or unrepresented actions.
            discounted_gains=ge*np.exp(-evaluation[:,:,self.model.nstate]
                                       -float(delta)*self.times[None,:])
            clairvoyant=np.max(discounted_gains,axis=1)/self.model.discounts(
                y,years(self.valuation,self.settlement),treasury=True)
            components=self.breakdown(delta,y);dirty=components['straight_dirty']-option['option_value']
            self._price_cache[key]={**components,**option,'model_dirty':dirty,
                'model_clean':dirty-self.terms.accrued(self.settlement),'accrued_interest':self.terms.accrued(self.settlement),
                'initial_state':y.tolist(),'issuer_delta':float(delta),'security_kernel':self.model.security,
                'actual_security_type':self.terms.security,'isin':self.terms.isin,'name':self.terms.name,
                'regression_stochastic_state_indices':list(self.regression_predictor_indices()),
                'ytm_callable':self.terms.ytm(dirty,self.settlement),
                'ytm_straight':self.terms.ytm(components['straight_dirty'],self.settlement),
                'myopic_option_value':myopic['option_value'],
                'myopic_option_standard_error':myopic['option_standard_error'],
                'feasible_grid_clairvoyant_upper_bound':float(clairvoyant.mean()),
                'feasible_grid_clairvoyant_standard_error':float(clairvoyant.std(ddof=1)/np.sqrt(len(clairvoyant))),
                'clairvoyant_bound_scope':'Perfect foresight over implemented feasible grid and numerically integrated commitment gains; excludes observation-history actions; not a bound for the full continuous contract.',
                'benchmark_method':self.terms.benchmark_method,
                'excluded_observation_before_notice_actions':len(self._excluded_actions),
                'numerical_notice_lags':list(self.lags),
                'minimum_feasible_notice_days':min([(r-n).days for n in self.dates[1:]
                    for r in self.redemption_candidates(n)],default=None),
                'benchmark_scope':'Model CMT par yields; H.15 publication fallback unmodeled. Weekly comparable issue uses closest published tenor with shorter tie. Observation-history actions excluded.',
                'scope':'Conditional joint-AFNS value; finite exercise policy, Gaussian moment formulas and numerical fixing integration; fixed dynamics not empirically reestimated here.'}
        result=self._price_cache[key].copy()
        if not return_samples: result.pop('_option_samples',None)
        return result


def fit_common_delta(pricers,observed_dirty,initial_states=None,weights=None,
                     bounds=(-.03,.15),iterations=3,tolerance=1e-7):
    """Common scalar fit with iterated own-option corrections, returning residuals.

    Each cheap scalar minimization holds the preceding option estimates fixed.
    This is a documented fixed-point calibration, not a proof of a unique joint
    optimum. The caller may independently optimize the final callable objective.
    """
    targets=np.asarray(observed_dirty,float);w=np.ones(len(targets)) if weights is None else np.asarray(weights,float)
    ys=[None]*len(pricers) if initial_states is None else initial_states
    options=np.zeros(len(pricers));trace=[];last=None
    for k in range(iterations):
        def objective(delta):
            residual=np.array([p.straight(delta,y) for p,y in zip(pricers,ys)])-options-targets
            return float(np.sum(w*residual**2))
        fit=minimize_scalar(objective,bounds=bounds,method='bounded',options={'xatol':1e-10})
        delta=float(fit.x);results=[p.price(delta,y) for p,y in zip(pricers,ys)]
        options=np.array([x['option_value'] for x in results]);residual=np.array([x['model_dirty'] for x in results])-targets
        trace.append({'iteration':k,'delta':delta,'residuals':residual.tolist(),'options':options.tolist()})
        if last is not None and abs(delta-last)<tolerance: break
        last=delta
    return {'issuer_delta':delta,'residuals':residual.tolist(),'weighted_price_sse':float(np.sum(w*residual**2)),
            'bond_results':results,'iterations':trace,'method':'Iterated fixed-option scalar least squares'}


def fit_green_z(pricer,observed_dirty,delta=0.,initial_state=None,bounds=(-.02,.02),xtol=1e-8):
    """Fit callable price, repricing/retraining the option at every trial state."""
    if pricer.model.security!='green' or pricer.terms.security!='green':
        raise ValueError('Actual green-bond Z calibration requires a green kernel and confirmed green terms')
    trace=[]
    def residual(z):
        result=pricer.price(delta,initial_state,z)
        error=result['model_dirty']-observed_dirty
        trace.append({'z':float(z),'price_residual':float(error),'option':result['option_value']})
        return error
    root=brentq(residual,*bounds,xtol=xtol)
    result=pricer.price(delta,initial_state,root)
    return {'green_initial_z':float(root),'price_residual':float(result['model_dirty']-observed_dirty),
            'bond_result':result,'evaluations':trace,
            'method':'Numerical callable-price root with endogenous policy reestimation; global uniqueness not asserted'}


def matched_yield_benchmark(green_pricer,green_dirty,conventional_pricers,conventional_dirty):
    """Maturity-interpolated raw yield benchmark, intentionally coupon-contaminated."""
    if len(conventional_pricers)!=2: raise ValueError('Exactly two conventional maturity brackets required')
    pairs=sorted(zip(conventional_pricers,conventional_dirty),key=lambda x:x[0].terms.maturity)
    times=np.array([years(p.settlement,p.terms.maturity) for p,_ in pairs])
    tg=years(green_pricer.settlement,green_pricer.terms.maturity)
    if not times[0]<=tg<=times[1] or times[0]==times[1]: raise ValueError('Conventional bonds do not bracket green maturity')
    ys=np.array([p.terms.ytm(v,p.settlement) for p,v in pairs]);wg=(tg-times[0])/(times[1]-times[0])
    yc=float((1-wg)*ys[0]+wg*ys[1]);yg=green_pricer.terms.ytm(green_dirty,green_pricer.settlement)
    return {'green_ytm':yg,'conventional_interpolated_ytm':yc,'raw_matched_greenium_bp':(yc-yg)*1e4,
            'conventional_ytms':ys.tolist(),'conventional_weights':[1-wg,wg],
            'scope':'Own-schedule nominal annual yields interpolated in remaining maturity; not provider OAS or a zero-coupon greenium'}
