"""Gaussian pricing model from the joint AFNS manuscript.

The constructor accepts observed/calibrated or explicitly specified parameters;
it estimates none.  Supported state orders are X=(L,S,C), (X,L_F),
(X,L_F,S_F,C_F), and (X,L_F,S_F,C_F,Z), with dimensions 3, 4, 6, 7.
Time is in years, states are annual decimal rates, and covariance is per year.
An issuer-specific constant spread stays external to the state and its integral.
"""
from __future__ import annotations

from functools import lru_cache
import json
from pathlib import Path
from typing import Mapping

import numpy as np
from numpy.polynomial.legendre import leggauss
from scipy.linalg import expm


def _number(config, name, *, positive=False, nonnegative=False):
    if name not in config:
        raise ValueError(f"Required model parameter {name!r} is missing")
    value = float(config[name])
    if not np.isfinite(value):
        raise ValueError(f"{name} must be finite")
    if positive and value <= 0:
        raise ValueError(f"{name} must be strictly positive")
    if nonnegative and value < 0:
        raise ValueError(f"{name} must be nonnegative")
    return value


def _psd(matrix, name):
    """Validate a symmetric PSD matrix; remove round-off eigenvalues only."""
    matrix = np.asarray(matrix, dtype=float)
    if not np.isfinite(matrix).all():
        raise ValueError(f"{name} contains nonfinite entries")
    scale = max(float(np.linalg.norm(matrix, ord=2)), 1e-30)
    tolerance = 256 * np.finfo(float).eps * len(matrix) * scale
    if np.max(np.abs(matrix - matrix.T)) > tolerance:
        raise ValueError(f"{name} must be symmetric")
    matrix = (matrix + matrix.T) / 2
    values, vectors = np.linalg.eigh(matrix)
    if values[0] < -tolerance:
        raise ValueError(f"{name} is not positive semidefinite: min eigenvalue {values[0]}")
    if values[0] < 0:
        matrix = (vectors * np.maximum(values, 0)) @ vectors.T
        matrix = (matrix + matrix.T) / 2
    return matrix


class JointAFNSModel:
    """Paper-restricted Gaussian affine model, including deterministic boundaries.

    Required config keys: ``lam``, ``y0``, ``covariance``; for dimensions 4/6/7,
    also ``epsF``, ``thetaLF``; for 6/7 also ``lamF``; for 7 also ``muZ``,
    ``thetaZ``. Additional provenance fields are retained without interpretation.
    Direct K/mean overrides are deliberately not accepted: K is built from the
    paper's restrictions. A seven-state conventional model has no Z rate loading.
    """

    treasury_indices = [0, 1, 2]

    def __init__(self, config: Mapping, security="conventional"):
        self.config = dict(config)
        self.security = security
        self.y0 = np.asarray(config["y0"], dtype=float).copy()
        if self.y0.ndim != 1 or len(self.y0) not in (3, 4, 6, 7):
            raise ValueError("y0 must be a vector of length 3, 4, 6 or 7")
        if not np.isfinite(self.y0).all():
            raise ValueError("y0 must be finite")
        self.nstate = len(self.y0)
        n = self.nstate
        if security not in ("conventional", "green", "treasury"):
            raise ValueError("security must be conventional, green or treasury")
        if security == "green" and n != 7:
            raise ValueError("The green security requires the seven-state model")
        self.lam = _number(config, "lam", positive=True)
        self.K = np.zeros((n, n))
        self.K[1, 1] = self.K[2, 2] = self.lam
        self.K[1, 2] = -self.lam
        self.theta = np.zeros(n)
        self.rho_treasury = np.zeros(n)
        self.rho_treasury[:2] = 1
        self.rho = self.rho_treasury.copy()
        if n >= 4:
            self.epsF = _number(config, "epsF", nonnegative=True)
            self.thetaLF = _number(config, "thetaLF")
            self.K[3, 3] = self.epsF
            self.theta[3] = self.thetaLF
            if security != "treasury":
                self.rho[3] = 1
        if n >= 6:
            self.lamF = _number(config, "lamF", positive=True)
            self.K[4, 4] = self.K[5, 5] = self.lamF
            self.K[4, 5] = -self.lamF
            if security != "treasury":
                self.rho[4] = 1
        if n == 7:
            self.muZ = _number(config, "muZ", positive=True)
            self.thetaZ = _number(config, "thetaZ")
            self.K[6, 6] = self.muZ
            self.theta[6] = self.thetaZ
            if security == "green":
                self.rho[6] = -1
        covariance = np.asarray(config["covariance"], dtype=float)
        if covariance.shape != (n, n):
            raise ValueError(f"covariance must have shape {(n, n)}")
        self.omega = _psd(covariance, "covariance")
        self.Omega = self.omega
        self.covariance = self.omega
        # Explicit overrides are checked, never allowed to alter the paper model.
        for key, expected in (("KQ", self.K), ("thetaQ", self.theta)):
            if key in config:
                supplied = np.asarray(config[key], dtype=float)
                if supplied.shape != expected.shape or not np.allclose(supplied, expected, rtol=1e-12, atol=1e-14):
                    raise ValueError(f"{key} conflicts with the paper's block restrictions")

    @classmethod
    def load(cls, path, security="conventional"):
        return cls(json.loads(Path(path).read_text()), security=security)

    @classmethod
    def from_treasury_parameters(cls, parameters):
        """Construct the exact three-state reduction from a Treasury calibration."""
        p = parameters if isinstance(parameters, Mapping) else json.loads(Path(parameters).read_text())
        return cls({"lam": p["lam"], "y0": p["y0"], "covariance": p["covariance"],
                    "provenance": p.get("methodology", "supplied Treasury parameters")})

    @staticmethod
    def _horizons(tau):
        t = np.asarray(tau, dtype=float)
        if not np.isfinite(t).all() or np.any(t < 0):
            raise ValueError("Pricing horizons must be finite and nonnegative")
        return t

    @staticmethod
    def _kernel(t, kappa):
        return t if kappa == 0 else -np.expm1(-kappa*t)/kappa

    def B(self, tau, treasury=False):
        t = self._horizons(tau)
        flat = t.reshape(-1)
        b = np.zeros((len(flat), self.nstate))
        bs = self._kernel(flat, self.lam)
        b[:, 0] = flat
        b[:, 1] = bs
        b[:, 2] = bs - flat*np.exp(-self.lam*flat)
        only_treasury = treasury or self.security == "treasury"
        if self.nstate >= 4 and not only_treasury:
            b[:, 3] = self._kernel(flat, self.epsF)
        if self.nstate >= 6 and not only_treasury:
            bfs = self._kernel(flat, self.lamF)
            b[:, 4] = bfs
            b[:, 5] = bfs - flat*np.exp(-self.lamF*flat)
        if self.security == "green" and not treasury:
            b[:, 6] = -self._kernel(flat, self.muZ)
        return b.reshape(t.shape + (self.nstate,))

    def A(self, tau, treasury=False):
        t = self._horizons(tau)
        flat = t.reshape(-1)
        # Split long horizons to resolve fast decays while retaining smooth
        # positive quadrature. Typical coupon horizons use one 48-node panel.
        rates = [self.lam]
        if self.nstate >= 4: rates += [self.epsF]
        if self.nstate >= 6: rates += [self.lamF]
        if self.nstate == 7: rates += [self.muZ]
        maxrate = max(rates)
        panels = max(1, int(np.ceil(float(np.max(flat, initial=0))*maxrate/20)))
        nodes, weights = leggauss(48)
        fractions = (np.arange(panels)[:, None]+(nodes[None, :]+1)/2)/panels
        v = flat[:, None, None]*fractions[None, :, :]
        b = self.B(v, treasury=treasury)
        variance = flat/(2*panels)*np.einsum("npqi,ij,npqj,q->n", b, self.omega, b, weights)
        rho = self.rho_treasury if treasury else self.rho
        mean = (self.B(flat, treasury=treasury)-flat[:, None]*rho)@self.theta
        result = mean + .5*variance
        return float(result[0]) if t.ndim == 0 else result.reshape(t.shape)

    @lru_cache(maxsize=1024)
    def _coeff_cached(self, horizons, treasury):
        a = np.asarray(self.A(np.array(horizons), treasury=treasury))
        b = self.B(np.array(horizons), treasury=treasury)
        a.setflags(write=False); b.setflags(write=False)
        return a, b

    def coeff(self, tuple_horizons, treasury=False):
        horizons = self._horizons(tuple_horizons)
        if horizons.ndim != 1:
            raise ValueError("coeff expects a one-dimensional sequence of horizons")
        return self._coeff_cached(tuple(float(x) for x in horizons), bool(treasury))

    def discounts(self, state, horizons, spread=0, treasury=False):
        """Return (..., horizon) prices for state of shape (..., nstate).

        Treasury prices ignore the external issuer spread. For corporate prices
        spread can be a scalar or an array broadcastable over the state batches.
        """
        state = np.asarray(state, dtype=float)
        if state.shape[-1] != self.nstate or not np.isfinite(state).all():
            raise ValueError("state must have finite entries and last dimension nstate")
        t = self._horizons(horizons)
        scalar = t.ndim == 0
        if t.ndim > 1:
            raise ValueError("discounts expects scalar or one-dimensional horizons")
        a, b = self.coeff(tuple(np.atleast_1d(t)), treasury=treasury)
        logprice = a-state@b.T
        if not (treasury or self.security == "treasury"):
            logprice = logprice-np.asarray(spread)[..., None]*np.atleast_1d(t)
        result = np.exp(logprice)
        return result[..., 0] if scalar else result

    def zcb(self, t, spread=0, treasury=False):
        return self.discounts(self.y0, t, spread=spread, treasury=treasury)

    def treasury_zcb(self, t):
        return self.zcb(t, treasury=True)

    @lru_cache(maxsize=256)
    def transition(self, t):
        """Exact augmented transition for (Y, I), dI=rho'Y dt.

        Return (Phi, gamma, Q) with mean Phi @ initial_aug + gamma.  The
        integrated issuer constant spread is external: add spread*t to I.
        The integral coordinate normally starts at zero for each interval.
        """
        t = float(self._horizons(t))
        n = self.nstate
        m = n+1
        drift = np.zeros((m, m))
        drift[:n, :n] = -self.K
        drift[n, :n] = self.rho
        offset = np.r_[self.K@self.theta, 0.]
        augmented = np.zeros((m+1, m+1))
        augmented[:m, :m] = drift
        augmented[:m, m] = offset
        mean_exp = expm(augmented*t)
        phi, gamma = mean_exp[:m, :m], mean_exp[:m, m]
        diffusion = np.zeros((m, m)); diffusion[:n, :n] = self.omega
        vanloan = np.zeros((2*m, 2*m))
        vanloan[:m, :m] = drift
        vanloan[:m, m:] = diffusion
        vanloan[m:, m:] = -drift.T
        # Very long intervals can lose accuracy through the growing block of
        # Van Loan's exponential. Positive Gaussian quadrature avoids cancellation.
        quadrature_needed = np.linalg.norm(drift, ord=2)*t > 25
        if not quadrature_needed:
            raw = expm(vanloan*t)
            covariance = raw[:m, m:]@phi.T
            covariance = (covariance+covariance.T)/2
            if not np.isfinite(covariance).all():
                quadrature_needed = True
            else:
                scale = max(np.linalg.norm(covariance, ord=2), 1e-30)
                quadrature_needed = np.linalg.eigvalsh(covariance)[0] < -1e-10*scale
        if quadrature_needed:
            q, w = leggauss(64)
            panels = max(1, int(np.ceil(np.linalg.norm(drift, ord=2)*t/15)))
            covariance = np.zeros((m, m))
            for panel in range(panels):
                times = t*(panel+(q+1)/2)/panels
                for s, weight in zip(times, w):
                    propagator = expm(drift*s)
                    covariance += weight*t/(2*panels)*(propagator@diffusion@propagator.T)
            covariance = (covariance+covariance.T)/2
        covariance = _psd(covariance, "augmented transition covariance")
        for item in (phi, gamma, covariance): item.setflags(write=False)
        return phi, gamma, covariance


def validation_checks():
    """Small deterministic checks of nesting, nonzero means and Gaussian pricing.

    Parameters below are test fixtures, not fitted spread parameters or an
    empirical Oracle scenario. Validation creates no pricing configuration.
    """
    from scipy.integrate import quad
    base = {"lam": .7, "y0": [.045, -.012, .003],
            "covariance": [[4e-5, 1e-5, 0], [1e-5, 9e-5, 2e-5], [0, 2e-5, 16e-5]]}
    three = JointAFNSModel(base)
    sixconfig = dict(base, y0=base["y0"]+[0., 0., 0.], epsF=.12,
                     lamF=.45, thetaLF=0., covariance=np.pad(base["covariance"], (0, 3)).tolist())
    six = JointAFNSModel(sixconfig)
    ts = np.array([0., .03, .5, 2.3, 9.])
    static_error = float(np.max(np.abs(three.zcb(ts, spread=.013)-six.zcb(ts, spread=.013))))
    # Deterministic spread dynamics have a closed-form integrated mean.
    fourconfig = dict(base, y0=base["y0"]+[.018], epsF=.35, thetaLF=.011,
                      covariance=np.pad(base["covariance"], (0, 1)).tolist())
    four = JointAFNSModel(fourconfig)
    integrated = .011*ts+(.018-.011)*four._kernel(ts, .35)
    deterministic_error = float(np.max(np.abs(four.zcb(ts)-three.zcb(ts)*np.exp(-integrated))))
    # Stochastic covariance and nonzero mean in all seven states.
    fixture = np.diag([.006, .009, .012, .003, .004, .005, .0006])
    fixture[3, 0] = -.0007; fixture[6, 1] = .0001
    sevenconfig = dict(base, y0=base["y0"]+[.014, -.002, .001, .0008], epsF=.15,
                       lamF=.4, thetaLF=.01, muZ=1.1, thetaZ=.0003,
                       covariance=(fixture@fixture.T).tolist())
    seven = JointAFNSModel(sevenconfig, security="green")
    a_errors=[]; gaussian_errors=[]; transition_errors=[]
    for t in [.02, .4, 2.1, 7.]:
        reference = (seven.B(t)-t*seven.rho)@seven.theta + .5*quad(lambda s:seven.B(s)@seven.omega@seven.B(s),0,t,epsabs=1e-13)[0]
        a_errors.append(abs(seven.A(t)-reference))
        phi,gamma,cov=seven.transition(t)
        initial=np.r_[seven.y0,0.]
        mean=phi@initial+gamma
        gaussian_price=np.exp(-mean[-1]+.5*cov[-1,-1])
        gaussian_errors.append(abs(gaussian_price-seven.zcb(t)))
        transition_errors.append(abs(phi[-1,:-1]-seven.B(t)).max())
    t=.73
    p1,g1,c1=seven.transition(t); p2,g2,c2=seven.transition(2*t)
    composition=max(float(np.max(abs(p2-p1@p1))),float(np.max(abs(g2-(p1@g1+g1)))),float(np.max(abs(c2-(p1@c1@p1.T+c1)))))
    report={"test_parameters":"Synthetic numerical test fixtures only; no empirical spread calibration",
            "static_three_vs_six_price_max_error":static_error,
            "deterministic_mean_reverting_spread_price_max_error":deterministic_error,
            "nonzero_mean_A_vs_adaptive_integral_max_error":float(max(a_errors)),
            "gaussian_integral_moment_vs_affine_price_max_error":float(max(gaussian_errors)),
            "integral_transition_loading_vs_B_max_error":float(max(transition_errors)),
            "transition_semigroup_max_error":composition,
            "treasury_loadings_outside_first_three_max":float(np.max(abs(seven.B(ts,treasury=True)[:,3:])))}
    for key,value in report.items():
        if key != "test_parameters" and value > 1e-10:
            raise AssertionError(f"Validation failed: {key}={value}")
    report["passed"]=True
    return report


if __name__ == "__main__":
    result=validation_checks()
    target=Path(__file__).with_name("joint_afns_model_check.json")
    target.write_text(json.dumps(result,indent=2))
    print(json.dumps(result,indent=2))
