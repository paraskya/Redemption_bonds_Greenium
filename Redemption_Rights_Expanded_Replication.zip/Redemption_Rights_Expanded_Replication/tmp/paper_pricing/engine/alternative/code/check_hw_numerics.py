from pathlib import Path
import sys,json,hashlib,time
import numpy as np
from scipy.integrate import quad
sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'treasury/code'))
from hull_white_contract_pricer import *
from revised_pilot import read_contracts,contract_terms
from history_pricer import load_h15
from treasury_curves import TreasuryCurve
import argparse
ROOT=Path(__file__).resolve().parents[1]
ap=argparse.ArgumentParser();ap.add_argument('--source-root',default=str(ROOT.parent/'previous'));args=ap.parse_args()
base=Path(args.source_root)/'pricing/inputs'
params=json.loads((ROOT/'results/hw_rate_parameters.json').read_text());a=params['a_Q'];sig=params['sigma_per_sqrt_year']
curve=TreasuryCurve('2026-08-31');m=HullWhiteCurveModel(curve,a,sig)
T=np.array([0.,.001,.1,1.,5.,10.,30.,65.]);P=m.discounts(0,T,np.array([0.]))[0]
errors={'initial_curve_max_abs_discount':float(np.max(abs(P-np.exp(curve.log_discount(T))))),'integrated_variance_quadrature_max_abs':0.,'fixing_covariance_quadrature_max_abs':0.}
for h in [.0001,.01,1.,10.,30.]:
 ref=quad(lambda u:sig**2*m.B(h-u)**2,0,h,epsabs=1e-13)[0]
 errors['integrated_variance_quadrature_max_abs']=max(errors['integrated_variance_quadrature_max_abs'],abs(ref-m.vi(h)))
for s,r in [(.01,.02),(.03,.16),(2.,5.)]:
 ref=quad(lambda u:sig**2*np.exp(-a*(s-u))*m.B(r-u),0,s,epsabs=1e-13)[0]
 got=m.cov_x_i(s)+m.vx(s)*m.B(r-s)
 errors['fixing_covariance_quadrature_max_abs']=max(errors['fixing_covariance_quadrature_max_abs'],abs(ref-got))
contracts=read_contracts(base/'verizon_reviewed_contracts.json');h15=load_h15(base/'treasury_daily_percent.csv')
fixtures=[]
for code in ['92343VES','92343VGP']:
 terms=contract_terms(contracts[code]);runs=[]
 for dtype in ['float32','float64']:
  p=HWContractPricer(terms,'2026-08-31',curve,a,sig,HWSettings(train_paths=64,evaluation_paths=128,cache_dtype=dtype),h15)
  S=lambda t:.01317*t-.01317*(-np.expm1(-.3*t))/.3
  r=p.price(S,lambda t:.001*(-np.expm1(-.1*t))/.1)
  runs.append(r)
  if dtype=='float64':
   # Direct CMT and make-whole interpolation comparisons at actual action dates.
   cmt_errors=[];mw_errors=[]
   for ai in np.linspace(0,len(p.actions)-1,min(12,len(p.actions))).astype(int):
    j,n,red,obs=p.actions[ai]
    if red>=terms.par_call_date:continue
    months,_=p.schedule.h15_tenor_selection(red)
    for ob in obs:
     if ob< p.valuation:continue
     t=years(p.valuation,ob)
     for mo in months:
      xs=np.linspace(-.07,.07,43)+.000133
      tau=mo/12.;hh=np.arange(.5,tau+1e-8,.5)
      if not len(hh) or abs(hh[-1]-tau)>1e-10:hh=np.r_[hh,tau]
      dfs=m.discounts(t,t+hh,xs);exact=(1-dfs[:,-1])/(dfs@np.diff(np.r_[0,hh]))
      cmt_errors.append(np.max(abs(p._cmt(ob,mo,xs)-exact)))
    mask=np.array([d>red for d in terms.mw_dates]);cash=terms.mw_amounts[mask].copy();cash[0]-=terms.accrued(red)
    tt=np.array([thirty360(red,d) for d,k in zip(terms.mw_dates,mask) if k]);rates=np.linspace(-.05,.15,51)+.000037
    exact=np.exp(-2*tt[None,:]*np.log1p(rates[:,None]/2))@cash
    mw_errors.append(np.max(abs(p._redemption_table(red)(rates)-exact)))
   fixtures.append({'code':code,'float32_minus_float64_callable_per100':runs[0]['model_dirty']-runs[1]['model_dirty'],
    'float32_minus_float64_option_per100':runs[0]['option_value']-runs[1]['option_value'],
    'CMT_interpolation_max_abs_yield_bp':float(max(cmt_errors)*1e4),
    'MW_smooth_PV_interpolation_max_abs_per100':float(max(mw_errors)),
    'numerics':p.settings.__dict__})
  del p
assert errors['initial_curve_max_abs_discount']<1e-12
assert errors['integrated_variance_quadrature_max_abs']<1e-12
assert errors['fixing_covariance_quadrature_max_abs']<1e-12
for f in fixtures:
 assert abs(f['float32_minus_float64_callable_per100'])<.0001
 assert f['CMT_interpolation_max_abs_yield_bp']<.02
 assert f['MW_smooth_PV_interpolation_max_abs_per100']<.0001
out={'analytic_checks':errors,'cache_and_interpolation_checks':fixtures,'passed':True,
 'scope':'Deterministic formula and cache/interpolation checks. Does not establish Monte Carlo policy or grid convergence.',
 'code_sha256':hashlib.sha256(Path(__file__).with_name('hull_white_contract_pricer.py').read_bytes()).hexdigest()}
(ROOT/'results/hw_numerical_checks.json').write_text(json.dumps(out,indent=2))
print(json.dumps(out,indent=2))
