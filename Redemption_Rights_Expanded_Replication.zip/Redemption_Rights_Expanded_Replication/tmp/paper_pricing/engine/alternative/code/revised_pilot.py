"""Fixed full-curve AFNS counterfactuals and GK-centered comparisons.

Issuer states come from the broad conventional curve and are never refit to
GK/BE here.  Green callable-price inversion recomputes the option policy.
Every baseline price uses the supplied signed Gaussian dynamics unchanged.
"""
from __future__ import annotations
import os
for _name in ('OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS'):
    os.environ[_name]='1'
import argparse
import csv
import json
import time
from pathlib import Path
from dataclasses import replace
import numpy as np
from scipy.optimize import brentq
from scipy.stats import norm
from benchmark import CashflowBond,as_date,years
from joint_afns_model import JointAFNSModel
from dated_bond_pricer import BondTerms,NumericalSettings
from history_pricer import HistoryBondPricer,load_h15
from shared_paths import SharedPathGroup
from policy_feedback import fixed_conventional_policy
from validated_policy import ValidationPolicyGreenPricer

HERE=Path(__file__).resolve().parent
REVISION=HERE.parent
DEFAULT_CONTRACTS=REVISION/'universe/verizon_reviewed_contracts.json'
DEFAULT_PRICES=REVISION/'universe/verizon_exact_issuer_monthly_prices.csv'
H15=HERE/'data/treasury_daily_percent.csv'
GREEN='92343VGL'; TWIN='92343VGK'; OLD='92343VBE'


def embed_config(config,mu_z=.1):
    out=dict(config); dim=len(config['y0'])
    if dim not in (4,6,7): raise ValueError('Expected 4-, 6- or 7-state configuration')
    cov=np.zeros((7,7)); cov[:dim,:dim]=config['covariance']
    y=np.zeros(7); y[:dim]=config['y0']
    out.update(covariance=cov.tolist(),y0=y.tolist())
    if dim<6: out.update(lamF=.1,spread_SF_CF_fixed_zero=True)
    if dim<7:
        out.update(muZ=mu_z,thetaZ=0.,green_diffusion_fixed_zero=True,green_Q_shape_assumed=True)
    return out


def read_contracts(path=DEFAULT_CONTRACTS):
    data=json.loads(Path(path).read_text())
    return {r['source_code']:r for r in data['contracts']}


def contract_terms(row):
    if row['currency']!='USD' or row['frequency']!=2:
        raise ValueError('Only verified USD semiannual contracts are implemented')
    if row['benchmark_family']!='US_Treasury_H15_preceding_week_average':
        raise ValueError('Unsupported make-whole fixing family')
    if not row.get('treasury_comparable_horizon_verified',False):
        raise ValueError('Treasury comparable horizon must be separately verified')
    return BondTerms(name=f"Verizon {row['coupon_pct']}% {row['maturity_date']}",
        isin=row.get('isin') or row['source_code'],coupon=row['coupon_pct']/100,
        maturity=row['maturity_date'],interest_start=row.get('interest_accrual_start_date',row['issue_date']),first_coupon=row['first_coupon_date'],
        par_call_date=row['par_call_date'] or row['maturity_date'],mw_spread_bp=row['mw_spread_bp'],
        notice_min_days=row['notice_min_days'],notice_max_days=row['notice_max_days'],
        fixing_lag_business_days=row.get('fixing_business_days_before',3),
        accrued_treatment='exclude_before_discount',security='green' if row['is_green_source'] else 'conventional',
        mw_reference_date=row['mw_cashflow_end_date'],benchmark_method='h15_weekly_2017',
        benchmark_reference_date=row['treasury_comparable_horizon_date'],
        sources=(row['source_url'],),assumptions=(
            'Original issue terms; outstanding-notice and lifecycle conditions not exhaustively verified.',
            'NYC banking calendar approximated with US federal holidays; H15 excludes Good Friday.',
            'Future published Treasury yields represented by model par yields; banker choice proxied by tenor rule.',
            'No outstanding notice; unconditional commitment and full redemption assumed.',
            'Maturity used internally as par-date sentinel when legal par call is absent.'))


def read_prices(path,month,codes):
    ans={}
    with open(path) as f:
        for r in csv.DictReader(f):
            if r['Date']==month and r['Code'] in codes and r['P_PRICE']:
                p=float(r['P_PRICE'])
                if p>0: ans[r['Code']]=p
    missing=set(codes)-ans.keys()
    if missing: raise ValueError(f'Missing positive prices: {sorted(missing)}')
    return ans


def load_config(path,month):
    data=json.loads(Path(path).read_text())
    if 'y0' in data: return data
    if isinstance(data,list): return next(x for x in data if x.get('month_label',x.get('month'))==month)
    if month in data: return data[month]
    if 'configs' in data: return next(x for x in data['configs'] if x.get('month_label')==month)
    return next(x for x in data.values() if isinstance(x,dict) and x.get('month_label')==month)


def numerical_root(pricer,target,state,price_tolerance=1e-5,state_tolerance=2e-7,max_evaluations=45):
    """Reprice callable value at every accepted trial; report both tolerances.

    The finite regression policy is discontinuous in its fitted parameters.
    Thus a root solver's success alone is not accepted as price convergence.
    """
    trace=[]; evaluated={}
    z0=float(brentq(lambda z:pricer.straight(initial_state=state,z=z)-target,-.05,.05,xtol=1e-13))
    def error(z):
        z=float(z)
        if z not in evaluated:
            if len(evaluated)>=max_evaluations: raise RuntimeError('Callable root evaluation budget reached')
            r=pricer.price(initial_state=state,z=z,return_samples=True)
            evaluated[z]=r
            trace.append({'evaluation':len(trace)+1,'z':z,'z_bp':z*1e4,
                'callable_price_error_per100':r['model_dirty']-target,
                'option_value_per100':r['option_value'],'option_MC_SE_per100':r['option_standard_error'],
                'selected_policy':r.get('selected_policy','green_trained'),
                'policy_validation':r.get('policy_validation')})
        return evaluated[z]['model_dirty']-target
    f0=error(z0)
    if abs(f0)<price_tolerance:
        left,right=z0-state_tolerance*.49,z0+state_tolerance*.49
        fl,fh=error(left),error(right)
        root=z0;half_width=(right-left)/2
        direct_bracket=fl<=0<=fh
        if not direct_bracket:
            # Price agreement alone is not a demonstrated state bracket.
            half_width=np.inf
    else:
        a=z0; fa=f0; width=max(2e-6,abs(f0)/max(pricer.straight(initial_state=state,z=z0+1e-5)
            -pricer.straight(initial_state=state,z=z0),1e-12)*1e-5*1.25)
        b=z0+width; fb=error(b)
        for _ in range(12):
            if fa*fb<=0: break
            width*=2; b=z0+width; fb=error(b)
        else: raise RuntimeError('No callable-price bracket found')
        # Safeguarded secant with an explicit evaluated bracket. Tight price
        # agreement is checked independently of the bracket width.
        for _ in range(max_evaluations):
            if len(evaluated)>=max_evaluations: break
            root=b-fb*(b-a)/(fb-fa) if fb!=fa else (a+b)/2
            if not a+.02*(b-a)<root<b-.02*(b-a): root=(a+b)/2
            fr=error(root)
            if abs(fr)<=price_tolerance and len(evaluated)+2<max_evaluations:
                left=max(a,root-state_tolerance*.49)
                right=min(b,root+state_tolerance*.49)
                fl,fh=error(left),error(right)
                if fl<=0<=fh:
                    a,fa,b,fb=left,fl,right,fh
                    # Preserve the interior near-root observation, which can
                    # have a smaller price error than either bracket endpoint.
                    if abs(fr)<min(abs(fl),abs(fh)):
                        if fr<=0: a,fa=root,fr
                        else: b,fb=root,fr
                    break
            if fr<=0: a,fa=root,fr
            else: b,fb=root,fr
            if b-a<=state_tolerance and min(abs(fa),abs(fb))<=price_tolerance: break
        root=min((a,b),key=lambda z:abs(error(z)))
        half_width=(b-a)/2
    final=evaluated[root]
    max_slope_error=abs(final['model_dirty']-target)
    return {'z':root,'result':final,'evaluations':trace,
        'state_tolerance_bp':state_tolerance*1e4,'price_tolerance_per100':price_tolerance,
        'final_bracket_width_bp':2*half_width*1e4 if np.isfinite(half_width) else None,
        'price_converged':max_slope_error<=price_tolerance,
        'state_bracket_converged':2*half_width<=state_tolerance,
        'converged':max_slope_error<=price_tolerance and 2*half_width<=state_tolerance,
        'evaluation_budget_exhausted':len(evaluated)>=max_evaluations,
        'method':'Safeguarded callable-price root with the full exercise-policy procedure repriced at each trial; direct bracket and price tolerances both required.'}


def stripped(result):
    return {k:v for k,v in result.items() if not k.startswith('_')}


def to_json(value):
    if isinstance(value,np.ndarray): return value.tolist()
    if isinstance(value,np.generic): return value.item()
    raise TypeError(type(value).__name__)


def run_case(month,config,settings,outdir,contracts_path=DEFAULT_CONTRACTS,
             prices_path=DEFAULT_PRICES,price_convention='clean',controls=(TWIN,OLD),
             mu_z=.1,contract_bridge=True,policy_feedback=True,history_path=H15,select_policy_on_validation=True,fixed_green_z=None):
    started=time.time(); outdir=Path(outdir); outdir.mkdir(parents=True,exist_ok=True)
    config=embed_config(config,mu_z)
    if float(config.get('issuer_delta',0.))!=0.:
        raise ValueError('Current validated-policy pilot expects supplied issuer_delta=0; a nonzero constant may not be ignored.')
    valuation=config.get('valuation_date',config.get('observation_date',month))
    date=as_date(valuation); records=read_contracts(contracts_path)
    codes=(GREEN,)+tuple(c for c in controls if c!=GREEN)
    terms={c:contract_terms(records[c]) for c in codes}
    bonds={c:CashflowBond.from_contract(records[c]) for c in codes}
    observed=read_prices(prices_path,month,codes)
    dirty={c:observed[c]+(terms[c].accrued(date) if price_convention=='clean' else 0.) for c in codes}
    h15=load_h15(history_path)
    pricers={c:(ValidationPolicyGreenPricer if c==GREEN and select_policy_on_validation else HistoryBondPricer)(t,JointAFNSModel(config,t.security),date,date,settings,h15_daily=h15)
        for c,t in terms.items()}
    pricers['GL_B']=HistoryBondPricer(terms[GREEN],JointAFNSModel(config,'conventional'),date,date,settings,h15_daily=h15)
    if select_policy_on_validation:pricers[GREEN].conventional_policy_pricer=pricers['GL_B']
    if contract_bridge and OLD in terms:
        synthetic=replace(terms[GREEN],name='Synthetic GL payments with BE-type rights',
            mw_spread_bp=terms[OLD].mw_spread_bp,notice_min_days=terms[OLD].notice_min_days,
            notice_max_days=terms[OLD].notice_max_days,par_call_date=terms[GREEN].maturity,
            mw_reference_date=terms[GREEN].maturity,benchmark_reference_date=terms[GREEN].maturity,security='conventional')
        pricers['GL_BE_RIGHTS']=HistoryBondPricer(synthetic,JointAFNSModel(config,'conventional'),date,date,settings,h15_daily=h15)
    shared=SharedPathGroup(pricers.values()); y=np.array(config['y0'])
    result={}
    for c,p in pricers.items():
        if c==GREEN: continue
        result[c]=p.price(initial_state=y,return_samples=True)
        print(json.dumps({'month':month,'code':c,'option':result[c]['option_value'],
            'elapsed_s':time.time()-started}),flush=True)
    inversion=numerical_root(pricers[GREEN],dirty[GREEN],y)
    y[6]=inversion['z']; result[GREEN]=inversion['result']
    fixed_green_result=None
    if fixed_green_z is not None:
        fixed_green_result=pricers[GREEN].price(initial_state=np.array(config['y0']),z=float(fixed_green_z),return_samples=True)
    H_Bg=result['GL_B']['straight_dirty']; C_Bg=result['GL_B']['option_value']; V_Bg=result['GL_B']['model_dirty']
    H_G=result[GREEN]['straight_dirty']; C_G=result[GREEN]['option_value']
    pi_call=dirty[GREEN]-V_Bg; pi_straight=dirty[GREEN]+C_G-H_Bg
    paired_samples=result[GREEN]['_option_samples']-result['GL_B']['_option_samples']
    section74={'conventional_straight_green_contract_per100':H_Bg,
        'conventional_option_green_contract_per100':C_Bg,
        'conventional_callable_green_contract_per100':V_Bg,
        'green_option_green_contract_per100':C_G,
        'observed_callable_premium_per100':pi_call,
        'observed_straight_equivalent_premium_per100':pi_straight,
        'same_contract_option_feedback_per100':C_G-C_Bg,
        'same_contract_option_feedback_paired_MC_SE_per100':float(paired_samples.std(ddof=1)/np.sqrt(len(paired_samples))),
        'price_identity_error_per100':pi_straight-pi_call-(C_G-C_Bg),
        'scope':'Paper Section 7.4 exact accounting identity for GL payments and redemption rights under both kernels; fitted green price error remains explicit.'}
    if policy_feedback:
        fixed=fixed_conventional_policy(pricers['GL_B'],pricers[GREEN],y)
        C_Gfixed=fixed['green_option_under_fixed_conventional_policy']
        kernel_samples=fixed['_green_option_samples']-fixed['_conventional_option_samples']
        response_samples=result[GREEN]['_option_samples']-fixed['_green_option_samples']
        section74.update(green_callable_value_under_fixed_conventional_policy_per100=H_G-C_Gfixed,
            green_option_under_fixed_conventional_policy_per100=C_Gfixed,
            fixed_policy_green_discounting_option_effect_per100=C_Gfixed-C_Bg,
            green_exercise_policy_response_per100=C_G-C_Gfixed,
            fixed_policy_effect_paired_MC_SE_per100=float(kernel_samples.std(ddof=1)/np.sqrt(len(kernel_samples))),
            exercise_response_paired_MC_SE_per100=float(response_samples.std(ddof=1)/np.sqrt(len(response_samples))),
            policy_reconciliation_error_per100=(C_G-C_Bg)-(C_Gfixed-C_Bg)-(C_G-C_Gfixed),
            conventional_policy_reproduction_error_per100=fixed['conventional_option_recomputed_under_conventional_policy']-C_Bg,
            fixed_policy_scope=fixed['scope'])
        response_se=section74['exercise_response_paired_MC_SE_per100']
        section74.update(green_policy_response_conditional_MC_z_score=(C_G-C_Gfixed)/response_se if response_se else None,
            feasible_conventional_policy_has_higher_evaluation_value=bool(C_G<C_Gfixed),
            policy_shortfall_exceeds_two_conditional_MC_SE=bool(C_G-C_Gfixed < -2*response_se))
    yg_obs=bonds[GREEN].yield_from_dirty(dirty[GREEN],date)
    yg_adj=bonds[GREEN].yield_from_dirty(dirty[GREEN]+C_G,date)
    ybg=bonds[GREEN].yield_from_dirty(H_Bg,date)
    decomposition={'full_curve_conditional_straight_yield_difference_bp':(ybg-yg_adj)*1e4,
        'full_curve_before_option_addback_yield_difference_bp':(ybg-yg_obs)*1e4,
        'green_own_option_yield_addback_effect_bp':(yg_obs-yg_adj)*1e4,
        'scope':'Fixed supplied full-curve state; change from a separately refitted zero-option curve is not calculated here.'}
    if TWIN in result:
        ck=result[TWIN]['option_value']; hk=result[TWIN]['straight_dirty']; vk=result[TWIN]['model_dirty']
        yk_obs=bonds[TWIN].yield_from_dirty(dirty[TWIN],date)
        yk_adj=bonds[TWIN].yield_from_dirty(dirty[TWIN]+ck,date)
        ybk=bonds[TWIN].yield_from_dirty(hk,date)
        synthetic_bond=replace(bonds[GREEN],coupon_pct=bonds[TWIN].coupon_pct)
        ts,cs=synthetic_bond.cashflows(date)
        h_synthetic=float(pricers['GL_B'].model.discounts(y,ts)@cs)
        y_synthetic=synthetic_bond.yield_from_dirty(h_synthetic,date)
        coupon=ybg-y_synthetic; maturity=y_synthetic-ybk
        raw=yk_obs-yg_obs; adjusted=yk_adj-yg_adj; standardized=adjusted+coupon+maturity
        model_gap=ybg-yg_adj
        callable_standardization=bonds[GREEN].yield_from_dirty(V_Bg,date)-bonds[TWIN].yield_from_dirty(vk,date)
        decomposition.update(raw_GL_against_GK_yield_difference_bp=raw*1e4,
            GK_own_option_adjusted_yield_difference_bp=adjusted*1e4,
            GK_anchored_standardized_straight_yield_difference_bp=standardized*1e4,
            pure_coupon_standardization_bp=coupon*1e4,
            maturity_schedule_standardization_bp=maturity*1e4,
            combined_coupon_maturity_standardization_bp=(coupon+maturity)*1e4,
            GK_own_option_net_addback_bp=(adjusted-raw)*1e4,
            GK_full_curve_yield_residual_bp=(ybk-yk_adj)*1e4,
            full_curve_minus_GK_anchor_bp=(model_gap-standardized)*1e4,
            GK_anchored_callable_standardized_yield_difference_bp=(raw+callable_standardization)*1e4,
            GK_callable_standardization_including_rights_bp=callable_standardization*1e4,
            near_twin_reconciliation_error_bp=(standardized-raw-(adjusted-raw)-coupon-maturity)*1e4,
            decomposition_order='First change GL coupon from 2.85% to GK 3.4% on GL payment dates; then change to GK maturity and schedule. Conventional curve held fixed.',
            excluded_GK_from_curve_fit=config.get('excluded_GK_from_curve_fit'))
    bridge=None
    if 'GL_BE_RIGHTS' in result:
        c_synthetic=result['GL_BE_RIGHTS']['option_value']; cb=result[OLD]['option_value']
        bridge={'BE_option_minus_GL_green_option_per100':cb-C_G,
            'cashflow_maturity_component_per100':cb-c_synthetic,
            'redemption_rights_component_on_GL_cashflows_per100':c_synthetic-C_Bg,
            'conventional_minus_green_kernel_same_contract_per100':C_Bg-C_G,
            'reconciliation_error_per100':cb-C_G-(cb-c_synthetic)-(c_synthetic-C_Bg)-(C_Bg-C_G),
            'synthetic_conventional_GL_option_BE_type_rights_per100':c_synthetic,
            'definition':'Synthetic GL coupon/principal dates; BE-type 30bp MW to GL maturity, no terminal par call, 30–60day notice. The remaining actual-BE minus synthetic difference is cashflow/maturity, not pure contractual rights.'}
    components=[]
    for c in codes:
        r=result[c]; conventional=H_Bg if c==GREEN else r['straight_dirty']
        components.append({'month_label':month,'valuation_date':str(date),'code':c,'observed_P_PRICE':observed[c],
            'price_basis_assumed':price_convention,'observed_dirty':dirty[c],
            'treasury_straight_dirty':r['treasury_straight_dirty'],'conventional_straight_dirty':conventional,
            'issuer_discount':r['treasury_straight_dirty']-conventional,
            'green_straight_component':r['straight_dirty']-conventional,
            'option_value':r['option_value'],'option_MC_SE':r['option_standard_error'],
            'model_dirty':r['model_dirty'],'model_clean':r['model_clean'],'accrued':r['accrued_interest'],
            'model_price_residual':r['model_dirty']-dirty[c],
            'Q_notice_grid_issuer_negative_probability':r['Q_notice_grid_probability_issuer_spread_ever_negative'],
            'Q_notice_grid_issuer_below_MW_probability':r['Q_notice_grid_probability_issuer_spread_ever_below_MW_spread'],
            'option_negative_issuer_share':r['share_option_value_from_negative_issuer_spread_at_notice'],
            'option_negative_selected_spread_share':r['share_option_value_from_negative_selected_spread_at_notice'],
            'option_negative_remaining_maturity_zero_spread_share':r['share_option_value_from_negative_remaining_maturity_zero_spread_at_notice'],
            'option_negative_same_cashflow_yield_spread_share':r['share_option_value_from_negative_same_cashflow_yield_spread_at_notice']})
    marginal=[]; loading=np.array([0,0,0,1,1,0,0.])
    for horizon in (1,5,10,15):
        phi,gamma,cov=pricers['GL_B'].model.transition(horizon)
        mean=float(loading@(phi[:7,:7]@y+gamma[:7])); sd=float(np.sqrt(max(0,loading@cov[:7,:7]@loading)))
        marginal.append({'years':horizon,'mean_issuer_LF_plus_SF_bp':mean*1e4,
            'sd_issuer_LF_plus_SF_bp':sd*1e4,'negative_probability':float(norm.cdf(-mean/sd)) if sd else float(mean<0),
            'below_GL_MW_probability':float(norm.cdf((.002-mean)/sd)) if sd else float(mean<.002)})
    out={'month_label':month,'valuation_date':str(date),'config':config,'numerics':settings.__dict__,
        'status':'provisional_numerical_diagnostic',
        'empirical_redemption_magnitudes_accepted':False,'full_60_month_refinement_run':False,
        'result_status':'provisional conditional numerical diagnostic; conventional curve is pre-option' if not config.get('option_adjustment_applied',False) else 'conditional numerical diagnostic under supplied dynamics',
        'production_option_estimate':False,'full_60_month_refinement_completed_in_this_run':False,
        'section74':section74,'near_twin_decomposition':decomposition,'BE_contract_bridge':bridge,
        'green_inversion':{k:v for k,v in inversion.items() if k!='result'},
        'final_initial_state':y.tolist(),'price_components':components,
        'marginal_total_issuer_spread':marginal,'shared_path_audit':shared.audit(),
        'bond_results':{c:stripped(r) for c,r in result.items()},'elapsed_seconds':time.time()-started,
        'assumptions':{'P_PRICE_basis':price_convention,'corporate_timestamp_verified':False,
            'settlement':'T+0 proxy','curve_state_refit_to_GK_BE':False,
            'no_spread_floor_inside_exercise':True,'green_conditional_Q_parameters_identified':False,
            'finite_policy_scope':'Refined finite notice grid, independent training/evaluation,32or more conditional fixing draws; simulation SE excludes grid,quadrature,policy andparameter uncertainty.'}}
    np.savez_compressed(outdir/'option_samples.npz',**{c:r['_option_samples'] for c,r in result.items()}, **({'GL_fixed_baseline_green_state':fixed_green_result['_option_samples']} if fixed_green_result is not None else {}))
    out['fixed_baseline_green_state_result']=stripped(fixed_green_result) if fixed_green_result is not None else None
    out['fixed_baseline_green_state']=fixed_green_z
    (outdir/'result.json').write_text(json.dumps(out,indent=2,default=to_json))
    with (outdir/'option_addbacks.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(components[0])); w.writeheader();w.writerows(components)
    print(json.dumps({'completed':str(outdir),'elapsed_s':out['elapsed_seconds'],'green_root_converged':inversion['converged']}),flush=True)
    return out


def main():
    p=argparse.ArgumentParser();p.add_argument('--month',default='2026-08-31');p.add_argument('--config',required=True)
    p.add_argument('--contracts',default=str(DEFAULT_CONTRACTS));p.add_argument('--prices',default=str(DEFAULT_PRICES))
    p.add_argument('--history',default=str(H15))
    p.add_argument('--output',required=True);p.add_argument('--train',type=int,default=1600)
    p.add_argument('--evaluation',type=int,default=6000);p.add_argument('--step',type=int,default=30)
    p.add_argument('--validation',type=int,default=2400)
    p.add_argument('--qmc-power',type=int,default=5);p.add_argument('--seed',type=int,default=20260925)
    p.add_argument('--price-convention',choices=('clean','dirty'),default='clean')
    p.add_argument('--controls',default=f'{TWIN},{OLD}');p.add_argument('--no-contract-bridge',action='store_true')
    p.add_argument('--no-policy-feedback',action='store_true')
    p.add_argument('--green-policy',choices=('validated_two_policy','single_green_trained'),default='validated_two_policy')
    p.add_argument('--mu-z',type=float,default=.1);a=p.parse_args()
    config=load_config(a.config,a.month)
    settings=NumericalSettings(train_paths=a.train,evaluation_paths=a.evaluation,validation_paths=a.validation,step_days=a.step,
        qmc_power=a.qmc_power,seed=a.seed,paired_driver=False)
    run_case(a.month,config,settings,a.output,a.contracts,a.prices,a.price_convention,
        tuple(filter(None,a.controls.split(','))),a.mu_z,not a.no_contract_bridge,not a.no_policy_feedback,a.history,a.green_policy=='validated_two_policy')

if __name__=='__main__': main()
