"""History-aware extension of the dated AFNS notice pricer.

Past H.15 observations are retained in the filtration. Observations already
published at valuation use the saved H.15 data; later observations use the
simulated AFNS par-curve proxy. This corrects the older adapter's exclusion of
valid short-notice actions. Exercise still uses a finite candidate grid and
an approximate regression policy; no continuous-exercise exactness is claimed.
"""
from __future__ import annotations
import csv
from datetime import timedelta
from functools import lru_cache
import numpy as np
from scipy.stats import qmc, norm
from dated_bond_pricer import (BondPricer, years, thirty360, features,
                               exercise_probability, as_date)

TENOR_FIELDS = {1:'DGS1MO',3:'DGS3MO',6:'DGS6MO',12:'DGS1',24:'DGS2',36:'DGS3',
                60:'DGS5',84:'DGS7',120:'DGS10',240:'DGS20',360:'DGS30'}


def load_h15(path):
    out = {}
    for row in csv.DictReader(open(path)):
        out[as_date(row['observation_date'])] = {
            m: float(row[k])/100 for m,k in TENOR_FIELDS.items()
            if row.get(k) not in (None,'','NA','.')}
    return out


class HistoryBondPricer(BondPricer):
    def __init__(self,*args,h15_daily=None,**kwargs):
        super().__init__(*args,**kwargs)
        from joint_afns_model import JointAFNSModel
        self._conventional_diagnostic_model=JointAFNSModel(self.model.config,'conventional')
        self.h15_daily = h15_daily or {}
        past_needed = set()
        self.history_actions = set()
        self.valuation_history_actions = set()
        for n in self.dates[1:]:
            for r in self.redemption_candidates(n):
                if r >= self.terms.par_call_date: continue
                for s in self.benchmark_observation_dates(r):
                    if s <= n:
                        self.history_actions.add((n,r))
                        if s <= self.valuation:
                            self.valuation_history_actions.add((n,r))
                        else:
                            past_needed.add(s)
        self.history_dates = sorted(past_needed)
        self.history_index = {s:i for i,s in enumerate(self.history_dates)}
        self.simulation_dates = sorted(set(self.dates)|past_needed)
        self._base_history = {}
        self._path_context = {}
        self._active_context = None
        self._selected_rows = None
        self._redemption_expectation_cache = {}

    def redemption_candidates(self,n):
        """Do not discard actions with an observed fixing component."""
        ans=[]; terms=self.terms
        for lag in self.lags:
            r=self.calendar.following(n+timedelta(days=lag))
            if (r-n).days>terms.notice_max_days:
                r=self.calendar.preceding(n+timedelta(days=terms.notice_max_days))
            if (terms.notice_min_days <= (r-n).days <= terms.notice_max_days
                and terms.call_start_date <= r < terms.maturity
                and (not self.settings.par_only or r >= terms.par_call_date)):
                ans.append(r)
        return sorted(set(ans))

    def _simulate_with_history(self,training):
        if hasattr(self,'shared_path_group'):
            self.shared_path_group.simulate(training)
            return
        if training is not True and training is not False:
            raise ValueError('Additional independent path cohorts require SharedPathGroup')
        m=self.model; d=m.nstate
        count=self.settings.train_paths if training else self.settings.evaluation_paths
        seed=self.settings.seed+(0 if training else 1)
        rng=np.random.default_rng(seed)
        state=np.zeros((count,d+1)); state[:,:d]=m.y0
        paths=np.zeros((count,len(self.dates),d+1))
        hist=np.zeros((count,len(self.history_dates),3))
        notice_index={}
        for j,n in enumerate(self.dates): notice_index.setdefault(n,[]).append(j)
        previous=self.valuation
        for s in self.simulation_dates:
            if s>previous:
                phi,gamma,cov=m.transition(years(previous,s))
                ev,vec=np.linalg.eigh(cov)
                if ev.min() < -1e-12: raise ValueError('Invalid transition covariance')
                root=vec*np.sqrt(np.maximum(ev,0))
                state=state@phi.T+gamma+rng.standard_normal((count,d+1))@root.T
            for j in notice_index.get(s,[]): paths[:,j]=state
            if s in self.history_index: hist[:,self.history_index[s]]=state[:,:3]
            previous=s
        self._base_paths[training]=paths
        self._base_history[training]=hist

    def paths(self,training,initial_state=None,z=None):
        if training not in self._base_paths: self._simulate_with_history(training)
        shift=self.initial_state(initial_state,z)-self.model.y0
        base=self._base_paths[training]
        if np.any(shift):
            effect=np.array([self.model.transition(float(t))[0][:,:self.model.nstate]@shift
                             for t in self.times])
            ans=base+effect[None,:,:]
        else: ans=base
        self._path_context[id(ans)]=(training,shift)
        return ans

    def exercise_gains(self,paths,delta):
        self._active_context=self._path_context[id(paths)]
        return super().exercise_gains(paths,delta)

    @lru_cache(None)
    def h15_fixing_setup(self,n,r):
        m=self.model; d=m.nstate
        all_dates=self.benchmark_observation_dates(r)
        future=tuple(s for s in all_dates if s>n)
        past=tuple(s for s in all_dates if s<=n)
        tenor_months,tenor_weights=self.h15_tenor_selection(r)
        coeffs=[self.cmt_coefficients(months) for months in tenor_months]
        if future:
            transitions=[m.transition(years(n,s)) for s in future]
            phis=np.stack([v[0][:3,:d] for v in transitions])
            means=np.array([g[:3]-c[:3,d]-c[:3,:d]@m.B(years(s,r))
                            for s,(_,g,c) in zip(future,transitions)])
            joint=np.zeros((3*len(future),3*len(future)))
            for i,s in enumerate(future):
                for j in range(i,len(future)):
                    p=m.transition(years(s,future[j]))[0][:d,:d]
                    block=(transitions[i][2][:d,:d]@p.T)[:3,:3]
                    joint[3*i:3*i+3,3*j:3*j+3]=block
                    joint[3*j:3*j+3,3*i:3*i+3]=block.T
            ev,vec=np.linalg.eigh((joint+joint.T)/2)
            if ev.min() < -1e-12: raise ValueError('Invalid fixing covariance')
            root=(vec*np.sqrt(np.maximum(ev,0)))@vec.T
            u=qmc.Sobol(d=3*len(future),scramble=True,
                        seed=self.settings.seed+731).random_base2(self.settings.qmc_power)
            normals=norm.ppf(np.clip(u,1e-12,1-1e-12))
            shifts=(normals@root.T).reshape(-1,len(future),3)+means[None,:,:]
            weights=np.full(len(u),1/len(u))
        else:
            phis=np.zeros((0,3,d)); shifts=np.zeros((1,0,3)); weights=np.ones(1)
        mask=np.array([x>r for x in self.terms.mw_dates])
        amounts=self.terms.mw_amounts[mask].copy()
        if self.terms.accrued_treatment=='exclude_before_discount': amounts[0]-=self.terms.accrued(r)
        if amounts.min() < -1e-9: raise ValueError('Negative make-whole cash flow')
        tau=np.array([thirty360(r,x) for x,k in zip(self.terms.mw_dates,mask) if k])
        return (future,past,phis,shifts,coeffs,np.array(tenor_weights),weights,amounts,tau,tenor_months)

    def _known_rate_sum(self,past,tenor_months,tenor_weights,coeffs,count):
        total=np.zeros(count)
        for s in past:
            if s<=self.valuation:
                if s not in self.h15_daily: raise ValueError(f'Missing historical H.15 date {s}')
                try:
                    total+=sum(w*self.h15_daily[s][tenor] for w,tenor in zip(tenor_weights,tenor_months))
                except KeyError as exc:
                    raise ValueError(f'Missing historical H.15 tenor at {s}') from exc
            else:
                training,shift=self._active_context
                x=self._base_history[training][self._selected_rows,self.history_index[s],:].copy()
                x+=self.model.transition(years(self.valuation,s))[0][:3,:self.model.nstate]@shift
                for w,(a,b,accr) in zip(tenor_weights,coeffs):
                    df=np.exp(a-x@b.T)
                    total+=w*(1-df[:,-1])/(df@accr)
        return total

    def h15_commitment_expectation(self,n,r,state):
        # The Treasury marginal is autonomous in the paper's block restriction.
        # Thus, for fixed dynamics and a fixed simulated path, changing only the
        # initial issuer or green state cannot change the conditional make-whole
        # amount. Cache by Treasury initial shift, path set and action. Corporate
        # discounting and the exercise policy are still recomputed at every fit.
        training,shift=self._active_context
        key=(training,n,r,tuple(shift[:3]))
        if key not in self._redemption_expectation_cache:
            self._redemption_expectation_cache[key]=np.full(len(self._base_paths[training]),np.nan)
        saved=self._redemption_expectation_cache[key]
        rows=self._selected_rows.copy()
        missing=np.isnan(saved[rows])
        if np.any(missing):
            self._selected_rows=rows[missing]
            saved[rows[missing]]=self._h15_commitment_uncached(n,r,state[missing])
            self._selected_rows=rows
        return saved[rows].copy()

    def _h15_commitment_uncached(self,n,r,state):
        future,past,phis,shifts,coeffs,tw,weights,amounts,tau,tenors=self.h15_fixing_setup(n,r)
        known=self._known_rate_sum(past,tenors,tw,coeffs,len(state))
        rate=np.repeat(known[:,None],len(weights),axis=1)
        if future:
            xf=np.einsum('nd,kid->nki',state,phis)[:,None,:,:]+shifts[None,:,:,:]
            for w,(a,b,accr) in zip(tw,coeffs):
                df=np.exp(a-xf@b.T)
                daily=(1-df[:,:,:,-1])/(df@accr)
                rate+=w*daily.sum(axis=2)
        rate/=len(past)+len(future)
        terms=self.terms
        if terms.treasury_rate_round_decimals is not None:
            scale=10**terms.treasury_rate_round_decimals
            rate=np.floor(rate*100*scale+.5)/scale/100
        rate+=terms.mw_spread_bp/1e4
        if np.any(rate<=-2): raise ValueError('Invalid make-whole discount domain')
        pv=np.exp(-2*tau[None,None,:]*np.log1p(rate[:,:,None]/2))@amounts
        if terms.accrued_treatment=='subtract_after_discount': pv-=terms.accrued(r)
        redemption=np.maximum(terms.notional,pv)
        if terms.redemption_price_round_decimals is not None:
            scale=10**terms.redemption_price_round_decimals
            redemption=np.floor(redemption/terms.notional*100*scale+.5)/scale*terms.notional/100
        return (redemption+terms.accrued(r))@weights

    def commitment(self,n,r,state,delta,H):
        terms=self.terms; m=self.model
        mask=np.array([n<p<=r for p in terms.payment_dates])
        tau=[years(n,p) for p,k in zip(terms.payment_dates,mask) if k]
        coupons=m.discounts(state,tau,spread=delta)@terms.cashflows[mask] if tau else np.zeros(len(state))
        p=m.discounts(state,[years(n,r)],spread=delta)[:,0]
        lower=coupons+p*(terms.notional+terms.accrued(r))
        if r>=terms.par_call_date: return lower
        selected=np.flatnonzero(H>lower); cost=lower.copy()
        for start in range(0,len(selected),160):
            idx=selected[start:start+160]
            self._selected_rows=idx
            cost[idx]=coupons[idx]+p[idx]*self.h15_commitment_expectation(n,r,state[idx])
        return cost

    def evaluate(self,paths,gains,actions,delta,fits,initial_state=None,z=None):
        """Independent policy evaluation plus pathwise spread diagnostics."""
        d=self.model.nstate; D=np.exp(-paths[:,:,d]-delta*self.times[None,:]); settings=self.settings
        predictors=self.regression_predictor_indices()
        survival=np.ones(len(paths)); values=np.zeros(len(paths)); negative=np.zeros(len(paths)); mass=[]
        negative_green=np.zeros(len(paths)); negative_tenor=np.zeros(len(paths)); negative_cashflows=np.zeros(len(paths))
        tenor_weighted_spread=np.zeros(len(paths))
        for j in range(1,len(self.dates)):
            if fits[j] is None: continue
            mask=(survival>0)&(gains[:,j]>0)
            if not np.any(mask): continue
            if np.isscalar(fits[j]): cont=fits[j]
            else:
                center,scale,coef=fits[j]; f=features(paths[mask,j][:,predictors],gains[mask,j])
                cont=np.maximum(0.,coef[0]+((f-center)/scale)@coef[1:])
            prob=exercise_probability((gains[mask,j]-cont)/self.terms.notional,
                                     settings.exercise_rule,self._interval(j),settings.hbar,settings.sigma_m)
            idx=np.flatnonzero(mask); weight=survival[idx]*prob
            if not np.any(weight): continue
            contribution=weight*D[idx,j]*gains[idx,j]
            spread=paths[idx,j,3]+delta
            if d>=6: spread+=paths[idx,j,4]
            green_spread=spread-(paths[idx,j,6] if d==7 and self.model.security=='green' else 0.)
            values[idx]+=contribution
            negative[idx]+=contribution*(spread<0)
            negative_green[idx]+=contribution*(green_spread<0)
            # Instantaneous LF+SF can be negative while the remaining-horizon
            # issuer curve is positive because curvature enters future spreads.
            # Report the discount-kernel term spread and an exact same-cashflow
            # PV ordering sign, without interpreting spot spread as borrowing YTM.
            diagnostic=self._conventional_diagnostic_model
            remaining=years(self.dates[j],self.terms.maturity)
            state=paths[idx,j,:d]
            ab,bb=diagnostic.coeff((remaining,)); at,bt=diagnostic.coeff((remaining,),treasury=True)
            tenor_spread=((at-ab)+state@(bb-bt).T)[:,0]/remaining+delta
            negative_tenor[idx]+=contribution*(tenor_spread<0)
            tenor_weighted_spread[idx]+=contribution*tenor_spread
            cash_mask=np.array([p>self.dates[j] for p in self.terms.payment_dates])
            horizons=[years(self.dates[j],p) for p,k in zip(self.terms.payment_dates,cash_mask) if k]
            promised=self.terms.cashflows[cash_mask]
            hb=diagnostic.discounts(state,horizons,spread=delta)@promised
            ht=diagnostic.discounts(state,horizons,treasury=True)@promised
            negative_cashflows[idx]+=contribution*(hb>ht)
            survival[idx]*=1-prob
            mass.append({'notice_date':str(self.dates[j]),'fraction':float(weight.sum()/len(paths)),
                         'mean_notice_days':float(weight@actions[idx,j]/weight.sum())})
        y=self.initial_state(initial_state,z)
        df=self.model.discounts(y,years(self.valuation,self.settlement),treasury=True)
        values/=df; negative/=df; negative_green/=df;negative_tenor/=df;negative_cashflows/=df;tenor_weighted_spread/=df
        spread_grid=paths[:,:,3]+delta
        if d>=6: spread_grid=spread_grid+paths[:,:,4]
        threshold=self.terms.mw_spread_bp/1e4
        return {'option_value':float(values.mean()),
                'option_standard_error':float(values.std(ddof=1)/np.sqrt(len(values))),
                'exercise_fraction':float(1-survival.mean()),'exercise_distribution':mass,'_option_samples':values,
                'Q_notice_grid_probability_issuer_spread_ever_negative':float(np.mean(spread_grid.min(axis=1)<0)),
                'Q_negative_grid_probability_includes_initial_observation':True,
                'initial_effective_issuer_short_spread_bp':float((y[3]+(y[4] if d>=6 else 0.)+delta)*1e4),
                'negative_grid_first_passage_from_positive_initial_state':bool(y[3]+(y[4] if d>=6 else 0.)+delta>=0),
                'Q_notice_grid_probability_issuer_spread_ever_below_MW_spread':float(np.mean(spread_grid.min(axis=1)<threshold)),
                'option_value_from_negative_issuer_spread_at_notice_per100':float(negative.mean()),
                'share_option_value_from_negative_issuer_spread_at_notice':float(negative.sum()/values.sum()) if values.sum()>0 else None,
                'share_option_value_from_negative_selected_spread_at_notice':float(negative_green.sum()/values.sum()) if values.sum()>0 else None,
                'share_option_value_from_negative_remaining_maturity_zero_spread_at_notice':float(negative_tenor.sum()/values.sum()) if values.sum()>0 else None,
                'share_option_value_from_negative_same_cashflow_yield_spread_at_notice':float(negative_cashflows.sum()/values.sum()) if values.sum()>0 else None,
                'option_value_weighted_remaining_maturity_zero_spread_bp':float(tenor_weighted_spread.sum()/values.sum()*1e4) if values.sum()>0 else None,
                'remaining_spread_scope':'Conventional-versus-Treasury zero-yield spread to actual remaining maturity. Same-cashflow negative yield-spread sign is identified exactly by H_B>H_T for identical positive remaining payments; no borrowing/transaction spread is observed.',
                'negative_spread_scope':'Issuer LF+SF+constant spread at chosen notice; Z excluded. Grid crossing is not continuous first-passage probability.',
                'share_option_value_from_negative_green_discount_spread_at_notice':float(negative_green.sum()/values.sum()) if values.sum()>0 else None}

    def price(self,*args,**kwargs):
        out=super().price(*args,**kwargs)
        out.update({'included_actions_with_observations_known_at_notice':len(self.history_actions),
                    'included_actions_with_observations_at_or_before_valuation':len(self.valuation_history_actions),
                    'excluded_observation_before_notice_actions':0,
                    'simulation_nodes':len(self.simulation_dates),'notice_nodes':len(self.dates)-1,
                    'clairvoyant_bound_scope':'Perfect foresight over implemented notice/redemption grid and numerical commitment gains, including observed fixing history; not the full continuous contract.',
                    'benchmark_scope':'Saved H.15 history through valuation; future AFNS par-CMT proxy with weekly averaging; nearest published tenor proxy for banker selection; dealer fallback not modeled.',
                    'scope':'Conditional Gaussian AFNS pricing with approximate regression policy, finite notice/action grid and Sobol fixing integration; not an exact American-option valuation.'})
        return out
