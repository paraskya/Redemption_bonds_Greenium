"""Evaluate the conventional notice/redemption policy with green discounting."""
from datetime import timedelta
import numpy as np
from dated_bond_pricer import years,features,exercise_probability


def fixed_conventional_policy(brown,green,state,sample_kind=False):
    if brown.dates!=green.dates or brown.terms.maturity!=green.terms.maturity:
        raise ValueError('Policy comparison requires the same full contract and notice grid')
    key=(tuple(state[:6]),sample_kind)
    if not hasattr(brown,'_fixed_policy_inputs'):brown._fixed_policy_inputs={}
    if key not in brown._fixed_policy_inputs:
        bt=brown.paths(True,state);be=brown.paths(sample_kind,state)
        bt_gain,_=brown.exercise_gains(bt,0.)
        be_gain,be_action=brown.exercise_gains(be,0.)
        fits=brown.train(bt,bt_gain,0.)
        brown._fixed_policy_inputs[key]=(be,be_gain,be_action,fits)
    be,be_gain,be_action,fits=brown._fixed_policy_inputs[key]
    ge=green.paths(sample_kind,state)
    d=green.model.nstate; terms=green.terms
    Dg=np.exp(-ge[:,:,d]); Db=np.exp(-be[:,:,d]); survival=np.ones(len(be))
    values_g=np.zeros(len(be)); values_b=np.zeros(len(be));mass=[]
    negative=np.zeros(len(be));negative_selected=np.zeros(len(be));negative_zero=np.zeros(len(be));negative_cash=np.zeros(len(be))
    tenor_weighted=np.zeros(len(be))
    green._active_context=green._path_context[id(ge)]
    predictors=brown.regression_predictor_indices()
    for j,n in enumerate(brown.dates[1:],1):
        if fits[j] is None: continue
        mask=(survival>0)&(be_gain[:,j]>0)
        if not np.any(mask): continue
        if np.isscalar(fits[j]): continuation=fits[j]
        else:
            center,scale,coef=fits[j]
            f=features(be[mask,j][:,predictors],be_gain[mask,j])
            continuation=np.maximum(0.,coef[0]+((f-center)/scale)@coef[1:])
        probabilities=exercise_probability((be_gain[mask,j]-continuation)/terms.notional,
            brown.settings.exercise_rule,brown._interval(j),brown.settings.hbar,brown.settings.sigma_m)
        indices=np.flatnonzero(mask); weights=survival[indices]*probabilities
        active=weights>0; indices=indices[active]; weights=weights[active]
        if not len(indices): continue
        state_g=ge[:,j,:d]; H=green.straight_at(n,state_g,0.)
        for lag in np.unique(be_action[indices,j]):
            selected=be_action[indices,j]==lag; idx=indices[selected]; weight=weights[selected]
            r=n+timedelta(days=int(lag))
            cash_mask=np.array([n<p<=r for p in terms.payment_dates])
            ts=[years(n,p) for p,k in zip(terms.payment_dates,cash_mask) if k]
            coupons=green.model.discounts(state_g[idx],ts)@terms.cashflows[cash_mask] if ts else np.zeros(len(idx))
            discount=green.model.discounts(state_g[idx],[years(n,r)])[:,0]
            if r>=terms.par_call_date:
                redemption=np.full(len(idx),terms.notional+terms.accrued(r))
            else:
                # The H<=par shortcut is invalid here: a policy fixed under B
                # can redeem when the green exercise gain is negative. Compute
                # the full commitment, preserving global history path indices.
                redemption=np.empty(len(idx))
                for start in range(0,len(idx),160):
                    rows=idx[start:start+160];green._selected_rows=rows
                    redemption[start:start+160]=green.h15_commitment_expectation(n,r,state_g[rows])
            g_gain=H[idx]-(coupons+discount*redemption)
            contribution=weight*Dg[idx,j]*g_gain
            values_g[idx]+=contribution
            values_b[idx]+=weight*Db[idx,j]*be_gain[idx,j]
            instantaneous=state_g[idx,3]+state_g[idx,4]
            negative[idx]+=contribution*(instantaneous<0)
            negative_selected[idx]+=contribution*(instantaneous-state_g[idx,6]<0)
            remaining=years(n,terms.maturity);diagnostic=green._conventional_diagnostic_model
            ab,bb=diagnostic.coeff((remaining,));at,bt=diagnostic.coeff((remaining,),treasury=True)
            zero_spread=((at-ab)+state_g[idx]@(bb-bt).T)[:,0]/remaining
            negative_zero[idx]+=contribution*(zero_spread<0);tenor_weighted[idx]+=contribution*zero_spread
            cash_mask=np.array([p>n for p in terms.payment_dates])
            horizons=[years(n,p) for p,k in zip(terms.payment_dates,cash_mask) if k]
            hb=diagnostic.discounts(state_g[idx],horizons)@terms.cashflows[cash_mask]
            ht=diagnostic.discounts(state_g[idx],horizons,treasury=True)@terms.cashflows[cash_mask]
            negative_cash[idx]+=contribution*(hb>ht)
        survival[indices]*=1-probabilities[active]
        mass.append({'notice_date':str(n),'fraction':float(weights.sum()/len(be)),
            'mean_notice_days':float(weights@be_action[indices,j]/weights.sum())})
    settlement_df=green.model.discounts(state,years(green.valuation,green.settlement),treasury=True)
    values_g/=settlement_df;values_b/=settlement_df
    negative/=settlement_df;negative_selected/=settlement_df;negative_zero/=settlement_df;negative_cash/=settlement_df;tenor_weighted/=settlement_df
    total=values_g.sum();grid=ge[:,:,3]+ge[:,:,4]
    return {'green_option_under_fixed_conventional_policy':float(values_g.mean()),
        'conventional_option_recomputed_under_conventional_policy':float(values_b.mean()),
        'exercise_fraction_under_conventional_policy':float(1-survival.mean()),
        'exercise_distribution':mass,
        'option_standard_error':float(values_g.std(ddof=1)/np.sqrt(len(values_g))),
        'Q_notice_grid_probability_issuer_spread_ever_negative':float(np.mean(grid.min(axis=1)<0)),
        'Q_notice_grid_probability_issuer_spread_ever_below_MW_spread':float(np.mean(grid.min(axis=1)<terms.mw_spread_bp/1e4)),
        'option_value_from_negative_issuer_spread_at_notice_per100':float(negative.mean()),
        'share_option_value_from_negative_issuer_spread_at_notice':float(negative.sum()/total) if total else None,
        'share_option_value_from_negative_selected_spread_at_notice':float(negative_selected.sum()/total) if total else None,
        'share_option_value_from_negative_green_discount_spread_at_notice':float(negative_selected.sum()/total) if total else None,
        'share_option_value_from_negative_remaining_maturity_zero_spread_at_notice':float(negative_zero.sum()/total) if total else None,
        'share_option_value_from_negative_same_cashflow_yield_spread_at_notice':float(negative_cash.sum()/total) if total else None,
        'option_value_weighted_remaining_maturity_zero_spread_bp':float(tenor_weighted.sum()/total*1e4) if total else None,
        'fixed_policy_negative_gain_sample_fraction':float(np.mean(values_g<0)),
        '_green_option_samples':values_g,'_conventional_option_samples':values_b,
        'scope':'Same GL contract, conventional fitted notice AND redemption-lag policy held fixed; green conditional commitments and discounting repriced without a spread floor.'}
