"""Fresh-seed, higher-resolution direct pricing at frozen fitted curves.

The conventional and common/omitted-green fit parameters remain unchanged.
This checks numerical pricing sensitivity, not a new joint calibration or
out-of-time market backtest. One contract cache is alive at a time.
"""
from pathlib import Path
import argparse,json,sys,gc,time,hashlib
import numpy as np
import pandas as pd
HERE=Path(__file__).resolve().parent;ROOT=HERE.parent;PROJECT=ROOT.parent
sys.path.insert(0,str(PROJECT/'treasury/code'));sys.path.insert(0,str(PROJECT/'corporate/code'))
from hull_white_contract_pricer import HWContractPricer,HWSettings
from afns_shifted_contract_pricer import AFNSContractPricer
from treasury_curves import TreasuryCurve
from corporate_data import load_observations,NSSpread,GreenIntegral,GREEN_CODES
from history_pricer import load_h15

def clear_caches(pricer):
    for cls in type(pricer).__mro__:
        for value in cls.__dict__.values():
            if hasattr(value,'cache_clear'):value.cache_clear()
    if hasattr(pricer.model,'base'):
        for value in type(pricer.model.base).__dict__.values():
            if hasattr(value,'cache_clear'):value.cache_clear()
        for value in type(pricer.model).__dict__.values():
            if hasattr(value,'cache_clear'):value.cache_clear()

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--model',choices=['hw1f','afns3f_shifted','afns_shifted','afns_plus'],required=True)
    ap.add_argument('--fit-dir');ap.add_argument('--source-root',default=str(Path('restored/Zero_Coupon_Greenium_Data_and_Code').resolve()))
    ap.add_argument('--train',type=int,default=768);ap.add_argument('--evaluation',type=int,default=2304)
    ap.add_argument('--seed',type=int,default=20261003);ap.add_argument('--step',type=int,default=30);ap.add_argument('--qmc-power',type=int,default=5)
    args=ap.parse_args();fdir=Path(args.fit_dir) if args.fit_dir else PROJECT/'corporate/results'/args.model
    out=ROOT/'results'/('refined_'+args.model);out.mkdir(parents=True,exist_ok=True)
    data=load_observations(args.source_root);obs=data['observations'].set_index('code');valuation=data['valuation']
    rate=json.loads((ROOT/'results/hw_rate_parameters.json').read_text());curve=TreasuryCurve(str(valuation))
    fit=json.loads((fdir/'conventional_fit.json').read_text());beta=np.array(fit['parameters_bp'])/1e4;spread=NSSpread(beta)
    settings=HWSettings(train_paths=args.train,evaluation_paths=args.evaluation,seed=args.seed,step_days=args.step,qmc_power=args.qmc_power)
    h15=load_h15(Path(args.source_root)/'pricing/inputs/treasury_daily_percent.csv')
    low=pd.concat([pd.read_csv(fdir/p) for p in ['conventional_prices.csv','common_green_prices.csv','omitted_green_prices.csv']],ignore_index=True)
    rows=[];prep=[];started=time.time()
    for code in GREEN_CODES+['92343VGK']:
        cases=[('common_green',fdir/'green_fit_common.json'),('omitted_green',fdir/f'green_fit_omit_{code}.json')] if code in GREEN_CODES else [('conventional_holdout',None)]
        if args.model=='hw1f':
            p=HWContractPricer(data['terms'][code],valuation,curve,rate['a_Q'],rate['sigma_per_sqrt_year'],settings,h15)
        else:p=AFNSContractPricer(data['terms'][code],valuation,curve,data['prior_config'],settings,h15)
        prep.append({'code':code,'seconds':p.preparation_seconds,'bytes':p.cache_bytes(),'notices':len(p.dates),'actions':len(p.actions)})
        print(json.dumps({'prepared':code,'model':args.model,'seconds':p.preparation_seconds,'cache_MB':p.cache_bytes()/1e6}),flush=True)
        for case,path in cases:
            state=json.loads(path.read_text()) if path is not None else {'z_bp':0.}
            z=float(state['z_bp']);green=GreenIntegral(z/1e4) if code in GREEN_CODES else None
            r=p.price(spread,green,return_samples=True);ob=obs.loc[code];bond=data['bonds'][code]
            y=bond.yield_from_dirty(r['model_dirty'],valuation,adjusted=True)
            old=low.loc[(low.code==code)&(low.case==case)]
            if old.empty and code=='92343VGK':old=low.loc[low.code==code]
            if len(old)!=1:raise ValueError(f'Ambiguous lower-resolution result for {code} {case}')
            old=old.iloc[0]
            # Dollar standard error mapped using the observed-price DV01.
            row={'model':args.model,'code':code,'case':case,'valuation_date':str(valuation),'green_z_bp':z,
                'observed_clean_per100':float(ob.observed_clean_per100),'observed_dirty_per100':float(ob.observed_dirty_per100),
                'model_dirty_per100':r['model_dirty'],'model_clean_per100':r['model_dirty']-float(ob.accrued_per100),
                'straight_dirty_per100':r['straight_dirty'],'option_value_per100':r['option_value'],
                'option_mc_se_per100':r['option_standard_error'],'conditional_option_mc_se_yield_bp':r['option_standard_error']/float(ob.dv01_per100),
                'yield_error_bp':(y-float(ob.observed_yield_pct)/100)*1e4,'price_error_per100':r['model_dirty']-float(ob.observed_dirty_per100),
                'lower_resolution_yield_error_bp':float(old.yield_error_bp),'lower_resolution_option_per100':float(old.option_value_per100),
                'refinement_change_yield_bp':(y-float(old.model_yield_pct)/100)*1e4,
                'refinement_change_price_per100':r['model_dirty']-float(old.model_dirty_per100),
                'training_option_value_per100':r['training_option_value'],'evaluation_exercise_probability':r['evaluation_exercise_probability'],
                'maximum_treasury_horizon_used_years':r['maximum_treasury_horizon_used_years'],'fixed_parameters_recalibrated':False,
                'observed_price_used_by_pricer':False,'seed':args.seed,'train_paths':args.train,'evaluation_paths':args.evaluation,
                'fixing_draws':2**args.qmc_power,'notice_step_days':args.step}
            rows.append(row);np.savez_compressed(out/f'{code}_{case}_option_samples.npz',option_samples=r['_option_samples'],exercise_indices=r['_exercise_indices'])
            print(json.dumps({'completed':code,'case':case,'yield_error_bp':row['yield_error_bp'],'refinement_change_bp':row['refinement_change_yield_bp']}),flush=True)
        pd.DataFrame(rows).to_csv(out/'direct_pricing.csv',index=False)
        clear_caches(p);del p;gc.collect()
    frame=pd.DataFrame(rows);summary={}
    for case,part in frame.groupby('case'):
        summary[case]={'n_bonds':len(part),'refined_yield_rmse_bp':float(np.sqrt(np.mean(part.yield_error_bp**2))),
            'lower_resolution_yield_rmse_bp':float(np.sqrt(np.mean(part.lower_resolution_yield_error_bp**2))),
            'maximum_abs_refinement_change_yield_bp':float(part.refinement_change_yield_bp.abs().max()),
            'maximum_conditional_option_mc_se_yield_bp':float(part.conditional_option_mc_se_yield_bp.max())}
    payload={'model':args.model,'valuation_date':str(valuation),'settings':settings.__dict__,'frozen_credit_parameters_bp':fit['parameters_bp'],
        'aggregates':summary,'preparation':prep,'elapsed_seconds':time.time()-started,
        'scope':'Fresh-seed higher path count and fixing quadrature replay at unchanged lower-resolution fitted curves. No full conventional outer recalibration at refined settings; no independent market or out-of-time test.',
        'input_fit_hashes':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in fdir.glob('*.json')},
        'code_hashes':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [Path(__file__),HERE/'hull_white_contract_pricer.py',HERE/'afns_shifted_contract_pricer.py']}}
    (out/'summary.json').write_text(json.dumps(payload,indent=2));print(json.dumps(payload,indent=2),flush=True)
if __name__=='__main__':main()
