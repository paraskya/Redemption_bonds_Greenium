"""Initial-curve-fitted AFNS rates with the common actual-contract pricer.

The three original AFNS Treasury dynamics are preserved, centered at zero.
A deterministic time-dependent shift reproduces the supplied initial curve.
Credit and green curves remain deterministic as in the Hull--White comparison.
This is explicitly an AFNS++ extension, not the original homogeneous model.
"""
from __future__ import annotations
from functools import lru_cache
import numpy as np
from scipy.stats import qmc, norm
from joint_afns_model import JointAFNSModel
from hull_white_contract_pricer import HWContractPricer, HWSettings, years, thirty360


def psd_root(cov):
    cov = (np.asarray(cov, float) + np.asarray(cov, float).T) / 2
    ev, vec = np.linalg.eigh(cov)
    scale = max(float(np.linalg.norm(cov, 2)), 1e-30)
    if ev.min(initial=0.) < -1e-11 * scale:
        raise ValueError("Negative covariance eigenvalue beyond roundoff")
    return vec * np.sqrt(np.maximum(ev, 0.))


class AFNSShiftedCurveModel:
    """Centered Gaussian AFNS with Phi(u)=-log(P0(u))+Var(integral X)/2."""
    def __init__(self, curve, config):
        self.curve = curve
        omega = np.asarray(config["covariance"], float)[:3, :3]
        self.base = JointAFNSModel({"lam": float(config["lam"]),
            "y0": [0., 0., 0.], "covariance": omega.tolist()},
            security="treasury")
        self.K = self.base.K
        self.omega = omega
        self.nstate = 3
        self.factor_scale = np.maximum(
            np.sqrt(np.diag(self.transition(1.)[2])[:3]), .001)

    @lru_cache(maxsize=8192)
    def transition(self, h):
        return self.base.transition(float(h))

    def B(self, h):
        return self.base.B(h, treasury=True)

    def vi(self, h):
        t = np.asarray(h, float)
        if t.ndim == 0:
            return float(self.base.coeff((float(t),), treasury=True)[0][0] * 2)
        a = self.base.coeff(tuple(t.ravel()), treasury=True)[0]
        return (2*a).reshape(t.shape)

    def phi_integral(self, t):
        t = np.asarray(t, float)
        return -np.asarray(self.curve.log_discount(t), float) + .5*self.vi(t)

    def bond_coeff(self, t, T):
        T = np.asarray(T, float)
        h = np.maximum(T-float(t), 0.)
        return -self.phi_integral(T)+self.phi_integral(t)+.5*self.vi(h), self.B(h)

    def discounts(self, t, T, x):
        a, b = self.bond_coeff(t, T)
        return np.exp(a - np.asarray(x) @ np.atleast_2d(b).T)

    @lru_cache(maxsize=4096)
    def _fix_moments(self, u_tuple, horizon):
        u = np.asarray(u_tuple)
        count = len(u)
        loading = np.empty((count, 3, 3))
        shift = np.empty((count, 3))
        covariance = np.empty((count*3, count*3))
        for i, ui in enumerate(u):
            phi, _, cv = self.transition(float(ui))
            loading[i] = phi[:3, :3]
            shift[i] = -(cv[:3, 3] + cv[:3, :3] @ self.B(horizon-ui))
            for j, uj in enumerate(u):
                if ui <= uj:
                    later = self.transition(float(uj-ui))[0][:3, :3]
                    block = cv[:3, :3] @ later.T
                else:
                    earlier_cv = self.transition(float(uj))[2][:3, :3]
                    later = self.transition(float(ui-uj))[0][:3, :3]
                    block = later @ earlier_cv
                covariance[3*i:3*i+3, 3*j:3*j+3] = block
        return loading, shift, (covariance+covariance.T)/2

    def conditional_fixing_moments(self, n, r, fixings):
        return self._fix_moments(tuple(np.asarray(fixings, float)-n), float(r-n))


class AFNSContractPricer(HWContractPricer):
    """Same cashflow, calendar, notice and policy routines as HW; three factors."""
    def __init__(self, terms, valuation, curve, config, settings=None, h15=None, progress=None):
        self.afns_config = config
        # The overridden simulation installs the three-factor model before any
        # price, simulated fixing or conditional commitment is calculated.
        super().__init__(terms, valuation, curve, 1., 1.,
                         settings=settings, h15=h15, progress=progress)

    def _simulate(self):
        self.model = AFNSShiftedCurveModel(self.model.curve, self.afns_config)
        m = self.model
        count_dates = len(self.sim_times)
        x = np.zeros((self.npath, count_dates, 3))
        integ = np.zeros((self.npath, count_dates))
        for left, count, seed in [(0,self.ntrain,self.settings.seed),
                (self.ntrain,self.neval,self.settings.seed+1)]:
            rng = np.random.default_rng(seed)
            section = slice(left,left+count)
            for j in range(1,count_dates):
                h = float(self.sim_times[j]-self.sim_times[j-1])
                phi, gamma, cv = m.transition(h)
                root = psd_root(cv)
                half = (count+1)//2
                z = rng.standard_normal((half,4))
                noise = np.r_[z,-z][:count] @ root.T
                old = np.column_stack([x[section,j-1],integ[section,j-1]])
                new = old @ phi.T + gamma + noise
                x[section,j] = new[:,:3]
                integ[section,j] = new[:,3]
        self.sim_index = {d:i for i,d in enumerate(self.sim_dates)}
        idx = [self.sim_index[d] for d in self.dates]
        self.x = x[:,idx]
        self.integral = integ[:,idx]
        self.history_x = {}
        self.all_x = x

    @lru_cache(maxsize=8192)
    def _cmt_coeff(self, s, months):
        t = years(self.valuation,s)
        tau = months/12.
        self.max_treasury_horizon_years = max(
            getattr(self,"max_treasury_horizon_years",0.), t+tau)
        h = np.arange(.5,tau+1e-8,.5)
        if not len(h) or abs(h[-1]-tau)>1e-10:
            h = np.r_[h,tau]
        accrual = np.diff(np.r_[0.,h])
        a,b = self.model.bond_coeff(t,t+h)
        return a,b,accrual

    def _cmt(self, s, months, x):
        # Direct three-factor evaluation; no interpolation error or dimension
        # reduction is introduced into future Treasury reference rates.
        a,b,accrual = self._cmt_coeff(s,months)
        df = np.exp(a - np.asarray(x) @ b.T)
        return (1-df[...,-1])/(df@accrual)

    def _conditional_redemption(self, n, r, observations):
        terms = self.terms
        if r>=terms.par_call_date:
            return np.full(self.npath,terms.notional+terms.accrued(r))
        tn,tr = years(self.valuation,n),years(self.valuation,r)
        x = self.all_x[:,self.sim_index[n],:]
        past = [s for s in observations if s<=n]
        future = [s for s in observations if s>n]
        months,weights = self.schedule.h15_tenor_selection(r)
        known = np.zeros(self.npath)
        for s in past:
            if s<=self.valuation:
                try:
                    known += sum(w*self.h15[s][mo] for w,mo in zip(weights,months))
                except KeyError as exc:
                    raise ValueError(f"Missing known H.15 observation {s}") from exc
            else:
                xs = self.all_x[:,self.sim_index[s],:]
                known += sum(w*self._cmt(s,mo,xs) for w,mo in zip(weights,months))
        if future:
            fix_times = np.array([years(self.valuation,s) for s in future])
            loading,shift,cv = self.model.conditional_fixing_moments(tn,tr,fix_times)
            root = psd_root(cv)
            u = qmc.Sobol(d=3*len(future),scramble=True,
                seed=self.settings.seed+731).random_base2(self.settings.qmc_power)
            z = (norm.ppf(np.clip(u,1e-12,1-1e-12)) @ root.T).reshape(-1,len(future),3)
            total = np.repeat(known[:,None],len(u),axis=1)
            for k,s in enumerate(future):
                mean = x @ loading[k].T + shift[k]
                xs = mean[:,None,:] + z[None,:,k,:]
                total += sum(w*self._cmt(s,mo,xs) for w,mo in zip(weights,months))
        else:
            total = known[:,None]
        rate = total/len(observations)
        if terms.treasury_rate_round_decimals is not None:
            scale = 10**terms.treasury_rate_round_decimals
            rate = np.floor(rate*100*scale+.5)/scale/100
        rate += terms.mw_spread_bp/1e4
        if rate.min()<-.15 or rate.max()>.50:
            raise ValueError("Redemption interpolation domain exceeded")
        redemption = np.maximum(terms.notional,self._redemption_table(r)(rate))
        if terms.redemption_price_round_decimals is not None:
            scale = 10**terms.redemption_price_round_decimals
            redemption = np.floor(redemption/terms.notional*100*scale+.5)/scale*terms.notional/100
        return redemption.mean(axis=1)+terms.accrued(r)

    def _features(self, x, gain):
        z = np.asarray(x)/self.model.factor_scale
        g = gain/10.
        return np.column_stack([np.ones(len(x)),z,z*z,z[:,0]*z[:,1],
            z[:,0]*z[:,2],z[:,1]*z[:,2],g,g*g,z*g[:,None]])

    def price(self,*args,**kwargs):
        result = super().price(*args,**kwargs)
        result["treasury_model"] = "AFNS three factors with exact initial-curve shift (AFNS++)"
        result["AFNS_lambda"] = float(self.afns_config["lam"])
        result["initial_curve_shift_extension"] = True
        return result


def prepare_afns_contract(terms, valuation, treasury_curve, config, settings=None,
                          h15=None, progress=None):
    return AFNSContractPricer(terms,valuation,treasury_curve,config,
                              settings=settings,h15=h15,progress=progress)
