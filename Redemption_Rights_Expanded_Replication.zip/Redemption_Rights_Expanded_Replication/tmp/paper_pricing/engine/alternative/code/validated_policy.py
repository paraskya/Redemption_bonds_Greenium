"""Select one whole green exercise policy on a separate validation sample.

Candidates are the G-trained policy and the B-trained policy repriced under G.
Their evaluation outcomes never enter the selection rule. This is a two-policy
approximation, not global optimal exercise or a pathwise hindsight maximum.
"""
import numpy as np
from history_pricer import HistoryBondPricer
from policy_feedback import fixed_conventional_policy


class ValidationPolicyGreenPricer(HistoryBondPricer):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        if self.model.security!='green':raise ValueError('Validation policy selection requires green kernel')
        self.conventional_policy_pricer=None
        self._validated_price_cache={}

    def price(self,delta=0.,initial_state=None,z=None,return_samples=False):
        if delta!=0.:raise ValueError('Current two-policy implementation assumes supplied issuer_delta=0')
        if self.conventional_policy_pricer is None:raise ValueError('Same-contract B policy pricer is required')
        if not hasattr(self,'shared_path_group') or getattr(self.conventional_policy_pricer,'shared_path_group',None) is not self.shared_path_group:
            raise ValueError('Independent validation requires both kernels in the same SharedPathGroup')
        y=self.initial_state(initial_state,z);key=(float(delta),tuple(y))
        if key not in self._validated_price_cache:
            # Fit on training and select on validation BEFORE pricing either
            # candidate on the independent evaluation set for this trial state.
            training=self.paths(True,y);tg,_=self.exercise_gains(training,0.)
            fits=self.train(training,tg,0.)
            validation=self.paths('validation',y);vg,va=self.exercise_gains(validation,0.)
            own_validation=self.evaluate(validation,vg,va,0.,fits,y)
            fixed_validation=fixed_conventional_policy(self.conventional_policy_pricer,self,y,'validation')
            paired_validation=own_validation['_option_samples']-fixed_validation['_green_option_samples']
            val_difference=float(paired_validation.mean())
            # Whole-policy, global selection. A tie keeps the conventional
            # feasible policy. The rule does not inspect evaluation outcomes.
            selected='green_trained' if val_difference>0 else 'fixed_conventional'
            own=super().price(0.,y,return_samples=True)
            fixed=fixed_conventional_policy(self.conventional_policy_pricer,self,y,False)
            paired_evaluation=own['_option_samples']-fixed['_green_option_samples']
            out=own.copy()
            if selected=='fixed_conventional':
                c=fixed['green_option_under_fixed_conventional_policy']
                for name in ('option_standard_error','exercise_distribution',
                    'Q_notice_grid_probability_issuer_spread_ever_negative',
                    'Q_notice_grid_probability_issuer_spread_ever_below_MW_spread',
                    'option_value_from_negative_issuer_spread_at_notice_per100',
                    'share_option_value_from_negative_issuer_spread_at_notice',
                    'share_option_value_from_negative_selected_spread_at_notice',
                    'share_option_value_from_negative_green_discount_spread_at_notice',
                    'share_option_value_from_negative_remaining_maturity_zero_spread_at_notice',
                    'share_option_value_from_negative_same_cashflow_yield_spread_at_notice',
                    'option_value_weighted_remaining_maturity_zero_spread_bp',
                    'fixed_policy_negative_gain_sample_fraction'):
                    out[name]=fixed[name]
                out.update(option_value=c,_option_samples=fixed['_green_option_samples'],
                    exercise_fraction=fixed['exercise_fraction_under_conventional_policy'],
                    model_dirty=own['straight_dirty']-c,
                    model_clean=own['straight_dirty']-c-own['accrued_interest'])
                out['ytm_callable']=self.terms.ytm(out['model_dirty'],self.settlement)
            out.update(selected_policy=selected,
                policy_approximation='Two whole policies, selected by independent validation mean; global optimality is not claimed.',
                policy_validation={
                    'training_paths':self.settings.train_paths,
                    'validation_paths':self.settings.validation_paths,
                    'evaluation_paths':self.settings.evaluation_paths,
                    'training_seed':self.settings.seed,
                    'validation_seed':self.settings.seed+2,
                    'evaluation_seed':self.settings.seed+1,
                    'green_trained_validation_option_mean':own_validation['option_value'],
                    'fixed_conventional_validation_option_mean':fixed_validation['green_option_under_fixed_conventional_policy'],
                    'green_minus_fixed_validation_mean':val_difference,
                    'green_minus_fixed_validation_paired_SE':float(paired_validation.std(ddof=1)/np.sqrt(len(paired_validation))),
                    'selected_policy':selected,
                    'selection_rule':'Choose G-trained only when its global validation mean exceeds fixed-B under G; no evaluation values and no pathwise max used.',
                    'green_trained_evaluation_option_mean':own['option_value'],
                    'fixed_conventional_evaluation_option_mean':fixed['green_option_under_fixed_conventional_policy'],
                    'green_minus_fixed_evaluation_mean':float(paired_evaluation.mean()),
                    'green_minus_fixed_evaluation_paired_SE':float(paired_evaluation.std(ddof=1)/np.sqrt(len(paired_evaluation))),
                    'evaluation_used_in_policy_selection':False,
                    'global_optimal_policy_claimed':False})
            self._validated_price_cache[key]=out
        result=self._validated_price_cache[key].copy()
        if not return_samples:result.pop('_option_samples',None)
        return result
