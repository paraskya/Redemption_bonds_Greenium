"""Controlled epsF=.1 -> 0 repricing; no parameter/state refit.

The parent revision's complete contracted pricer is copied unchanged except
for saving samples and an optional price at a supplied green state. The
coupling below changes only the covariance square root, never its covariance.
"""
from __future__ import annotations
import os
for name in ('OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS'): os.environ[name]='1'
import argparse,gc,hashlib,json,time
from pathlib import Path
from functools import lru_cache
import numpy as np
from scipy.linalg import cholesky
import revised_pilot as rp
from dated_bond_pricer import NumericalSettings
from shared_paths import SharedPathGroup
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
COUPLING_AUDITS=[]
REFERENCE_TREASURY={}

class PairedGroup(SharedPathGroup):
    """Ordered covariance factor keeps Treasury innovations identical."""
    @lru_cache(None)
    def transition(self,t):
        phi,gamma,symmetric=super().transition(t)
        cov=symmetric@symmetric.T
        active=[i for i in range(7) if self.model.omega[i,i]>0]+[7]
        if self.model.omega[6,6]>0:active.append(8)
        # Here CF and Z are deterministic. Do not invent their diffusion.
        active=sorted(set(active));inactive=[i for i in range(9) if i not in active]
        inactive_error=float(np.max(np.abs(cov[inactive,:]),initial=0.))
        if inactive_error>1e-15:raise ValueError('Unexpected stochastic inactive coordinate')
        sub=cov[np.ix_(active,active)];sd=np.sqrt(np.diag(sub))
        correlation=sub/sd[:,None]/sd[None,:]
        factor=sd[:,None]*cholesky((correlation+correlation.T)/2,lower=True)
        root=np.zeros_like(cov);root[np.ix_(active,active)]=factor
        error=float(np.max(np.abs(root@root.T-cov)))
        if error>1e-13:raise AssertionError('Covariance factor failed')
        key=round(float(t),13)
        treasury=(phi[:3,:3],gamma[:3],root[:3,:3])
        comparison=0.
        if key in REFERENCE_TREASURY:
            comparison=max(float(np.max(abs(a-b))) for a,b in zip(treasury,REFERENCE_TREASURY[key]))
            if comparison>1e-13:raise AssertionError('Treasury transition changed')
        else:REFERENCE_TREASURY[key]=treasury
        COUPLING_AUDITS.append(dict(dt=float(t),epsF=self.model.epsF,
            covariance_reconstruction_max_error=error,inactive_covariance_max=inactive_error,
            treasury_transition_factor_max_change=comparison,stochastic_coordinates=active))
        return phi,gamma,root
rp.SharedPathGroup=PairedGroup

def release_pricer_caches():
    # functools caches on bound methods otherwise retain complete path groups
    # after one scenario ends. Clear only after all its outputs are persisted.
    from dated_bond_pricer import BondPricer
    from history_pricer import HistoryBondPricer
    for cls in (PairedGroup,SharedPathGroup,BondPricer,HistoryBondPricer,rp.JointAFNSModel):
        for value in cls.__dict__.values():
            if hasattr(value,'cache_clear'):value.cache_clear()
    gc.collect()

def se(values):return float(np.std(values,ddof=1)/np.sqrt(len(values)))
def hashfile(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def compare(a,b,da,db):
    samples_a=np.load(da/'option_samples.npz');samples_b=np.load(db/'option_samples.npz')
    rows=[]
    for code in (rp.GREEN,rp.TWIN,rp.OLD,'GL_B'):
        ra=a['bond_results'][code];rb=b['bond_results'][code]
        diff=samples_b[code]-samples_a[code]
        rows.append(dict(code=code,green_state_treatment='own_conditional_callable_inversion' if code==rp.GREEN else 'held_fixed',
            mean_reverting_straight=ra['straight_dirty'],driftless_straight=rb['straight_dirty'],
            straight_change=rb['straight_dirty']-ra['straight_dirty'],
            mean_reverting_option=ra['option_value'],driftless_option=rb['option_value'],
            option_change=float(diff.mean()),option_change_paired_MC_SE=se(diff),
            mean_reverting_option_MC_SE=ra['option_standard_error'],driftless_option_MC_SE=rb['option_standard_error'],
            callable_change=rb['model_dirty']-ra['model_dirty'],
            mean_reverting_negative_issuer_notice_grid_probability=ra['Q_notice_grid_probability_issuer_spread_ever_negative'],
            driftless_negative_issuer_notice_grid_probability=rb['Q_notice_grid_probability_issuer_spread_ever_negative'],
            mean_reverting_negative_issuer_option_share=ra['share_option_value_from_negative_issuer_spread_at_notice'],
            driftless_negative_issuer_option_share=rb['share_option_value_from_negative_issuer_spread_at_notice'],
            mean_reverting_negative_remaining_zero_spread_option_share=ra['share_option_value_from_negative_remaining_maturity_zero_spread_at_notice'],
            driftless_negative_remaining_zero_spread_option_share=rb['share_option_value_from_negative_remaining_maturity_zero_spread_at_notice']))
    fixed=b['fixed_baseline_green_state_result'];ra=a['bond_results'][rp.GREEN]
    fixed_delta=samples_b['GL_fixed_baseline_green_state']-samples_a[rp.GREEN]
    fixed_row=dict(code=rp.GREEN,green_state_treatment='baseline_green_state_held_fixed',
        mean_reverting_straight=ra['straight_dirty'],driftless_straight=fixed['straight_dirty'],
        straight_change=fixed['straight_dirty']-ra['straight_dirty'],mean_reverting_option=ra['option_value'],
        driftless_option=fixed['option_value'],option_change=float(fixed_delta.mean()),option_change_paired_MC_SE=se(fixed_delta),
        callable_change=fixed['model_dirty']-ra['model_dirty'])
    import csv
    fields=list(dict.fromkeys(k for r in rows+[fixed_row] for k in r))
    with (da.parent/'paired_options.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows+[fixed_row])
    near={k:{'mean_reverting':v,'driftless':b['near_twin_decomposition'].get(k),
             'change':b['near_twin_decomposition'][k]-v}
        for k,v in a['near_twin_decomposition'].items() if isinstance(v,(int,float)) and not isinstance(v,bool)}
    # Fixed-point root introduces sampling variation. Delta-method SE below
    # propagates paired option samples into the observed-price green roots;
    # it is conditional on the fitted/validation-selected policies.
    za=a['green_inversion']['z'];zb=b['green_inversion']['z']
    root_se={}
    for label,r,samples in [('a',a,samples_a),('b',b,samples_b)]:
        c=r['config'];y=np.array(r['final_initial_state']);m=rp.JointAFNSModel(c,'green')
        bond=rp.CashflowBond.from_contract(rp.read_contracts(ROOT/'inputs/verizon_reviewed_contracts.json')[rp.GREEN])
        date=rp.as_date(r['valuation_date']);times,cashflows=bond.cashflows(date)
        h=float(np.asarray(cashflows)@m.discounts(y,times))
        deriv=float(np.asarray(cashflows)@(m.discounts(y,times)*(-m.B(np.array(times))[:,6])))
        root_se[label]=(deriv,samples[rp.GREEN])
    paired_root=1e4*(root_se['b'][1]/root_se['b'][0]-root_se['a'][1]/root_se['a'][0])
    output=dict(month=a['month_label'],status='controlled_fixed_parameter_state_sensitivity_not_accepted_calibration',
        baseline_epsF=a['config']['epsF'],counterfactual_epsF=b['config']['epsF'],options=rows,
        fixed_green_state_result=fixed_row,near_twin_metrics=near,
        green_state_baseline_bp=za*1e4,green_state_driftless_bp=zb*1e4,green_state_change_bp=(zb-za)*1e4,
        green_state_change_MC_SE_straight_sensitivity_approx_bp=se(paired_root),
        green_state_SE_scope='Linear propagation using straight-price derivative only; excludes option derivative, root-policy discontinuity, grid, parameter uncertainty. Do not treat as fully calibrated green-state CI.',
        raw_benchmark_unchanged=near['raw_GL_against_GK_yield_difference_bp']['change']==0.,
        both_roots_converged=a['green_inversion']['converged'] and b['green_inversion']['converged'],
        mean_reverting_root=a['green_inversion'],driftless_root=b['green_inversion'],
        pairing='Same independently seeded train/validation/evaluation Gaussian innovation streams and identical contract union calendar; ordered exact-covariance factors preserve Treasury innovations.',
        covariance_factor_audit=COUPLING_AUDITS)
    previous_summary=da.parent/'paired_summary.json'
    if not output['covariance_factor_audit'] and previous_summary.exists():
        output['covariance_factor_audit']=json.loads(previous_summary.read_text()).get('covariance_factor_audit',[])
    (da.parent/'paired_summary.json').write_text(json.dumps(output,indent=2,default=rp.to_json))
    return output

def main():
    p=argparse.ArgumentParser();p.add_argument('--month',default='2026-08-31');p.add_argument('--output',required=True)
    p.add_argument('--train',type=int,default=1600);p.add_argument('--validation',type=int,default=2400)
    p.add_argument('--evaluation',type=int,default=6000);p.add_argument('--qmc-power',type=int,default=5)
    p.add_argument('--step',type=int,default=30);p.add_argument('--seed',type=int,default=20260925)
    p.add_argument('--config',default=str(ROOT/'inputs/six_state_monthly_configs.json'))
    a=p.parse_args();out=Path(a.output);out.mkdir(parents=True,exist_ok=True)
    source=rp.load_config(a.config,a.month);base=dict(source);zero=dict(source,epsF=0.)
    for c in (base,zero):
        c['production_option_calibration_ready']=False
        c['calculation_scope']='controlled epsF-only sensitivity, all other parameters and initial issuer/Treasury states held fixed'
    (out/'configs.json').write_text(json.dumps(dict(mean_reverting=base,driftless=zero),indent=2))
    settings=NumericalSettings(train_paths=a.train,validation_paths=a.validation,evaluation_paths=a.evaluation,
        qmc_power=a.qmc_power,step_days=a.step,seed=a.seed,paired_driver=False)
    outputs=[]
    for label,c in [('mean_reverting',base),('driftless',zero)]:
        target=out/label;cached=target/'result.json'
        if cached.exists():r=json.loads(cached.read_text())
        else:
            r=rp.run_case(a.month,c,settings,target,ROOT/'inputs/verizon_reviewed_contracts.json',
                ROOT/'inputs/verizon_reviewed_monthly_prices.csv','clean',(rp.TWIN,rp.OLD),.1,False,True,
                ROOT/'inputs/treasury_daily_percent.csv',True,
                outputs[0]['green_inversion']['z'] if label=='driftless' else None)
        outputs.append(r);release_pricer_caches()
    summary=compare(*outputs,out/'mean_reverting',out/'driftless')
    provenance={str(x.relative_to(ROOT)):hashfile(x) for x in (ROOT/'inputs').glob('*') if x.is_file()}
    (out/'input_hashes.json').write_text(json.dumps(provenance,indent=2))
    print(json.dumps({'completed':str(out),'green_state_change_bp':summary['green_state_change_bp'],
        'roots_converged':summary['both_roots_converged'],'paired_option_changes':[{k:r[k] for k in ('code','option_change','option_change_paired_MC_SE')} for r in summary['options']]}),flush=True)
if __name__=='__main__':main()
