"""Serial direct common-state and leave-one-green-out callable checks."""
import json,os,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
for name in ('OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS'):os.environ[name]='1'
states=json.loads((ROOT/'inputs/direct_pricing_states.json').read_text())
for suffix,control in [('ES','GH'),('FL','FR'),('GL','GK'),('GP','GB')]:
    code='92343V'+suffix;out=ROOT/'results'/f'{suffix}_common_state'
    common=out/'common_state_result.json';heldout=out/'leave_one_green_out_result.json'
    complete=False
    if common.exists() and heldout.exists():
        a=json.loads(common.read_text());b=json.loads(heldout.read_text())
        complete=abs(a['common_green_state_bp']-states['common_z']*1e4)<1e-12 and abs(b['common_green_state_bp']-states['leave_one_green_out_z'][code]*1e4)<1e-12
    if not complete:
        cmd=[sys.executable,str(ROOT/'code/run_green_pair.py'),'--green',code,
            '--control','92343V'+control,'--output',str(out),'--direct-z-bp',str(states['common_z']*1e4),
            '--loo-z-bp',str(states['leave_one_green_out_z'][code]*1e4)]
        if suffix=='GL':cmd+=['--extra-calendar-control','92343VBE']
        subprocess.run(cmd,check=True)
    subprocess.run([sys.executable,str(ROOT/'code/consolidate_results.py')],check=True)
