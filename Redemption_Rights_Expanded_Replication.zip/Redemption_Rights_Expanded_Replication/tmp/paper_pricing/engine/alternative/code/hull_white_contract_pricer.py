"""Curve-fitted Hull--White benchmark with actual dated redemption terms.

One Gaussian short-rate factor, deterministic issuer/green forward spreads.
The initial Treasury discount curve is fitted exactly by its deterministic shift.
The original BondTerms/calendar, notice grids and H.15 fixing definitions are
reused. Weekly observed fixings stay in the information set. Future fixings
are integrated under the redemption forward measure, using common Sobol draws.
Issuer exercise uses LSM policies trained and evaluated on disjoint paths.
No observed price is supplied to this module.

The economic alternatives to the paper are one Treasury risk factor and zero
credit/green diffusion. This is a finite-grid numerical benchmark, not an exact
continuous-exercise price, and rate option parameters require independent input.
"""
from __future__ import annotations
import os
for _v in ('OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS'):
    os.environ[_v]='1'
from dataclasses import dataclass
from functools import lru_cache
from datetime import date
import time
import numpy as np
from scipy.interpolate import PchipInterpolator
from scipy.stats import qmc, norm
from dated_bond_pricer import BondPricer, BondTerms, NumericalSettings, years, thirty360, as_date
from history_pricer import HistoryBondPricer

@dataclass(frozen=True)
class HWSettings:
    train_paths:int=192
    evaluation_paths:int=576
    step_days:int=30
    seed:int=20260926
    qmc_power:int=4
    notice_lags:tuple|None=None
    cache_dtype:str='float32'
    cmt_grid_points:int=601
    redemption_grid_points:int=2401
    regression_ridge:float=1e-7

class LogDiscountCurve:
    """PCHIP of log discounts, with linear log-discount extrapolation.

    Prefer passing the exact GSW/Svensson callable when available. This is an
    explicit tabular adapter; its fit is exact at the supplied discount knots.
    """
    def __init__(self,times,discounts):
        t=np.asarray(times,float);d=np.asarray(discounts,float)
        if t[0]>0:t=np.r_[0.,t];d=np.r_[1.,d]
        if np.any(np.diff(t)<=0) or np.any(d<=0):raise ValueError('Invalid discount knots')
        self.t=t;self.ld=np.log(d);self.interp=PchipInterpolator(t,self.ld)
    def log_discount(self,t):
        t=np.asarray(t,float)
        ans=self.interp(np.clip(t,self.t[0],self.t[-1]))
        return np.where(t>self.t[-1],self.ld[-1]+(t-self.t[-1])*self.interp.derivative()(self.t[-1]),ans)

class HullWhiteCurveModel:
    def __init__(self,curve,a,sigma):
        if a<=0 or sigma<0:raise ValueError('a>0 and sigma>=0 required')
        self.curve=curve;self.a=float(a);self.sigma=float(sigma)
    def B(self,h):
        h=np.asarray(h,float);return -np.expm1(-self.a*h)/self.a
    def vx(self,h):
        h=np.asarray(h,float);return self.sigma**2*(-np.expm1(-2*self.a*h))/(2*self.a)
    def cov_x_i(self,h):return .5*self.sigma**2*self.B(h)**2
    def vi(self,h):
        h=np.asarray(h,float);ah=self.a*h
        # Cancellation-free series for very short intervals.
        exact=self.sigma**2/self.a**2*(h-2*self.B(h)-np.expm1(-2*ah)/(2*self.a))
        small=self.sigma**2*h**3*(1/3-ah/4+7*ah**2/60-ah**3/24+31*ah**4/2520)
        return np.where(abs(ah)<1e-3,small,np.maximum(exact,0.))
    def phi_integral(self,t):
        t=np.asarray(t,float);return -np.asarray(self.curve.log_discount(t),float)+.5*self.vi(t)
    def bond_coeff(self,t,T):
        T=np.asarray(T,float);h=np.maximum(T-float(t),0.)
        return -self.phi_integral(T)+self.phi_integral(t)+.5*self.vi(h),self.B(h)
    def discounts(self,t,T,x):
        A,B=self.bond_coeff(t,T)
        return np.exp(np.asarray(x)[...,None]*(-B)+A)
    def conditional_fixing_moments(self,n,r,fixings):
        u=np.asarray(fixings,float)-n
        h=np.asarray(r)-np.asarray(fixings,float)
        mean_shift=-self.cov_x_i(u)-self.vx(u)*self.B(h)
        covariance=self.vx(np.minimum.outer(u,u))*np.exp(-self.a*abs(np.subtract.outer(u,u)))
        return np.exp(-self.a*u),mean_shift,covariance

class HWContractPricer:
    """Reusable actual-contract pricer. Curves passed to price are integrated.

    S(t) is the cumulative deterministic issuer spread from valuation to t.
    G(t) is the cumulative green discount benefit. Both must vanish at zero.
    Caches contain only Treasury quantities and simulated rate paths.
    """
    def __init__(self,terms:BondTerms,valuation,curve,a,sigma,settings=None,h15=None,progress=None):
        started=time.time();self.terms=terms;self.valuation=as_date(valuation)
        self.settings=settings or HWSettings();self.max_treasury_horizon_years=0.;self.model=HullWhiteCurveModel(curve,a,sigma)
        self.h15=h15 or {};self.progress=progress;self.dtype=np.dtype(self.settings.cache_dtype)
        # Reuse the dated calendar/event definitions, including history actions.
        ns=NumericalSettings(train_paths=max(2,self.settings.train_paths),evaluation_paths=max(2,self.settings.evaluation_paths),
            step_days=self.settings.step_days,seed=self.settings.seed,qmc_power=self.settings.qmc_power,notice_lags=self.settings.notice_lags)
        self.schedule=object.__new__(HistoryBondPricer)
        BondPricer.__init__(self.schedule,terms,None,self.valuation,self.valuation,ns)
        self.dates=self.schedule.dates
        self.times=np.array([years(self.valuation,d) for d in self.dates])
        self.ntrain=self.settings.train_paths;self.neval=self.settings.evaluation_paths;self.npath=self.ntrain+self.neval
        self.actions=[];history=set();self.actions_by_node=[]
        for j,n in enumerate(self.dates):
            inds=[]
            if j>0:
                for r in self.schedule.redemption_candidates(n):
                    obs=self.schedule.benchmark_observation_dates(r) if r<terms.par_call_date else ()
                    for s in obs:
                        if self.valuation<s<=n:history.add(s)
                    inds.append(len(self.actions));self.actions.append((j,n,r,obs))
            self.actions_by_node.append(inds)
        self.sim_dates=sorted(set(self.dates)|history)
        self.sim_times=np.array([years(self.valuation,d) for d in self.sim_dates])
        self._simulate()
        self.cf_dates=[d for d in terms.payment_dates if d>self.valuation]
        self.cf_times=np.array([years(self.valuation,d) for d in self.cf_dates])
        self.cf_amounts=terms.cashflows[np.array([d>self.valuation for d in terms.payment_dates])]
        self.redemption_times=np.array([years(self.valuation,a[2]) for a in self.actions])
        self._prepare()
        self.preparation_seconds=time.time()-started
        self.price_calls=0
    def _simulate(self):
        m=self.model;N=self.npath;nt=len(self.sim_times)
        x=np.zeros((N,nt));integ=np.zeros((N,nt))
        # Independent cohorts; antithetic pairs within each cohort.
        for left,count,seed in [(0,self.ntrain,self.settings.seed),(self.ntrain,self.neval,self.settings.seed+1)]:
            rng=np.random.default_rng(seed)
            for j in range(1,nt):
                h=self.sim_times[j]-self.sim_times[j-1]
                cv=np.array([[m.vx(h),m.cov_x_i(h)],[m.cov_x_i(h),m.vi(h)]],float)
                e,v=np.linalg.eigh(cv);root=v@np.diag(np.sqrt(np.maximum(e,0.)))
                half=(count+1)//2;z=rng.standard_normal((half,2));z=np.r_[z,-z][:count]@root.T
                ix=slice(left,left+count);old=x[ix,j-1]
                x[ix,j]=np.exp(-m.a*h)*old+z[:,0]
                integ[ix,j]=integ[ix,j-1]+m.B(h)*old+z[:,1]
        self.sim_index={d:i for i,d in enumerate(self.sim_dates)}
        idx=[self.sim_index[d] for d in self.dates]
        self.x=x[:,idx];self.integral=integ[:,idx]
        self.history_x={d:x[:,self.sim_index[d]] for d in self.sim_dates if d not in set(self.dates)}
        self.all_x=x
    @lru_cache(None)
    def _cmt_table(self,s,months):
        m=self.model;t=years(self.valuation,s);tau=months/12.
        self.max_treasury_horizon_years=max(self.max_treasury_horizon_years,t+tau)
        h=np.arange(.5,tau+1e-8,.5)
        if not len(h) or abs(h[-1]-tau)>1e-10:h=np.r_[h,tau]
        accr=np.diff(np.r_[0.,h])
        # Conservative bound; all actually evaluated points must lie inside it.
        bound=max(.10,10*m.sigma/np.sqrt(2*m.a))
        xx=np.linspace(-bound,bound,self.settings.cmt_grid_points)
        df=m.discounts(t,t+h,xx)
        yy=(1-df[:,-1])/(df@accr)
        return xx,yy
    def _cmt(self,s,months,x):
        xx,yy=self._cmt_table(s,months)
        if np.min(x,initial=0)<xx[0] or np.max(x,initial=0)>xx[-1]:raise ValueError('CMT interpolation domain exceeded')
        return np.interp(x,xx,yy)
    @lru_cache(None)
    def _redemption_table(self,r):
        terms=self.terms
        mask=np.array([d>r for d in terms.mw_dates]);cash=terms.mw_amounts[mask].copy()
        if terms.accrued_treatment=='exclude_before_discount':cash[0]-=terms.accrued(r)
        tau=np.array([thirty360(r,d) for d,k in zip(terms.mw_dates,mask) if k])
        # This table is for the smooth make-whole PV; floor and contractual
        # rounding are applied after evaluation, preserving their kinks.
        rates=np.linspace(-.15,.50,self.settings.redemption_grid_points)
        pv=np.exp(-2*tau[None,:]*np.log1p(rates[:,None]/2))@cash
        if terms.accrued_treatment=='subtract_after_discount':pv-=terms.accrued(r)
        return PchipInterpolator(rates,pv,extrapolate=False)
    def _conditional_redemption(self,n,r,observations):
        terms=self.terms;N=self.npath
        if r>=terms.par_call_date:return np.full(N,terms.notional+terms.accrued(r))
        tn=years(self.valuation,n);tr=years(self.valuation,r)
        x=self.all_x[:,self.sim_index[n]]
        past=[s for s in observations if s<=n];future=[s for s in observations if s>n]
        months,weights=self.schedule.h15_tenor_selection(r)
        known=np.zeros(N)
        for s in past:
            if s<=self.valuation:
                try:known+=sum(w*self.h15[s][mo] for w,mo in zip(weights,months))
                except KeyError as exc:raise ValueError(f'Missing known H.15 observation {s}') from exc
            else:
                xs=self.all_x[:,self.sim_index[s]]
                known+=sum(w*self._cmt(s,mo,xs) for w,mo in zip(weights,months))
        if future:
            ts=np.array([years(self.valuation,s) for s in future])
            loading,shift,cov=self.model.conditional_fixing_moments(tn,tr,ts)
            ev,vec=np.linalg.eigh(cov);root=vec@np.diag(np.sqrt(np.maximum(ev,0.)))
            uu=qmc.Sobol(d=len(future),scramble=True,seed=self.settings.seed+731).random_base2(self.settings.qmc_power)
            zz=norm.ppf(np.clip(uu,1e-12,1-1e-12))@root.T
            total=np.repeat(known[:,None],len(uu),axis=1)
            for k,s in enumerate(future):
                xs=x[:,None]*loading[k]+shift[k]+zz[None,:,k]
                total+=sum(w*self._cmt(s,mo,xs) for w,mo in zip(weights,months))
        else:total=known[:,None]
        rate=total/len(observations)
        if terms.treasury_rate_round_decimals is not None:
            scale=10**terms.treasury_rate_round_decimals;rate=np.floor(rate*100*scale+.5)/scale/100
        rate+=terms.mw_spread_bp/1e4
        if rate.min()<-.15 or rate.max()>.50:raise ValueError('Redemption interpolation domain exceeded')
        redemption=np.maximum(terms.notional,self._redemption_table(r)(rate))
        if terms.redemption_price_round_decimals is not None:
            scale=10**terms.redemption_price_round_decimals
            redemption=np.floor(redemption/terms.notional*100*scale+.5)/scale*terms.notional/100
        return redemption.mean(axis=1)+terms.accrued(r)
    def _prepare(self):
        N,J,K=self.npath,len(self.dates),len(self.cf_times)
        # Float32 saves memory, while all sums, regressions and prices use
        # float64. Its effect is separately checked against a float64 fixture.
        self.cashflow_basis=np.zeros((J,N,K),dtype=self.dtype)
        for j,t in enumerate(self.times):
            mask=self.cf_times>t+1e-12
            if mask.any():
                self.cashflow_basis[j][:,mask]=self.model.discounts(t,self.cf_times[mask],self.x[:,j])
        self.redemption_tsy_pv=np.empty((len(self.actions),N),dtype=self.dtype)
        self.coupons_until_redemption=[]
        for ai,(j,n,r,obs) in enumerate(self.actions):
            tr=self.redemption_times[ai];tn=self.times[j]
            expected=self._conditional_redemption(n,r,obs)
            self.redemption_tsy_pv[ai]=self.model.discounts(tn,np.array([tr]),self.x[:,j])[:,0]*expected
            self.coupons_until_redemption.append(np.flatnonzero((self.cf_times>tn+1e-12)&(self.cf_times<=tr+1e-12)))
            if self.progress and ai and ai%200==0:self.progress({'prepared_actions':ai,'total_actions':len(self.actions)})
        self._cmt_table.cache_clear();self._redemption_table.cache_clear()
        # History is already represented in cached commitments.
        self.all_x=None;self.history_x={}
    def _features(self,x,gain):
        scale=max(self.model.sigma/np.sqrt(2*self.model.a),.001)
        z=x/scale;g=gain/10.
        return np.column_stack([np.ones(len(x)),z,z*z,g,g*g,z*g])
    def price(self,spread_integral,green_integral=None,return_samples=False):
        started=time.time();self.price_calls+=1
        def A(t):
            ans=np.asarray(spread_integral(t),float)
            if green_integral is not None:ans=ans-np.asarray(green_integral(t),float)
            return np.broadcast_to(ans,np.asarray(t).shape)
        if abs(float(A(np.array(0.))))>1e-10:raise ValueError('Integrated curves must vanish at zero')
        Acf=A(self.cf_times);An=A(self.times);Ar=A(self.redemption_times)
        cfweights=self.cf_amounts*np.exp(-Acf)
        # Every discount and option is recalculated for the supplied curves.
        H=np.asarray(self.cashflow_basis@cfweights,dtype=float)*np.exp(An)[:,None]
        gains=np.zeros_like(H)
        for j,ais in enumerate(self.actions_by_node):
            if not ais:continue
            for ai in ais:
                cost=np.asarray(self.redemption_tsy_pv[ai],float)*np.exp(An[j]-Ar[ai])
                cpidx=self.coupons_until_redemption[ai]
                if len(cpidx):cost=cost+(self.cashflow_basis[j][:,cpidx]@cfweights[cpidx])*np.exp(An[j])
                gains[j]=np.maximum(gains[j],H[j]-cost)
        gains=np.maximum(gains,0.)
        D=np.exp(-self.integral.T-self.model.phi_integral(self.times)[:,None]-An[:,None])
        policies=[None]*len(self.dates);future=np.zeros(self.ntrain)
        nfeatures=self._features(self.x[:1,0],np.zeros(1)).shape[1]
        for j in range(len(self.dates)-1,0,-1):
            itm=gains[j,:self.ntrain]>0
            if not np.any(itm):
                coef=np.zeros(nfeatures);coef[0]=float(np.mean(future/D[j,:self.ntrain]))
                policies[j]=coef
                continue
            idx=np.flatnonzero(itm);F=self._features(self.x[idx,j],gains[j,idx])
            target=future[idx]/D[j,idx]
            if len(idx)<8:
                coef=np.zeros(F.shape[1]);coef[0]=target.mean()
            else:
                gram=F.T@F;ridge=self.settings.regression_ridge*max(float(np.trace(gram)),1.)/F.shape[1]
                penalty=np.eye(F.shape[1])*ridge;penalty[0,0]=0
                coef=np.linalg.solve(gram+penalty,F.T@target)
            cont=np.maximum(F@coef,0.);take=gains[j,idx]>cont
            selected=idx[take];future[selected]=D[j,selected]*gains[j,selected]
            policies[j]=coef
        # Independent evaluation at the trained policy.
        values=np.zeros(self.neval);alive=np.ones(self.neval,dtype=bool);exercise_indices=np.full(self.neval,-1,int)
        for j in range(1,len(self.dates)):
            if policies[j] is None:continue
            ii=np.flatnonzero(alive&(gains[j,self.ntrain:]>0))
            if not len(ii):continue
            idx=ii+self.ntrain;F=self._features(self.x[idx,j],gains[j,idx]);cont=np.maximum(F@policies[j],0.)
            take=ii[gains[j,idx]>cont];ti=take+self.ntrain
            values[take]=D[j,ti]*gains[j,ti];alive[take]=False;exercise_indices[take]=j
        option=float(values.mean());half=(self.neval+1)//2
        if self.neval%2==0:
            pair=.5*(values[:half]+values[half:]);se=float(pair.std(ddof=1)/np.sqrt(len(pair)))
        else:se=float(values.std(ddof=1)/np.sqrt(len(values)))
        straight=float(np.exp(self.model.curve.log_discount(self.cf_times)-Acf)@self.cf_amounts)
        result={'straight_dirty':straight,'option_value':option,'model_dirty':straight-option,
            'option_standard_error':se,'evaluation_exercise_probability':float((~alive).mean()),
            'training_option_value':float(future.mean()),'pricing_seconds':time.time()-started,
            'notice_nodes':len(self.dates),'redemption_actions':len(self.actions),
            'maximum_treasury_horizon_used_years':max(self.max_treasury_horizon_years,float(self.cf_times[-1])),
            'treasury_model':'Hull-White one factor with exact initial-curve shift',
            'credit_diffusion':0.,'green_diffusion':0.,'finite_grid':True,
            'history_fixings_retained':True,'own_option_revalued_at_every_price':True,
            'observed_price_used':False,'standard_error_scope':'Antithetic independent policy-evaluation sampling error; excludes policy, grid, fixing integration, parameter and price-input uncertainty.'}
        if return_samples:result['_option_samples']=values;result['_exercise_indices']=exercise_indices
        return result
    def cache_bytes(self):return int(self.cashflow_basis.nbytes+self.redemption_tsy_pv.nbytes+self.x.nbytes+self.integral.nbytes)
