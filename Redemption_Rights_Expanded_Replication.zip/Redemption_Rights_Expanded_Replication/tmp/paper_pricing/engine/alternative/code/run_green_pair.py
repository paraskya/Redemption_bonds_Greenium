"""Additional Verizon green/control pairs under the selected driftless refit.

The financial pricing modules are frozen copies of the preceding experiment.
This runner generalizes contract selection and reporting only. Each process
prices one green bond, its contractual conventional-kernel counterfactual,
and its specified conventional control, on shared exact Gaussian paths.
"""
from __future__ import annotations
import os
for name in ('OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS'):
    os.environ[name]='1'
import argparse,csv,hashlib,json,time
from pathlib import Path
from dataclasses import replace
import numpy as np
from scipy.optimize import brentq
from run_pair import PairedGroup,COUPLING_AUDITS,release_pricer_caches,se
from revised_pilot import (embed_config,read_contracts,contract_terms,read_prices,
    load_config,numerical_root,stripped,to_json)
from benchmark import CashflowBond,as_date
from joint_afns_model import JointAFNSModel
from dated_bond_pricer import NumericalSettings
from history_pricer import HistoryBondPricer,load_h15
from validated_policy import ValidationPolicyGreenPricer
from policy_feedback import fixed_conventional_policy

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--green',required=True);ap.add_argument('--control',required=True)
    ap.add_argument('--month',default='2026-08-31')
    ap.add_argument('--output',required=True)
    ap.add_argument('--seed',type=int,default=20260925)
    ap.add_argument('--train',type=int,default=1600)
    ap.add_argument('--validation',type=int,default=2400)
    ap.add_argument('--evaluation',type=int,default=6000)
    ap.add_argument('--step',type=int,default=30)
    ap.add_argument('--qmc-power',type=int,default=5)
    ap.add_argument('--config',default=str(ROOT/'inputs/selected_latest_config.json'))
    ap.add_argument('--fixed-z-bp',type=float,nargs='*',default=[])
    ap.add_argument('--direct-z-bp',type=float,default=None)
    ap.add_argument('--loo-z-bp',type=float,default=None)
    ap.add_argument('--extra-calendar-control',nargs='*',default=[])
    a=ap.parse_args();out=Path(a.output);out.mkdir(parents=True,exist_ok=True)
    if (out/'result.json').exists() and a.direct_z_bp is None:
        print(json.dumps({'reused':str(out/'result.json')}),flush=True);return
    started=time.time();green=a.green;control=a.control;counter=green+'_B'
    cfg=embed_config(load_config(a.config,a.month),.1)
    if cfg['epsF']!=0 or float(cfg.get('issuer_delta',0))!=0:
        raise ValueError('Expected selected epsF=0, issuer_delta=0 configuration')
    settings=NumericalSettings(train_paths=a.train,validation_paths=a.validation,
        evaluation_paths=a.evaluation,step_days=a.step,qmc_power=a.qmc_power,
        seed=a.seed,paired_driver=False)
    date=as_date(cfg.get('valuation_date',cfg.get('observation_date',a.month)))
    records=read_contracts(ROOT/'inputs/verizon_reviewed_contracts.json')
    if not records[green]['is_green_source'] or records[control]['is_green_source']:
        raise ValueError('Green/control classification disagreement')
    terms={c:contract_terms(records[c]) for c in (green,control)}
    bonds={c:CashflowBond.from_contract(records[c]) for c in (green,control)}
    observed=read_prices(ROOT/'inputs/verizon_reviewed_monthly_prices.csv',a.month,(green,control))
    dirty={c:observed[c]+terms[c].accrued(date) for c in (green,control)}
    h15=load_h15(ROOT/'inputs/treasury_daily_percent.csv')
    pg=ValidationPolicyGreenPricer(terms[green],JointAFNSModel(cfg,'green'),date,date,settings,h15_daily=h15)
    pc=HistoryBondPricer(terms[control],JointAFNSModel(cfg,'conventional'),date,date,settings,h15_daily=h15)
    pb=HistoryBondPricer(terms[green],JointAFNSModel(cfg,'conventional'),date,date,settings,h15_daily=h15)
    pg.conventional_policy_pricer=pb
    extras=[HistoryBondPricer(contract_terms(records[c]),JointAFNSModel(cfg,'conventional'),date,date,settings,h15_daily=h15)
        for c in a.extra_calendar_control]
    shared=PairedGroup([pg,pc,pb]+extras);y=np.array(cfg['y0'])
    print(json.dumps({'started':green,'control':control,'seed':a.seed,
        'green_notice_nodes':len(pg.dates),'control_notice_nodes':len(pc.dates),
        'union_simulation_nodes':len(shared.simulation_dates)}),flush=True)
    if a.direct_z_bp is not None:
        direct_states=[('common_state',a.direct_z_bp)]
        if a.loo_z_bp is not None:direct_states.append(('leave_one_green_out',a.loo_z_bp))
        for label,z_bp in direct_states:
            y[6]=z_bp/1e4
            # No observed target is passed to any pricing or policy method.
            # For LOO, the caller must supply Z fitted only to the other greens.
            r=pg.price(initial_state=y,return_samples=True)
            payload={'green_code':green,'control_code':control,'month_label':a.month,
                'valuation_date':str(date),'common_green_state_bp':z_bp,'candidate_type':label,
                'observed_dirty_per100':dirty[green],'observed_clean_per100':observed[green],
                'model_callable_dirty_per100':r['model_dirty'],
                'model_callable_price_residual_per100':r['model_dirty']-dirty[green],
                'model_callable_yield_residual_bp':(bonds[green].yield_from_dirty(r['model_dirty'],date)-bonds[green].yield_from_dirty(dirty[green],date))*1e4,
                'option_value_per100':r['option_value'],'option_MC_SE_per100':r['option_standard_error'],
                'numerics':settings.__dict__,'config':cfg,'result':stripped(r),
                'shared_path_audit':shared.audit(),'covariance_factor_audit':COUPLING_AUDITS,
                'observed_green_price_used_in_pricing_or_policy':False,
                'observed_green_price_used_only_for_scoring':True,
                'state_fitted_elsewhere':True,
                'scope':'Direct callable price at an externally fitted green state, with green and conventional exercise policies trained and independent-validation selected at that state. No green quote inversion is performed. A leave-one-green-out state must be supplied from the other green bonds only; conventional hyperparameters remain retrospective and the other-bond targets use frozen own-option addbacks.',
                'extra_calendar_controls':a.extra_calendar_control,
                'elapsed_seconds':time.time()-started}
            np.savez_compressed(out/(label+'_option_samples.npz'),**{green:r['_option_samples']})
            (out/(label+'_result.json')).write_text(json.dumps(payload,indent=2,default=to_json))
            print(json.dumps({'direct_state_completed':str(out),'candidate_type':label,'green':green,'z_bp':z_bp,
                'callable_price_residual':r['model_dirty']-dirty[green],
                'callable_yield_residual_bp':payload['model_callable_yield_residual_bp'],
                'elapsed_seconds':time.time()-started}),flush=True)
        release_pricer_caches();return
    result={}
    for c,p in ((control,pc),(counter,pb)):
        result[c]=p.price(initial_state=y,return_samples=True)
        print(json.dumps({'code':c,'option':result[c]['option_value'],'elapsed_seconds':time.time()-started}),flush=True)
    straight_z=float(brentq(lambda z:pg.straight(initial_state=y,z=z)-dirty[green],-.05,.05,xtol=1e-13))
    inv=numerical_root(pg,dirty[green],y)
    y[6]=inv['z'];result[green]=inv['result']
    print(json.dumps({'code':green,'option':result[green]['option_value'],
        'green_z_bp':inv['z']*1e4,'converged':inv['converged'],'elapsed_seconds':time.time()-started}),flush=True)
    fixed_z_results={}
    for z_bp in a.fixed_z_bp:
        rr=pg.price(initial_state=np.array(cfg['y0']),z=z_bp/1e4,return_samples=True)
        fixed_z_results[str(z_bp)]=stripped(rr)
    rg=result[green];rc=result[control];rb=result[counter]
    tg,cg=bonds[green].cashflows(date);tc,cc=bonds[control].cashflows(date)
    tau=float(tg[-1]);loading=float(-pg.model.B(np.array([tau]))[0,6]/tau)
    # The locally evaluated price bracket propagates conditional simulation
    # error. This excludes regression selection and parameter uncertainty.
    trace=inv['evaluations'];z=inv['z']
    below=[x for x in trace if x['z']<z];above=[x for x in trace if x['z']>z]
    local_derivative=None
    if below and above:
        lo=max(below,key=lambda x:x['z']);hi=min(above,key=lambda x:x['z'])
        local_derivative=(hi['callable_price_error_per100']-lo['callable_price_error_per100'])/(hi['z']-lo['z'])
    elif len(trace)>=2:
        nearest=sorted(trace,key=lambda x:abs(x['z']-z))[:2]
        local_derivative=(nearest[1]['callable_price_error_per100']-nearest[0]['callable_price_error_per100'])/(nearest[1]['z']-nearest[0]['z'])
    straight_derivative=float(np.asarray(cg)@(pg.model.discounts(y,tg)*(-pg.model.B(np.asarray(tg))[:,6])))
    local_derivative_screen_pass=bool(local_derivative and local_derivative>0 and abs(local_derivative/straight_derivative-1)<.2)
    derivative_scope='Local full-callable-price secant through evaluated root trials. When it differs by more than 20% from the straight derivative, its propagated SE is suppressed because a narrow bracket can cross discrete policy changes. A passing screen is not proof of derivative accuracy.'
    z_se=rg['option_standard_error']/local_derivative if local_derivative_screen_pass else None
    yg=bonds[green].yield_from_dirty(dirty[green],date)
    yc=bonds[control].yield_from_dirty(dirty[control],date)
    yg_adj=bonds[green].yield_from_dirty(dirty[green]+rg['option_value'],date)
    yc_adj=bonds[control].yield_from_dirty(dirty[control]+rc['option_value'],date)
    ybg=bonds[green].yield_from_dirty(rb['straight_dirty'],date)
    ybc=bonds[control].yield_from_dirty(rc['straight_dirty'],date)
    synthetic=replace(bonds[green],coupon_pct=bonds[control].coupon_pct)
    ts,cs=synthetic.cashflows(date)
    hs=float(pb.model.discounts(y,ts)@cs)
    ys=synthetic.yield_from_dirty(hs,date)
    coupon=(ybg-ys)*1e4;maturity=(ys-ybc)*1e4
    raw=(yc-yg)*1e4;net=((yc_adj-yg_adj)-(yc-yg))*1e4
    standardized=(yc_adj-yg_adj)*1e4+coupon+maturity
    # Pathwise linear influence of each own-option addback on matched yields.
    def yield_derivative(bond,price):
        h=1e-4
        return (bond.yield_from_dirty(price+h,date)-bond.yield_from_dirty(price-h,date))/(2*h)
    dg=yield_derivative(bonds[green],dirty[green]+rg['option_value'])
    dc=yield_derivative(bonds[control],dirty[control]+rc['option_value'])
    net_se=se(1e4*(dc*rc['_option_samples']-dg*rg['_option_samples']))
    fixed_policy=fixed_conventional_policy(pb,pg,y)
    own_diff=rg['_option_samples']-rb['_option_samples']
    section74={
        'conventional_straight_green_contract_per100':rb['straight_dirty'],
        'conventional_option_green_contract_per100':rb['option_value'],
        'conventional_callable_green_contract_per100':rb['model_dirty'],
        'green_option_green_contract_per100':rg['option_value'],
        'observed_callable_premium_per100':dirty[green]-rb['model_dirty'],
        'observed_straight_equivalent_premium_per100':dirty[green]+rg['option_value']-rb['straight_dirty'],
        'same_contract_option_feedback_per100':rg['option_value']-rb['option_value'],
        'same_contract_option_feedback_paired_MC_SE_per100':se(own_diff),
        'green_option_under_fixed_conventional_policy_per100':fixed_policy['green_option_under_fixed_conventional_policy'],
        'green_exercise_policy_response_per100':rg['option_value']-fixed_policy['green_option_under_fixed_conventional_policy'],
        'identity_error_per100':(dirty[green]+rg['option_value']-rb['straight_dirty'])-(dirty[green]-rb['model_dirty'])-(rg['option_value']-rb['option_value'])}
    comp=[]
    for c in (green,control):
        r=result[c];h=rb['straight_dirty'] if c==green else r['straight_dirty']
        comp.append({'month_label':a.month,'valuation_date':str(date),'code':c,
            'is_green':c==green,'maturity_date':records[c]['maturity_date'],
            'coupon_pct':records[c]['coupon_pct'],'observed_clean_per100':observed[c],
            'accrued_per100':terms[c].accrued(date),'observed_dirty_per100':dirty[c],
            'option_value_per100':r['option_value'],'option_MC_SE_per100':r['option_standard_error'],
            'option_equivalent_straight_observed_dirty_per100':dirty[c]+r['option_value'],
            'option_equivalent_straight_observed_clean_per100':observed[c]+r['option_value'],
            'conventional_straight_dirty_per100':h,'model_straight_dirty_per100':r['straight_dirty'],
            'model_callable_dirty_per100':r['model_dirty'],'model_price_residual_per100':r['model_dirty']-dirty[c],
            'negative_instantaneous_issuer_option_share':r['share_option_value_from_negative_issuer_spread_at_notice'],
            'negative_remaining_zero_spread_option_share':r['share_option_value_from_negative_remaining_maturity_zero_spread_at_notice'],
            'Q_notice_grid_issuer_negative_probability':r['Q_notice_grid_probability_issuer_spread_ever_negative']})
    payload={'green_code':green,'control_code':control,'conventional_counterfactual_code':counter,
        'month_label':a.month,'valuation_date':str(date),'config':cfg,'numerics':settings.__dict__,
        'status':'conditional_callable_inversion_under_selected_driftless_refit',
        'production_option_estimate':False,'conventional_own_option_outer_refit_completed':False,
        'green_dynamics_estimated':False,'price_basis_verified':False,'price_basis_assumed':'clean',
        'green_inversion':{k:v for k,v in inv.items() if k!='result'},
        'conditional_green_state_bp':z*1e4,'straight_only_green_state_bp':straight_z*1e4,
        'final_payment_horizon_years':tau,'green_loading_at_final_payment':loading,
        'conditional_zero_greenium_at_final_payment_bp':z*loading*1e4,
        'straight_only_zero_greenium_at_final_payment_bp':straight_z*loading*1e4,
        'green_own_option_zero_greenium_effect_bp':(z-straight_z)*loading*1e4,
        'green_state_conditional_MC_SE_bp':z_se*1e4 if z_se is not None else None,
        'endpoint_zero_greenium_conditional_MC_SE_bp':z_se*loading*1e4 if z_se is not None else None,
        'local_callable_price_derivative':local_derivative,'derivative_scope':derivative_scope,
        'local_callable_derivative_screen_passed':local_derivative_screen_pass,
        'straight_price_derivative':straight_derivative,
        'green_state_MC_SE_straight_sensitivity_approx_bp':rg['option_standard_error']/straight_derivative*1e4,
        'endpoint_greenium_MC_SE_straight_sensitivity_approx_bp':rg['option_standard_error']/straight_derivative*loading*1e4,
        'straight_sensitivity_SE_scope':'Conditional option Monte Carlo error propagated through straight-price derivative only; excludes option sensitivity and policy, parameter, quote and grid uncertainty.',
        'near_control_decomposition':{'raw_matched_yield_gap_bp':raw,
            'own_option_net_addback_bp':net,'own_option_net_addback_conditional_MC_SE_bp':net_se,
            'pure_coupon_standardization_bp':coupon,'maturity_schedule_standardization_bp':maturity,
            'combined_coupon_maturity_standardization_bp':coupon+maturity,
            'control_anchored_standardized_straight_yield_gap_bp':standardized,
            'full_curve_straight_yield_gap_bp':(ybg-yg_adj)*1e4,
            'control_full_curve_yield_residual_bp':(ybc-yc_adj)*1e4,
            'bridge_identity_error_bp':(ybg-yg_adj)*1e4-standardized-(ybc-yc_adj)*1e4,
            'coupon_order':'First change green coupon to control coupon on green dates; then change to control maturity and schedule.'},
        'section74':section74,'price_components':comp,'bond_results':{c:stripped(r) for c,r in result.items()},
        'fixed_green_state_evaluations':fixed_z_results,'final_initial_state':y.tolist(),
        'shared_path_audit':shared.audit(),'covariance_factor_audit':COUPLING_AUDITS,
        'input_hashes':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (ROOT/'inputs').glob('*') if p.is_file()},
        'scope':'One-date conditional roots under a pre-option issuer curve. Finite-policy simulation; no full-conventional option outer iteration, no filtered green state, no identification of term-structure slope from a single green quote.',
        'elapsed_seconds':time.time()-started}
    np.savez_compressed(out/'option_samples.npz',**{c:r['_option_samples'] for c,r in result.items()})
    with (out/'option_addbacks.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(comp[0]));w.writeheader();w.writerows(comp)
    (out/'result.json').write_text(json.dumps(payload,indent=2,default=to_json))
    print(json.dumps({'completed':str(out),'green':green,'green_z_bp':z*1e4,
        'endpoint_zero_greenium_bp':z*loading*1e4,'green_option':rg['option_value'],
        'root_converged':inv['converged'],'elapsed_seconds':time.time()-started}),flush=True)
    release_pricer_caches()

if __name__=='__main__':main()
