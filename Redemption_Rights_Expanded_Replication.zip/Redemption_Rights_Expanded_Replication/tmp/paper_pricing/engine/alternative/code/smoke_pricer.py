from pathlib import Path
import sys,json,time
sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'treasury/code'))
from hull_white_contract_pricer import *
from revised_pilot import read_contracts,contract_terms
from history_pricer import load_h15
from treasury_curves import TreasuryCurve
import argparse
ap=argparse.ArgumentParser();ap.add_argument('--bond',default='92343VES');ap.add_argument('--train',type=int,default=24);ap.add_argument('--evaluation',type=int,default=48)
ap.add_argument('--source-root',default=str(Path(__file__).resolve().parents[2]/'previous'))
a=ap.parse_args()
base=Path(a.source_root)/'pricing/inputs'
terms=contract_terms(read_contracts(base/'verizon_reviewed_contracts.json')[a.bond])
curve=TreasuryCurve('2026-08-31')
s=HWSettings(train_paths=a.train,evaluation_paths=a.evaluation)
p=HWContractPricer(terms,'2026-08-31',curve,.1,.01,s,load_h15(base/'treasury_daily_percent.csv'),progress=lambda a:print(json.dumps(a),flush=True))
print(json.dumps({'prepared':a.bond,'seconds':p.preparation_seconds,'bytes':p.cache_bytes(),'nodes':len(p.dates)}),flush=True)
for spread in [.005,.01,.02]:
 print(json.dumps(p.price(lambda t:spread*t)),flush=True)
