"""Historical covariance matching for Hull--White bond yield loadings.

The scalar Q reversion controls B_Q(tau)/tau. Fit this shape and short-rate
variance to daily GSW zero-yield changes. No current-curve option calibration,
no claim to estimate risk premia, and no assumption that a is physical OU
reversion. Changes in fitted Treasury curves contain multiple factors and
measurement noise, so fit residual and PC coverage are reported explicitly.
"""
from pathlib import Path
import json,hashlib
import numpy as np
import pandas as pd
from scipy.optimize import minimize_scalar
ROOT=Path(__file__).resolve().parents[1]
source=ROOT.parent/'treasury/inputs/gsw_daily_percent.csv'
df=pd.read_csv(source);df['observation_date']=pd.to_datetime(df['observation_date'])
df=df.loc[df.observation_date.between('2021-08-31','2026-08-31')].sort_values('observation_date')
tenors=np.array([1,2,3,5,7,10,20,30],float)
y=df[[f'SVENY{int(t):02}' for t in tenors]].to_numpy()/100
dt=np.diff(df.observation_date.to_numpy()).astype('timedelta64[D]').astype(float)/365.25
changes=np.diff(y,axis=0)/np.sqrt(dt[:,None]);changes-=changes.mean(axis=0)
cov=changes.T@changes/len(changes)
def calc(a):
 b=-np.expm1(-a*tenors)/(a*tenors);outer=np.outer(b,b)
 var=float(np.sum(cov*outer)/np.sum(outer*outer))
 err=float(np.sum((cov-var*outer)**2)/np.sum(cov*cov))
 return err,var,b
opt=minimize_scalar(lambda loga:calc(np.exp(loga))[0],bounds=(np.log(.0001),np.log(3.)),method='bounded',options={'xatol':1e-12})
a=float(np.exp(opt.x));err,var,b=calc(a);e=np.linalg.eigvalsh(cov)
results={'method':'Frobenius least-squares match to annualized daily GSW zero-yield-change covariance',
 'date_from':str(df.observation_date.min().date()),'date_to':str(df.observation_date.max().date()),'n_changes':len(changes),
 'tenors_years':tenors.tolist(),'a_Q':a,'sigma_per_sqrt_year':float(np.sqrt(var)),
 'sigma_bp_per_sqrt_year':float(np.sqrt(var)*1e4),'relative_covariance_frobenius_error':float(np.sqrt(err)),
 'first_empirical_PC_variance_share':float(e[-1]/e.sum()),'rate_loading_B_over_tau':b.tolist(),
 'empirical_yield_vol_bp':(np.sqrt(np.diag(cov))*1e4).tolist(),'fitted_yield_vol_bp':(np.sqrt(var)*b*1e4).tolist(),
 'historical_covariance':cov.tolist(),'Q_reversion_physical_OU_estimate':False,'Q_option_implied_calibration':False,
 'scope':'Transparent historical-covariance parameterization. Current Treasury curve is fitted separately and exactly by a time-dependent shift. Historical daily Treasury changes are not exactly one-factor. No interest-rate option quotes are used.',
 'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest()}
out=ROOT/'results';out.mkdir(parents=True,exist_ok=True);(out/'hw_rate_parameters.json').write_text(json.dumps(results,indent=2))
print(json.dumps(results,indent=2))
