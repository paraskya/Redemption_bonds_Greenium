"""Independent cashflow and yield conventions for local matched comparisons.

US 30/360 accrued interest, following payment adjustment and a nominal annual
semiannual yield using ACT/365.25 times to payment. No provider-yield convention
or quote timestamp is asserted by these calculations.
"""
from __future__ import annotations
import argparse
import calendar
import csv
import hashlib
import json
from dataclasses import dataclass
from datetime import date, timedelta
from functools import lru_cache
from pathlib import Path
import numpy as np
from pandas.tseries.holiday import USFederalHolidayCalendar
from scipy.optimize import brentq


def as_date(value):
    return value if isinstance(value, date) else date.fromisoformat(value)

def years(start, end):
    return (as_date(end)-as_date(start)).days/365.25

def thirty360(start, end):
    """US 30/360; coupon accrual follows contractual, unadjusted dates."""
    start, end = as_date(start), as_date(end)
    def last_feb(d):
        return d.month == 2 and d.day == calendar.monthrange(d.year, 2)[1]
    d1 = 30 if start.day == 31 or last_feb(start) else start.day
    d2 = end.day
    if (d2 == 31 and d1 >= 30) or (last_feb(start) and last_feb(end)):
        d2 = 30
    return ((end.year-start.year)*360+(end.month-start.month)*30+d2-d1)/360

def add_months(d, n):
    d = as_date(d)
    y, m = divmod(d.year*12+d.month-1+n, 12)
    m += 1
    return date(y, m, min(d.day, calendar.monthrange(y,m)[1]))

@lru_cache(maxsize=100)
def holidays(year):
    # Explicit approximation to the legal NYC banking calendar. It includes
    # US federal observed holidays. Good Friday is deliberately not added.
    # None of these bonds' scheduled payments lies near Juneteenth; therefore
    # the 2021 bank-specific adoption ambiguity cannot alter this schedule.
    return frozenset(USFederalHolidayCalendar().holidays(
        date(year-1,1,1), date(year+1,12,31)).date)

def business(d):
    d = as_date(d)
    return d.weekday() < 5 and d not in holidays(d.year)

def following(d):
    d = as_date(d)
    while not business(d):
        d += timedelta(days=1)
    return d

def shift_business(d, n):
    d = as_date(d)
    step = 1 if n > 0 else -1
    for _ in range(abs(n)):
        d += timedelta(days=step)
        while not business(d):
            d += timedelta(days=step)
    return d

@dataclass
class CashflowBond:
    code: str
    coupon_pct: float
    issue_date: date
    maturity_date: date
    first_coupon_date: date
    frequency: int = 2
    notional: float = 100.

    @classmethod
    def from_contract(cls, row):
        if row['currency'] != 'USD' or row['frequency'] != 2:
            raise ValueError('Pilot implements USD semiannual bonds only')
        return cls(row['source_code'], float(row['coupon_pct']),
                   as_date(row.get('interest_accrual_start_date',row['issue_date'])), as_date(row['maturity_date']),
                   as_date(row['first_coupon_date']), int(row['frequency']))

    def schedule(self):
        """Full original schedule; amounts per100 and no call assumptions."""
        rows = []
        d = self.first_coupon_date
        previous = self.issue_date
        while d <= self.maturity_date:
            coupon = self.notional*self.coupon_pct/100*thirty360(previous,d)
            principal = self.notional if d == self.maturity_date else 0.
            rows.append({'code': self.code, 'contract_date': d,
                         'payment_date': following(d), 'coupon': coupon,
                         'principal': principal, 'amount': coupon+principal})
            previous, d = d, add_months(d,12//self.frequency)
        if not rows or rows[-1]['contract_date'] != self.maturity_date:
            raise ValueError('Unsupported irregular terminal period')
        return rows

    def accrued(self, settlement):
        settlement = as_date(settlement)
        if settlement < self.issue_date:
            raise ValueError('Settlement precedes issue date')
        previous = max([self.issue_date]+[
            r['contract_date'] for r in self.schedule()
            if r['contract_date'] <= settlement])
        return self.notional*self.coupon_pct/100*thirty360(previous,settlement)

    def cashflows(self, settlement, adjusted=True):
        """(times, amounts) with ACT/365.25 times, after settlement only."""
        settlement = as_date(settlement)
        chosen_date = 'payment_date' if adjusted else 'contract_date'
        rows = [r for r in self.schedule() if r[chosen_date] > settlement]
        return (np.asarray([years(settlement,r[chosen_date]) for r in rows]),
                np.asarray([r['amount'] for r in rows]))

    def price_from_yield(self, y, settlement, adjusted=True):
        times, amounts = self.cashflows(settlement,adjusted)
        return float(np.sum(amounts*(1+y/self.frequency)**(-self.frequency*times)))

    def yield_from_dirty(self, dirty, settlement, adjusted=True):
        if dirty <= 0:
            raise ValueError('Dirty price must be positive')
        return float(brentq(lambda y:self.price_from_yield(y,settlement,adjusted)-dirty,
                           -.5, 2., xtol=1e-13))

    def street_convention_yield(self, dirty, settlement):
        """Sensitivity only: nominal semiannual yield with US30/360 exponents."""
        settlement = as_date(settlement)
        rows = [r for r in self.schedule() if r['payment_date'] > settlement]
        t = np.asarray([thirty360(settlement,r['contract_date']) for r in rows])
        cf = np.asarray([r['amount'] for r in rows])
        return float(brentq(lambda y:np.sum(cf*(1+y/2)**(-2*t))-dirty,
                           -.5,2.,xtol=1e-13))
