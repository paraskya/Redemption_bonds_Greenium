"""Portable Treasury curves for controlled corporate-bond comparisons.

Annual decimal continuously compounded zero yields, ACT/365.25 year fractions.
GSW is the published Svensson curve, not an independent fit to Treasury prices.
AFNS direct fits retain the saved diffusion and recompute convexity for lambda.
"""
from pathlib import Path
import json
import numpy as np
from numpy.polynomial.legendre import leggauss

_Q, _W = leggauss(64)

def afns_B(tau, lam):
    t = np.atleast_1d(np.asarray(tau, dtype=float))
    s = -np.expm1(-lam*t)/lam
    ans = np.column_stack((t, s, s-t*np.exp(-lam*t)))
    return ans[0] if np.ndim(tau) == 0 else ans

def afns_A(tau, lam, covariance):
    t = np.atleast_1d(np.asarray(tau, dtype=float))
    v = t[:, None]*(_Q[None, :]+1)/2
    bs = afns_B(v.ravel(),lam).reshape(len(t),len(_Q),3)
    ans = .25*t*np.einsum('nqi,ij,nqj,q->n',bs,np.asarray(covariance),bs,_W)
    return float(ans[0]) if np.ndim(tau) == 0 else ans

def ns_loading(tau, decay_time):
    t = np.atleast_1d(np.asarray(tau, dtype=float))
    v = t/decay_time
    b = np.ones_like(v)
    np.divide(-np.expm1(-v),v,out=b,where=v!=0)
    return b, b-np.exp(-v)

def svensson_zero(tau, betas_decimal, tau1, tau2):
    t = np.atleast_1d(np.asarray(tau, dtype=float))
    b1,c1=ns_loading(t,tau1)
    _,c2=ns_loading(t,tau2)
    b=np.asarray(betas_decimal)
    ans=b[0]+b[1]*b1+b[2]*c1+b[3]*c2
    return float(ans[0]) if np.ndim(tau)==0 else ans

class TreasuryCurve:
    def __init__(self, month_label, model='gsw_svensson', parameter_path=None):
        p=Path(parameter_path) if parameter_path else Path(__file__).resolve().parents[1]/'results'/'curve_parameters.json'
        data=json.loads(p.read_text())
        self.month_label=month_label
        self.model=model
        self.parameters=data['months'][month_label][model]
        self.covariance=np.asarray(data['fixed_afns_covariance'])

    def zero(self,tau):
        t=np.atleast_1d(np.asarray(tau,dtype=float))
        if np.any(t<0):raise ValueError('Negative maturity is invalid')
        p=self.parameters
        if p['family']=='svensson':
            ans=svensson_zero(t,p['betas_decimal'],p['tau1'],p['tau2'])
        else:
            tsafe=np.where(t>0,t,1.)
            ans=(afns_B(tsafe,p['lambda'])@np.asarray(p['state'])-afns_A(tsafe,p['lambda'],self.covariance))/tsafe
            ans=np.where(t==0,p['state'][0]+p['state'][1],ans)
        return float(ans[0]) if np.ndim(tau)==0 else ans

    def discount(self,tau):
        return np.exp(-np.asarray(tau)*self.zero(tau))

    def log_discount(self,tau):
        return -np.asarray(tau)*self.zero(tau)

    def instantaneous_forward(self,tau):
        t=np.atleast_1d(np.asarray(tau,dtype=float))
        p=self.parameters
        if p['family']=='svensson':
            b=np.asarray(p['betas_decimal']);u=t/p['tau1'];v=t/p['tau2']
            ans=b[0]+b[1]*np.exp(-u)+b[2]*u*np.exp(-u)+b[3]*v*np.exp(-v)
        else:
            l=p['lambda'];x=np.asarray(p['state'])
            B=afns_B(t,l)
            mean=x[0]+x[1]*np.exp(-l*t)+x[2]*l*t*np.exp(-l*t)
            ans=mean-.5*np.einsum('ni,ij,nj->n',B,self.covariance,B)
        return float(ans[0]) if np.ndim(tau)==0 else ans
