"""Frozen, dated Verizon observations and parsimonious spread parameterization.

Prices are per 100. Rates and integrated rates use decimals unless a name ends
in ``_bp``. Every headline YTM uses actual adjusted payment dates and an
ACT/365.25 horizon, matching the preceding comparison's price-yield mapping.
"""
from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from pathlib import Path
import sys

import numpy as np
import pandas as pd


GREEN_CODES = ["92343VES", "92343VFL", "92343VGL", "92343VGP"]
HOLDOUT_CODES = ["92343VGK"]
VALUATION_DATE = "2026-08-31"


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load_observations(source_root, month=VALUATION_DATE):
    source_root = Path(source_root).resolve()
    sys.path.insert(0, str(source_root / "pricing" / "code"))
    from benchmark import CashflowBond, as_date
    from revised_pilot import contract_terms

    p = source_root / "pricing" / "inputs"
    config = json.loads((p / "selected_latest_config.json").read_text())
    contracts = {
        row["source_code"]: row
        for row in json.loads((p / "verizon_reviewed_contracts.json").read_text())["contracts"]
    }
    prices = pd.read_csv(p / "verizon_reviewed_monthly_prices.csv")
    fitting = config["conventional_fit_codes"]
    codes = fitting + HOLDOUT_CODES + GREEN_CODES
    latest = prices.loc[(prices.Date == month) & prices.Code.isin(codes)].set_index("Code")
    valuation = as_date(month)
    observations = []
    cashflows = []
    bonds = {}
    terms = {}
    for code in codes:
        contract = contracts[code]
        bond = CashflowBond.from_contract(contract)
        legal = contract_terms(contract)
        clean = float(latest.loc[code, "P_PRICE"])
        if not np.isfinite(clean) or clean <= 0:
            raise ValueError(f"Missing positive price for {code} at {month}")
        accrued = bond.accrued(valuation)
        dirty = clean + accrued
        y = bond.yield_from_dirty(dirty, valuation, adjusted=True)
        dv01 = (bond.price_from_yield(y - 0.0001, valuation, adjusted=True)
                - bond.price_from_yield(y + 0.0001, valuation, adjusted=True)) / 2
        t, cf = bond.cashflows(valuation, adjusted=True)
        mask = np.array([pay > valuation for pay in legal.payment_dates])
        legal_t = np.array([(pay - valuation).days / 365.25
                            for pay in legal.payment_dates if pay > valuation])
        if not np.array_equal(t, legal_t):
            raise AssertionError(f"Schedule timing differs for {code}")
        cf_error = float(np.max(np.abs(cf - legal.cashflows[mask])))
        ai_error = float(abs(accrued - legal.accrued(valuation)))
        if cf_error > 1e-10 or ai_error > 1e-10:
            raise AssertionError(f"Schedule amount/accrued differs for {code}")
        split = "green" if code in GREEN_CODES else "conventional_holdout" if code in HOLDOUT_CODES else "conventional_fit"
        observations.append(dict(
            code=code, split=split, valuation_date=month,
            coupon_pct=contract["coupon_pct"], maturity_date=contract["maturity_date"],
            is_green=bool(contract["is_green_source"]),
            observed_clean_per100=clean, accrued_per100=accrued,
            observed_dirty_per100=dirty, observed_yield_pct=y * 100,
            dv01_per100=dv01, final_payment_horizon_years=float(t[-1]),
            make_whole_spread_bp=contract["mw_spread_bp"],
            par_call_date=contract["par_call_date"],
            notice_min_days=contract["notice_min_days"],
            notice_max_days=contract["notice_max_days"],
            cashflow_crosscheck_max_error=cf_error, accrued_crosscheck_error=ai_error,
            yield_convention="semiannual_compounding_adjusted_payment_dates_ACT365.25",
            price_basis="P_PRICE_assumed_clean_not_independently_provider_verified",
        ))
        for row in bond.schedule():
            if row["payment_date"] > valuation:
                cashflows.append(dict(code=code, contract_date=str(row["contract_date"]),
                    payment_date=str(row["payment_date"]),
                    horizon_years=(row["payment_date"]-valuation).days/365.25,
                    coupon_per100=row["coupon"], principal_per100=row["principal"],
                    cashflow_per100=row["amount"]))
        bonds[code] = bond
        terms[code] = legal
    return dict(observations=pd.DataFrame(observations), cashflows=pd.DataFrame(cashflows),
                bonds=bonds, terms=terms, contracts=contracts, fitting_codes=fitting,
                holdout_codes=HOLDOUT_CODES, green_codes=GREEN_CODES,
                valuation=valuation, prior_config=config, source_root=source_root,
                source_hashes={str(file.relative_to(source_root)): sha256(file)
                               for file in [p / "selected_latest_config.json",
                                            p / "verizon_reviewed_contracts.json",
                                            p / "verizon_reviewed_monthly_prices.csv",
                                            source_root / "pricing/code/benchmark.py",
                                            source_root / "pricing/code/revised_pilot.py"]})


@dataclass
class NSSpread:
    """Three NS zero-spread coefficients; deterministic forward spread.

    S(t) = beta0*t + beta1*(1-exp(-lambda*t))/lambda
           + beta2*((1-exp(-lambda*t))/lambda-t*exp(-lambda*t)).
    All coefficients here are decimal rates.
    """
    parameters: np.ndarray
    decay: float = .3

    @staticmethod
    def integral_loadings(t, decay=.3):
        t = np.asarray(t, float)
        k = -np.expm1(-decay*t)/decay
        return np.stack([t, k, k-t*np.exp(-decay*t)], axis=-1)

    @staticmethod
    def forward_loadings(t, decay=.3):
        t = np.asarray(t, float)
        e = np.exp(-decay*t)
        return np.stack([np.ones_like(t), e, decay*t*e], axis=-1)

    def __call__(self, t):
        return self.integral_loadings(t, self.decay) @ np.asarray(self.parameters)

    def forward(self, t):
        return self.forward_loadings(t, self.decay) @ np.asarray(self.parameters)

    def zero(self, t):
        t = np.asarray(t, float)
        return np.divide(self(t), t, out=np.full_like(t, float(np.sum(self.parameters[:2]))), where=t != 0)

    def minimum_forward(self):
        """Exact global minimum over t >= 0, including the infinite horizon."""
        b0,b1,b2=np.asarray(self.parameters,float)
        candidates=[(0.,b0+b1),(float("inf"),b0)]
        if b2 != 0:
            critical=(b2-b1)/(self.decay*b2)
            if critical>0 and np.isfinite(critical):
                candidates.append((float(critical),float(self.forward(critical))))
        tenor,value=min(candidates,key=lambda item:item[1])
        return {"value":float(value),"horizon_years":float(tenor)}


@dataclass
class GreenIntegral:
    current: float
    long_run: float = 0.
    decay: float = .1

    def __call__(self, t):
        t = np.asarray(t, float)
        return self.long_run*t + (self.current-self.long_run)*(-np.expm1(-self.decay*t))/self.decay

    def zero(self, t):
        t = np.asarray(t, float)
        return np.divide(self(t), t, out=np.full_like(t, self.current), where=t != 0)


def write_inputs(data, output):
    output = Path(output)
    output.mkdir(parents=True, exist_ok=True)
    data["observations"].to_csv(output / "latest_observations.csv", index=False)
    data["cashflows"].to_csv(output / "latest_cashflows.csv", index=False)
    manifest = dict(valuation_date=str(data["valuation"]),
        conventional_fit_codes=data["fitting_codes"],
        conventional_holdout_codes=data["holdout_codes"],
        green_codes=data["green_codes"],
        holdout_conventional_quote_used_in_fit=False,
        prior_selected_model_source="pricing/inputs/selected_latest_config.json",
        yield_convention="nominal_semiannual_ACT365.25_to_following_adjusted_payment_dates",
        source_hashes=data["source_hashes"],
        observations=int(len(data["observations"])),
        green_shape=dict(muZ=.1, thetaZ=0., sigmaZ=0.),
        conventional_spread_curve=dict(family="Nelson_Siegel_zero_spread", decay=.3,
                                      stochastic_spread_diffusion=0.))
    (output / "input_manifest.json").write_text(json.dumps(manifest, indent=2))


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--source-root", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    write_inputs(load_observations(args.source_root), args.output)
